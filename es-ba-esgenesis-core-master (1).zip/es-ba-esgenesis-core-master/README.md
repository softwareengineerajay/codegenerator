# es-ba-genesis-core
ESGenesis Core SDKs and .NET project templates
