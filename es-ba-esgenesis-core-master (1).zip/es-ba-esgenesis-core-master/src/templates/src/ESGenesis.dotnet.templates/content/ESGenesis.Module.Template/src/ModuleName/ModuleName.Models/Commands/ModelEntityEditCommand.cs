﻿// Licensed to the .NET Foundation under one or more agreements.
// The .NET Foundation licenses this file to you under the MIT license.

using ESGenesis.Core.Sdk.CQRS.Commands;

namespace ModuleName.Models.Commands
{
    public class ModelEntityEditCommand
        : ICommand<bool>
    {
        public ModelEntityEditCommandModel ModelEntityEditCommandModel { get; private set; }
        public ModelEntityEditCommand(ModelEntityEditCommandModel animalEditCommandModel)
            : base()
        {
            this.ModelEntityEditCommandModel = animalEditCommandModel;
        }
    }
}

