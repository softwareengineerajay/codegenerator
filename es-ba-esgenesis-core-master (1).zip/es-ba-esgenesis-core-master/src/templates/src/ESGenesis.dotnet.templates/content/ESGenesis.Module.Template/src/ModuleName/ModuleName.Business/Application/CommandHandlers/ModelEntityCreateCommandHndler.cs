﻿// Licensed to the .NET Foundation under one or more agreements.
// The .NET Foundation licenses this file to you under the MIT license.

using ESGenesis.Core.Sdk.CQRS.Commands;
using Microsoft.Extensions.Logging;
using ModuleName.Models;
using ModuleName.Models.Commands;
using AutoMapper;
using ModuleName.Business.DataAccess.Entities;
using ModuleName.Business.BusinessLogic;

namespace ModuleName.Business.Application.CommandHandlers
{
    public class ModelEntityCreateCommandHndler
        : ICommandHandler<ModelEntityCreateCommand, ModelEntityCreateResponse>
    {
        private readonly ILogger<ModelEntityCreateCommandHndler> logger;
        private readonly IMapper mapper;
        private readonly IModelEntityBusinessLogic animalService;

        public ModelEntityCreateCommandHndler(
            ILogger<ModelEntityCreateCommandHndler> logger
            , IMapper mapper
            , IModelEntityBusinessLogic animalService)
        {
            this.logger = logger;
            this.mapper = mapper;
            this.animalService = animalService;
        }

        public async Task<ModelEntityCreateResponse> Handle(ModelEntityCreateCommand request, CancellationToken cancellationToken)
        {
            if (request == null) throw new ArgumentException(nameof(request));

            logger.LogInformation($"----- Add animal record Request: {request}");

            var response = await animalService.CreateAsyn(request.ModelEntityCreateCommandModel);

            if(response == null || response.IsSuccessful == false)
            {
                throw new Exception("Failed to create animal record.");
            }

            var result = mapper.Map<ModelEntity, ModelEntityCreateResponse>(response.Result);

            return result;
        }
    }
}
