﻿// Licensed to the .NET Foundation under one or more agreements.
// The .NET Foundation licenses this file to you under the MIT license.

using ESGenesis.Core.Sdk.CQRS.Queries;
using ESGenesis.Core.Sdk.Models;

namespace ModuleName.Models.Queries
{

    public class ExportModelEntitysQuery : IQuery<IBusinessResult<ModelEntityExportResultCode, byte[]>>
    {
        public ModelEntityExportSearchProfile ModelEntityExportSearchProfile { get; private set; }
        public ExportModelEntitysQuery(ModelEntityExportSearchProfile animalExportSearchProfile)
        {
            this.ModelEntityExportSearchProfile = animalExportSearchProfile;
        }
    }
}
