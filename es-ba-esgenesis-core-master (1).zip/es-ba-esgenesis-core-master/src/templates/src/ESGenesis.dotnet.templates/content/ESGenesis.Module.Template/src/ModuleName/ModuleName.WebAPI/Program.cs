using Elastic.Apm.SerilogEnricher;
using Elastic.CommonSchema.Serilog;
using Elastic.Serilog.Sinks;
using ModuleName.WebAPI;
using Serilog;
using Serilog.Exceptions;
using Serilog.Exceptions.Core;
using Serilog.Sinks.Elasticsearch;
using ElasticsearchSinkOptions = Serilog.Sinks.Elasticsearch.ElasticsearchSinkOptions;

try
{
    var host = CreateWebHostBuilder(args);
    host.Run();
    return 0;
}
catch (Exception ex)
{
    string type = ex.GetType().Name;
    if (type.Equals("StopTheHostException", StringComparison.Ordinal))
    {
        throw;
    }
    Log.Fatal(ex, "Program terminated unexpectedly ({ApplicationContext})!", Program.AppName);
    return 1;
}
finally
{
    Log.CloseAndFlush();
}
IHost CreateWebHostBuilder(string[] args)
{
    return Host.CreateDefaultBuilder(args)
        .ConfigureServices(services =>
        {
            services.Configure<HostOptions>(hostOptions =>
            {
                hostOptions.BackgroundServiceExceptionBehavior = BackgroundServiceExceptionBehavior.Ignore;
            });
        })
        .ConfigureWebHostDefaults(webBuilder =>
        {
            webBuilder
             .UseStartup<Startup>();
        })
       .ConfigureLogging((hostingContext, logging) =>
       {
           // Ensure HttpContextAccessor is accessible
           var httpAccessor = hostingContext.Configuration.Get<HttpContextAccessor>();

           var elkConfig = GetElasticsearchSinkOptions(hostingContext);

           var logger = new LoggerConfiguration()
                   .MinimumLevel.Override("Microsoft.EntityFrameworkCore.Database.Command", Serilog.Events.LogEventLevel.Verbose)
                   .Enrich.FromLogContext()
                   //.Enrich.WithEcsHttpContext(httpAccessor)
                   //.Enrich.With(new Serilog.Enrichers.Thread. Thread IdEnricher())
                   .Enrich.WithExceptionDetails(new DestructuringOptionsBuilder()
                        .WithDefaultDestructurers()
                   //     .WithDestructurers(new[] { new DbUpdateExceptionDestructurer() })
                   )
                   .Enrich.WithMachineName()
                   .Enrich.WithElasticApmCorrelationInfo()
                   .Enrich.WithProperty("Environment", $"{hostingContext.Configuration["ASPNETCORE_ENVIRONMENT"]}")
                   .Enrich.WithProperty("Application", Program.AppName)
                   .WriteTo.Console()
                   .WriteTo.Debug()
                   .WriteTo.Elasticsearch(elkConfig)
               .CreateBootstrapLogger();

           logging.ClearProviders();
           logging.AddSerilog(logger: logger, dispose: true);
       })
       .UseSerilog((hostingContext, config) =>
       {
           // Ensure HttpContextAccessor is accessible
           //var httpAccessor = hostingContext.Configuration.Get<HttpContextAccessor>();
           var httpAccessor = hostingContext.Configuration.Get<HttpContextAccessor>();

           var elkConfig = GetElasticsearchSinkOptions(hostingContext);

           config
               .MinimumLevel.Override("Microsoft.EntityFrameworkCore.Database.Command", Serilog.Events.LogEventLevel.Verbose)
               .Enrich.FromLogContext()
               //.Enrich.WithEcsHttpContext(httpAccessor)
               //.Enrich.With(new ThreadIdEnricher())
               .Enrich.WithExceptionDetails(new DestructuringOptionsBuilder()
                    .WithDefaultDestructurers()
               //     .WithDestructurers(new[] { new DbUpdateExceptionDestructurer() })
               )
               .Enrich.WithMachineName()
               .Enrich.WithElasticApmCorrelationInfo()
               .WriteTo.Console()
               .WriteTo.Debug()
               .Enrich.WithProperty("Environment", $"{hostingContext.Configuration["ASPNETCORE_ENVIRONMENT"]}")
               .Enrich.WithProperty("Application", Program.AppName)
               .WriteTo.Elasticsearch(elkConfig);
       })
       .Build();
}

ElasticsearchSinkOptions GetElasticsearchSinkOptions(HostBuilderContext hostingContext)
{
    var elkConfig = new ElasticsearchSinkOptions(
               new Uri(hostingContext.Configuration["ElasticSearchUrl"])
               )
    {
        ModifyConnectionSettings = x =>
        x.BasicAuthentication(
            hostingContext.Configuration["ElasticSearchUserName"],
            hostingContext.Configuration["ElasticSearchPassword"]),
        AutoRegisterTemplate = true,
        AutoRegisterTemplateVersion = AutoRegisterTemplateVersion.ESv6,
        CustomFormatter = new EcsTextFormatter(),
        IndexFormat = $"{hostingContext.Configuration["ElasticSearchEcsIndex"]}-{hostingContext.Configuration["ASPNETCORE_ENVIRONMENT"]}".ToLower()
    };

    return elkConfig;
}

#pragma warning disable S3903 // Types should be defined in named namespaces
public static partial class Program
#pragma warning restore S3903 // Types should be defined in named namespaces
{
    private static string Namespace = typeof(Startup).Namespace;
    public static readonly string AppName = Namespace.Replace("NOV.ES.TAT.", string.Empty);
}



//// Licensed to the .NET Foundation under one or more agreements.
//// The .NET Foundation licenses this file to you under the MIT license.

//var builder = WebApplication.CreateBuilder(args);

//// Add services to the container.

//builder.Services.AddControllers();
//// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
//builder.Services.AddEndpointsApiExplorer();
//builder.Services.AddSwaggerGen();

//var app = builder.Build();

//// Configure the HTTP request pipeline.
//if (app.Environment.IsDevelopment())
//{
//    app.UseSwagger();
//    app.UseSwaggerUI();
//}

//app.UseAuthorization();

//app.MapControllers();

//app.Run();
