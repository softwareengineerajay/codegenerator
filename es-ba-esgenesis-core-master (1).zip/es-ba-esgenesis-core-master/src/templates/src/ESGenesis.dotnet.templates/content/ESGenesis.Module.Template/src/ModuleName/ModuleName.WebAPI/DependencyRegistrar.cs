﻿using System.Reflection;
using Microsoft.Extensions.Diagnostics.HealthChecks;
using Newtonsoft.Json.Serialization;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using Microsoft.OpenApi.Models;
using ESGenesis.Core.Sdk.Authentication;
using ESGenesis.Cache.Redis.Sdk;
using ESGenesis.Core.Sdk.Caching;
using ESGenesis.Authentication.Sdk;
using ModuleName.WebAPI.Helpers;
using ModuleName.Business.DataAccess.Repositories;
using Microsoft.EntityFrameworkCore;
using ModuleName.Business.DataAccess;
using Asp.Versioning;
using ESGenesis.Core.Sdk.CQRS.Commands;
using ESGenesis.Core.Sdk.CQRS.Queries;
using ModuleName.Models.Queries;
using ModuleName.Business.Application.QueryHandlers;
using ModuleName.Business.BusinessLogic;
using ESGenesis.Authorization.Sdk.Clients;

namespace ModuleName.WebAPI
{
    public static class DependencyRegistrar
    {
        public static IServiceCollection AddCustomMvc(this IServiceCollection services)
        {
            services.AddControllers(
              options =>
              {
                  options.Filters.Add(typeof(HttpGlobalExceptionFilter));
                  options.Filters.Add(typeof(GlobalAuthenticationFilter));
                  //options.Filters.Add(typeof(LogLoggedInUserResourceFilter));

              }).AddNewtonsoftJson(
              joptions =>
              {
                  joptions.SerializerSettings.ContractResolver = new CamelCasePropertyNamesContractResolver();
                  joptions.SerializerSettings.ReferenceLoopHandling = ReferenceLoopHandling.Ignore;
                  joptions.SerializerSettings.Converters.Add(new StringEnumConverter());
              }
          );
            services.AddCors(options =>
            {
                options.AddPolicy("CorsPolicy",
                    builder => builder
                    .SetIsOriginAllowed((host) => true)
                    .AllowAnyMethod()
                    .AllowAnyHeader()
                    .AllowCredentials()
                    .WithExposedHeaders("*"));
            });
            return services;
        }

        public static IServiceCollection AddCustomApiVersion(this IServiceCollection services)
        {
            services.AddApiVersioning(options =>
            {
                options.DefaultApiVersion = new ApiVersion(1);
                options.ReportApiVersions = true;
                options.AssumeDefaultVersionWhenUnspecified = true;
                options.ApiVersionReader = ApiVersionReader.Combine(
                    new UrlSegmentApiVersionReader(),
                    new HeaderApiVersionReader("X-Api-Version"));
            })
            .AddApiExplorer(options =>
            {
                options.GroupNameFormat = "'v'V";
                options.SubstituteApiVersionInUrl = true;
            });

            return services;
        }

        public static IServiceCollection AddHealthChecks(this IServiceCollection services, IConfiguration configuration)
        {
            var hcBuilder = services.AddHealthChecks();

            hcBuilder.AddCheck("self", () => HealthCheckResult.Healthy());

            return services;
        }

        public static IServiceCollection AddCustomSwagger(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddSwaggerGen(options =>
            {
                options.SwaggerDoc("v1", new OpenApiInfo
                {
                    Title = "ESGenesis REST API",
                    Version = "v1",
                    Description = "The ESGenesis Service REST API"
                });
                options.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme()
                {
                    Name = "Authorization",
                    Type = SecuritySchemeType.ApiKey,
                    Scheme = "Bearer",
                    BearerFormat = "JWT",
                    In = ParameterLocation.Header,
                    Description = "JWT Authorization header using the Bearer scheme. \r\n\r\n Enter 'Bearer' [space] and then your token in the text input below.\r\n\r\nExample: \"Bearer 12345abcdef\"",
                });
                options.AddSecurityRequirement(new OpenApiSecurityRequirement()
                {
                    {
                          new OpenApiSecurityScheme()
                            {
                                Reference = new OpenApiReference
                                {
                                    Type = ReferenceType.SecurityScheme,
                                    Id = "Bearer"
                                }
                            },
                           Array.Empty<string>()
                    }
                });
            });

            return services;
        }

        public static IServiceCollection AddCustomDbContext(this IServiceCollection services,
            IConfiguration configuration)
        {
            services.AddDbContext<ModuleNameDbContext>(options =>
            {
                options.UseSqlServer(configuration["ModuleNameDbConnString"],
                sqlServerOptionsAction: sqlOptions =>
                {
                    //var typeOf = 
                    //sqlOptions.MigrationsAssembly(typeof(Upm.Business.DependencyRegistrar).GetTypeInfo().Assembly.GetName().Name);
                    //sqlOptions.EnableRetryOnFailure(maxRetryCount: 3, maxRetryDelay: TimeSpan.FromSeconds(30), errorNumbersToAdd: null);
                });
            },
            ServiceLifetime.Scoped
            );

            return services;
        }


        public static IServiceCollection AddWebApiServiceseDependecy(this IServiceCollection services)
        {
            services.AddScoped<IModelEntityRepository, ModelEntityRepository>();

            services.AddScoped<IModelEntityBusinessLogic, ModelEntityBusinessLogic>();
            services.AddScoped<IModelEntityExportBusinessLogic, ModelEntityExportBusinessLogic>();

            return services;
        }

        public static IServiceCollection RegistorMediatR(this IServiceCollection services)
        {
            services.AddScoped<IQueryBus, QueryBus>();
            services.AddScoped<ICommandBus, CommandBus>();

            List<Assembly> assemblies = new List<Assembly>();
            assemblies.Add(typeof(GetModelEntitysQuery).Assembly);
            assemblies.Add(typeof(GetModelEntitysQueryHandler).Assembly);

            services.AddMediatR(cfg =>
            cfg.RegisterServicesFromAssemblies(assemblies.ToArray()));
            
            return services;
        }

        public static IServiceCollection AddAutoMapper(this IServiceCollection services)
        {
            services.AddAutoMapper(AppDomain.CurrentDomain.GetAssemblies());
            return services;
        }

        public static IServiceCollection AddTokenValidatorSettings(this IServiceCollection services, IConfiguration configuration)
        {
            var tokenValidatorSettingsConfig = configuration.GetSection("TokenValidatorSettings");
            TokenValidatorSettings validatorSettings = Newtonsoft.Json.JsonConvert.DeserializeObject<TokenValidatorSettings>(tokenValidatorSettingsConfig.Value);

            services.AddSingleton<TokenValidatorSettings>(validatorSettings);
            services.AddScoped<ILoggedInUser, LoggedInUser>();

            return services;
        }

        public static IServiceCollection AddRedisConfig(this IServiceCollection services, IConfiguration configuration)
        {
            var redisSettingsConfig = configuration.GetSection("RedisSettingsConfig");
            services.Configure<RedisSettings>(redisSettingsConfig);

            var redisConnectionString = configuration["RedisConnectionString"];
            services.PostConfigure<RedisSettings>(o => o.ConnectionString = redisConnectionString);

            services.AddSingleton<ICache, RedisCache>();
            //services.AddSingleton<IAppNotificationClient, AppNotificationClient>();

            return services;
        }

        public static IServiceCollection AddUpmAuthorizzationService(this IServiceCollection services, IConfiguration configuration)
        {

            services.AddHttpClient<IUserProfileClient, UserProfileClient>(client =>
            {
                client.BaseAddress = new Uri(configuration["UpmServiceBaseUrl"]);
            });

            services.AddHttpClient<IFeatureToggleClient, FeatureToggleClient>(client =>
            {
                client.BaseAddress = new Uri(configuration["UpmServiceBaseUrl"]);
            });

            services.AddScoped<IUserSecurityContext, UserSecurityContext>();

            return services;
        }

    }

}
