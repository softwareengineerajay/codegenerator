﻿// Licensed to the .NET Foundation under one or more agreements.
// The .NET Foundation licenses this file to you under the MIT license.

using ESGenesis.Core.Sdk.Authentication;
using ModuleName.Business.BusinessLogic;
using ModuleName.Business.DataAccess;
using ModuleName.Business.DataAccess.Repositories;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace ModuleName.Worker
{
    public static class DependencyRegistrar
    {
        public static IServiceCollection AddCustomDbContext(this IServiceCollection services,
            IConfiguration configuration)
        {
            services.AddDbContext<ModuleNameDbContext>(options =>
            {
                options.UseSqlServer(configuration["ModuleNameDbConnString"],
                sqlServerOptionsAction: sqlOptions =>
                {
                    //var typeOf = 
                    //sqlOptions.MigrationsAssembly(typeof(Upm.Business.DependencyRegistrar).GetTypeInfo().Assembly.GetName().Name);
                    //sqlOptions.EnableRetryOnFailure(maxRetryCount: 3, maxRetryDelay: TimeSpan.FromSeconds(30), errorNumbersToAdd: null);
                });
            },
            ServiceLifetime.Scoped
            );

            return services;
        }

        public static IServiceCollection AddWorkerDomainCoreDependecy(this IServiceCollection services)
        {
            services.AddScoped<ILoggedInUser, LoggedInUser>();

            services.AddScoped<IModelEntityRepository, ModelEntityRepository>();

            services.AddScoped<IModelEntityBusinessLogic, ModelEntityBusinessLogic>();
            services.AddScoped<IModelEntityExportBusinessLogic, ModelEntityExportBusinessLogic>();

            services.AddScoped<IWorkerService, WorkerService>();

            return services;
        }
    }
}
