﻿// Licensed to the .NET Foundation under one or more agreements.
// The .NET Foundation licenses this file to you under the MIT license.

using AutoMapper;
using ESGenesis.Core.Sdk.CQRS.Queries;
using ModuleName.Models.Queries;
using ModuleName.Models;
using Microsoft.Extensions.Logging;
using ESGenesis.Core.Sdk.Models;
using ModuleName.Business.BusinessLogic;

namespace ModuleName.Business.Application.QueryHandlers
{
    public class ExportModelEntitysQueryHandler
        : IQueryHandler<ExportModelEntitysQuery, IBusinessResult<ModelEntityExportResultCode, byte[]>>
    {
        private readonly ILogger<ExportModelEntitysQueryHandler> logger;
        private readonly IMapper mapper;
        private readonly IModelEntityExportBusinessLogic animalExportService;

        public ExportModelEntitysQueryHandler(
            ILogger<ExportModelEntitysQueryHandler> logger,
            IMapper mapper,
            IModelEntityExportBusinessLogic animalExportService)
        {
            this.logger = logger;
            this.mapper = mapper;
            this.animalExportService = animalExportService;
        }

        public async Task<IBusinessResult<ModelEntityExportResultCode, byte[]>> Handle(ExportModelEntitysQuery request, CancellationToken cancellationToken)
        {
            if (request == null) throw new ArgumentException(nameof(request));

            logger.LogInformation($"----- Export ModelEntity QueryHandler Request: {request}");

            var result = await animalExportService.ExportCsv(request.ModelEntityExportSearchProfile);

            return result;
        }
    }
}
