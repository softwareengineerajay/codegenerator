﻿// Licensed to the .NET Foundation under one or more agreements.
// The .NET Foundation licenses this file to you under the MIT license.

using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.AspNetCore.Mvc;
using ESGenesis.Core.Sdk.Exceptions;

namespace ModuleName.WebAPI.Helpers
{
    public class HttpGlobalExceptionFilter : IExceptionFilter
    {
        private readonly ILogger<HttpGlobalExceptionFilter> logger;
        private readonly IConfiguration configuration;

        public HttpGlobalExceptionFilter(
            ILogger<HttpGlobalExceptionFilter> logger, IConfiguration configuration)
        {
            this.logger = logger;
            this.configuration = configuration;
        }

        public void OnException(ExceptionContext context)
        {
            logger.LogError(new EventId(context.Exception.HResult),
                context.Exception,
                context.Exception.Message);
            var errorModel = ExceptionExtensions.GetCustomErrorModel(context
                 , context.HttpContext.Request.Headers.RequestId
                 , "TraceId-"
                 , Convert.ToInt32(configuration["CustomerDeliverySlip_Error_Code"])
                 , configuration["BaseHelpUrl"]);

            context.Result = new ContentResult
            {
                Content = Newtonsoft.Json.JsonConvert.SerializeObject(errorModel),
                ContentType = "text/json",
                StatusCode = errorModel.Code
            };
            context.ExceptionHandled = true;
        }
    }

}
