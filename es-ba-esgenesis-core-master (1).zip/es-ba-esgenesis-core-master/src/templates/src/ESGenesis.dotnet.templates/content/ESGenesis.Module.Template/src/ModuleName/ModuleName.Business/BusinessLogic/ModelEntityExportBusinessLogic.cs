﻿// Licensed to the .NET Foundation under one or more agreements.
// The .NET Foundation licenses this file to you under the MIT license.

using ESGenesis.Core.Sdk.Authentication;
using ESGenesis.Core.Sdk.Helpers;
using ESGenesis.Core.Sdk.Models;
using ESGenesis.Core.Sdk.Pagination;
using ModuleName.Business.DataAccess.Entities;
using ModuleName.Business.DataAccess.Repositories;
using ModuleName.Models;
using Microsoft.Extensions.Logging;

namespace ModuleName.Business.BusinessLogic
{


    public interface IModelEntityExportBusinessLogic
    {
        Task<IBusinessResult<ModelEntityExportResultCode, byte[]>> ExportCsv(ModelEntityExportSearchProfile searchProfile);
    }

    public class ModelEntityExportBusinessLogic : IModelEntityExportBusinessLogic
    {
        private const string ExportDelimiter = ",";
        private const string ExportEscapeChar = "\"";
        private const string ExportEscapeCharReplacement = "\"\"";

        public static readonly IDictionary<ModelEntityExportResultCode, string> ErrorMessages = new Dictionary<ModelEntityExportResultCode, string>
                                                                                     {
                                                                                         { ModelEntityExportResultCode.None, string.Empty },
                                                                                         { ModelEntityExportResultCode.Success, string.Empty },
                                                                                         { ModelEntityExportResultCode.InvalidItem, "Invalid Item." },
                                                                                         { ModelEntityExportResultCode.ItemNotFound, "ModelEntity Not Found." },
                                                                                         { ModelEntityExportResultCode.AlreadyExists, "ModelEntity already exists." },
                                                                                         { ModelEntityExportResultCode.Error, "Unexpected error." },
                                                                                         { ModelEntityExportResultCode.DataValidationError, "Invalid Data Model." },
                                                                                         { ModelEntityExportResultCode.NullItemInput, "No access log was provided." },
                                                                                         { ModelEntityExportResultCode.ExportOverMax, "Export max record reached. Refine search criteria." },
                                                                                     };
        private readonly ILogger<ModelEntityExportBusinessLogic> logger;
        private readonly IModelEntityRepository animalRepository;
        private readonly ILoggedInUser loggedInUser;

        public ModelEntityExportBusinessLogic(ILogger<ModelEntityExportBusinessLogic> logger,
                                   IModelEntityRepository animalRepository,
                                   ILoggedInUser loggedInUser)
        {
            this.logger = logger;
            this.animalRepository = animalRepository;
            this.loggedInUser = loggedInUser;
        }
        public async Task<IBusinessResult<ModelEntityExportResultCode, byte[]>> ExportCsv(ModelEntityExportSearchProfile searchProfile)
        {
            if (searchProfile == null)
            {
                logger.LogCritical("ModelEntityExportBusinessLogic.ExportCsv error");

                return new BusinessResult<ModelEntityExportResultCode, byte[]>(false, ModelEntityExportResultCode.InvalidItem, null, ModelEntityExportResultCode.InvalidItem.ToString(), ErrorMessages[ModelEntityExportResultCode.InvalidItem]);
            }

            var modelValidationResult = DataAnnotationsHelper.ValidateModel(searchProfile);
            if (modelValidationResult.IsFailure == true)
            {
                logger.LogCritical("ModelEntityExportBusinessLogic.ExportCsv command model validation error");
                return new BusinessResult<ModelEntityExportResultCode, byte[]>(false, ModelEntityExportResultCode.InvalidItem, null, modelValidationResult.ErrorMessagesWithKeys);
            }

            List<ModelEntityExportResponse> animalExportResponses = new List<ModelEntityExportResponse>();

            var exportMax = 5000; //this._ApplicationConfiguration.ExportMax;

            try
            {
                Paging pagingParameter = new Paging();
                pagingParameter.SortColumn = "Id";
                pagingParameter.SortDirection = SortDirection.Ascending;

                var animalResponse = animalRepository.Search(pagingParameter, searchProfile.Keyword, searchProfile.NameSearchType, searchProfile.Name,  searchProfile.IncludeInActive);

                if (animalResponse != null && animalResponse.Count() > 0)
                {
                    animalResponse.Items.AsQueryable().GetPagedResult(                        animalResponse.Paging,
                        MapToModelEntityExportResponse);

                }
                else
                {
                    logger.LogError($"ModelEntityExportBusinessLogic.ExportCsv ModelEntity could not be found for profile: {searchProfile}", searchProfile);

                    return new BusinessResult<ModelEntityExportResultCode, byte[]>(false, ModelEntityExportResultCode.ItemNotFound, null, ModelEntityExportResultCode.ItemNotFound.ToString(), ErrorMessages[ModelEntityExportResultCode.ItemNotFound]);
                }
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "ModelEntityExportBusinessLogic.ExportCsv error: {0}", searchProfile);

                return new BusinessResult<ModelEntityExportResultCode, byte[]>(false, ModelEntityExportResultCode.Error, null, ModelEntityExportResultCode.Error.ToString(), ErrorMessages[ModelEntityExportResultCode.Error]);
            }

            var value = GenerateExportForApplicationSearch(animalExportResponses);

            return new BusinessResult<ModelEntityExportResultCode, byte[]>(true, ModelEntityExportResultCode.Success, value, null, null);
        }

        private ModelEntityExportResponse MapToModelEntityExportResponse(ModelEntity animalResponse)
        {
            ModelEntityExportResponse animalExportResponse = new ModelEntityExportResponse
            {
                Id = animalResponse.Id,
                Name = animalResponse.Name,                
            };

            return animalExportResponse;
        }

        public byte[] GenerateExportForApplicationSearch(List<ModelEntityExportResponse> transactionExportResponses)
        {
            var stream = new MemoryStream();
            var streamWriter = new StreamWriter(stream);
            streamWriter = MapSearchResultsToCsvExport(transactionExportResponses, streamWriter);
            streamWriter.Flush();

            return stream.ToArray();
        }

        private StreamWriter MapSearchResultsToCsvExport(IEnumerable<ModelEntityExportResponse> animalResponse, StreamWriter stream)
        {
            stream.WriteLine(string.Format("\"{0}\"[delimiter]\"{1}\"[delimiter]\"{2}\"",
                                           "Id",
                                           "CreatedDateTime",
                                           "Name")
                                   .Replace("[delimiter]", ExportDelimiter));
            foreach (var animal in animalResponse)
            {
                stream.WriteLine(string.Format("\"{0}\"[delimiter]\"{1}\"[delimiter]\"{2}\"[delimiter]\"{3}\"[delimiter]\"{4}\"[delimiter]\"{5}\"",
                                               EscapeTextInString(animal.Id.ToString()),
                                               EscapeTextInString(animal.CreatedDateTime.ToString()),
                                               EscapeTextInString(animal.Name))
                                       .Replace("[delimiter]", ExportDelimiter));
            }

            return stream;
        }

        private string EscapeTextInString(string value)
        {
            return value == null ? string.Empty : value.Replace(ExportEscapeChar, ExportEscapeCharReplacement);
        }
    }
}
