﻿// Licensed to the .NET Foundation under one or more agreements.
// The .NET Foundation licenses this file to you under the MIT license.

using System.ComponentModel.DataAnnotations;
using ESGenesis.Core.Sdk.Helpers;
using ESGenesis.Core.Sdk.Pagination;

namespace ModuleName.Models
{
    /// <summary>
    ///   The object that contains the parameters for searching ModelEntitys
    /// </summary>
    public class ModelEntityListProfile
    {
        /// <summary>
        ///   Initializes a new instance of the <see cref="ModelEntityListProfile" /> class.
        /// </summary>
        public ModelEntityListProfile()
        {
            //The Data Annotation of Default Value does not set the value as part of the constructor, so we have to set the default values this way.
            this.Start = 1;
            this.ResultCount = 20;
            this.SortColumn = "Id";
            this.SortOrder = SortDirection.Ascending;
        }

        /// <summary>
        ///   Keyword for searching a animal's name and description.
        ///   Default : &lt;blank&gt;
        /// </summary>
        public string? Keyword { get; set; }

        /// <summary>
        /// Name Search Type.
        /// Default : Equals
        /// </summary>
        public SearchComparerType NameSearchType { get; set; } = SearchComparerType.EqualTo;

        /// <summary>
        /// Name search.
        /// Default : &lt;blank&gt;
        /// </summary>
        public string? Name { get; set; }

        [Range(1, int.MaxValue, ErrorMessage = "You cannot Start before 1.")]
        public int Start { get; set; }

        /// <summary>
        ///   The number of records you would like to return.
        ///   The number must be between 1 and 200.
        ///   Default : 20
        ///   Example : 25 will get you 25 records in the result
        /// </summary>
        [Range(1, 200, ErrorMessage = "You cannot have a ResultCount that is less than 1 or greater than 200.")]
        public int ResultCount { get; set; }

        /// <summary>
        ///   The sort column that will be applied to your results.
        ///   Please refer to https://wiki.nov.com/display/RSIS/Sorting
        ///   Default : Id
        /// </summary>
        public required string SortColumn { get; set; }

        /// <summary>
        ///   The sort order that will be applied to your results.
        ///   Please refer to https://wiki.nov.com/display/RSIS/Sorting
        ///   Default : Ascending
        /// </summary>
        public required SortDirection SortOrder { get; set; }

        /// <summary>
        ///   Use True to return InActive and Active items.
        ///   False and Null will return only Active items.
        ///   Default : Null
        /// </summary>
        public bool? IncludeInActive { get; set; }
    }
}
