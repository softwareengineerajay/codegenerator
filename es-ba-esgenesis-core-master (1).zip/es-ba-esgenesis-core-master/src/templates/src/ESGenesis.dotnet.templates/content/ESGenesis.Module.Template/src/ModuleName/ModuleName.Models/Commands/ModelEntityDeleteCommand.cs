﻿// Licensed to the .NET Foundation under one or more agreements.
// The .NET Foundation licenses this file to you under the MIT license.

using ESGenesis.Core.Sdk.CQRS.Commands;

namespace ModuleName.Models.Commands
{
    public class ModelEntityDeleteCommand
        : ICommand<bool>
    {
        public int ModelEntityId { get; private set; }
        public ModelEntityDeleteCommand(int animalId)
            : base()
        {
            this.ModelEntityId = animalId;
        }
    }
}
