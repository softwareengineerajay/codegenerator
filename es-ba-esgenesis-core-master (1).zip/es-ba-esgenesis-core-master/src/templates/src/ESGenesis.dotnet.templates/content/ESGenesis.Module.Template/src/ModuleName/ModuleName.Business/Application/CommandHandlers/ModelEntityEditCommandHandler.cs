﻿// Licensed to the .NET Foundation under one or more agreements.
// The .NET Foundation licenses this file to you under the MIT license.

using AutoMapper;
using ESGenesis.Core.Sdk.CQRS.Commands;
using ModuleName.Business.BusinessLogic;
using ModuleName.Models.Commands;
using Microsoft.Extensions.Logging;

namespace ModuleName.Business.Application.CommandHandlers
{
    public class ModelEntityEditCommandHandler
        : ICommandHandler<ModelEntityEditCommand, bool>
    {
        private readonly ILogger<ModelEntityEditCommandHandler> logger;
        private readonly IMapper mapper;
        private readonly IModelEntityBusinessLogic animalService;

        public ModelEntityEditCommandHandler(
            ILogger<ModelEntityEditCommandHandler> logger
            , IMapper mapper
            , IModelEntityBusinessLogic animalService)
        {
            this.logger = logger;
            this.mapper = mapper;
            this.animalService = animalService;
        }

        public async Task<bool> Handle(ModelEntityEditCommand request, CancellationToken cancellationToken)
        {
            if (request == null) throw new ArgumentException(nameof(request));

            logger.LogInformation($"----- Edit animal record Request: {request}");

            var response = await animalService.EditAsync(request.ModelEntityEditCommandModel);

            if (response == null || response.IsSuccessful == false)
            {
                throw new Exception("Failed to update animal record.");
            }

            return true;
        }
    }
}
