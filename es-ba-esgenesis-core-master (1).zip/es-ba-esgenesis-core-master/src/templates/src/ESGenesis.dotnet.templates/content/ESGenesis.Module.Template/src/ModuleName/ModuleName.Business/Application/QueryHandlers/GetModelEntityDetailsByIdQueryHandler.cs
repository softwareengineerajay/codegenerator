﻿// Licensed to the .NET Foundation under one or more agreements.
// The .NET Foundation licenses this file to you under the MIT license.

using AutoMapper;
using ESGenesis.Core.Sdk.CQRS.Queries;
using ModuleName.Business.DataAccess.Entities;
using ModuleName.Business.DataAccess.Repositories;
using ModuleName.Models;
using ModuleName.Models.Queries;
using Microsoft.Extensions.Logging;

namespace ModuleName.Business.Application.QueryHandlers
{
    public class GetModelEntityDetailsByIdQueryHandler
        : IQueryHandler<GetModelEntityDetailsByIdQuery, ModelEntityResponse>
    {
        private readonly ILogger<GetModelEntityDetailsByIdQueryHandler> logger;
        private readonly IMapper mapper;
        private readonly IModelEntityRepository animalRepository;

        public GetModelEntityDetailsByIdQueryHandler(
            ILogger<GetModelEntityDetailsByIdQueryHandler> logger,
            IMapper mapper,
            IModelEntityRepository animalRepository)
        {
            this.logger = logger;
            this.mapper = mapper;
            this.animalRepository = animalRepository;
        }

        public async Task<ModelEntityResponse> Handle(GetModelEntityDetailsByIdQuery request, CancellationToken cancellationToken)
        {
            if (request == null) throw new ArgumentException(nameof(request));

            logger.LogInformation($"----- Get ModelEntity Details By Id QueryHandler Request: {request}");

            var result = animalRepository.GetById(request.Id);

            if (result == null)
            {
                logger.LogWarning($"----- Get ModelEntity Details By Id QueryHandler Request: {request} - Not Found");
                return null;
            }

            var animalResponse = this.mapper.Map<ModelEntity, ModelEntityResponse>(result);

            return animalResponse;

        }
    }
}
