﻿// Licensed to the .NET Foundation under one or more agreements.
// The .NET Foundation licenses this file to you under the MIT license.

namespace ModuleName.Models
{
    /// <summary>
    ///   The response that will contain the list of animals from the request and the total number of results
    ///   found.
    /// </summary>
    public class ModelEntitysResponse
    {
        /// <summary>
        ///   Gets or sets the list of animals that are returned as part of the request
        /// </summary>
        public IEnumerable<ModelEntityResponse> ModelEntitys { get; set; }
    }
}
