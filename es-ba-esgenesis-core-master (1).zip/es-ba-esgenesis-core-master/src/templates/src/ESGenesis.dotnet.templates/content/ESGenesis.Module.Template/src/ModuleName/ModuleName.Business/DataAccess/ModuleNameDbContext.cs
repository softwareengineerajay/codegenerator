﻿using ESGenesis.Core.Sdk.Authentication;
using ESGenesis.Core.Sdk.Data;
using ModuleName.Business.DataAccess.Configurations;
using ModuleName.Business.DataAccess.Entities;
using Microsoft.EntityFrameworkCore;

namespace ModuleName.Business.DataAccess
{
    public class ModuleNameDbContext : BaseContext
    {
        internal const string ModuleSchemaName = "ModuleName";

        public ModuleNameDbContext(DbContextOptions<ModuleNameDbContext> dbContextOptions
            , ILoggedInUser loggedInUser)
            : base(dbContextOptions, loggedInUser)
        {
        }

        public DbSet<ModelEntity> ModelEntitys { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.ApplyConfiguration(new ModelEntityConfiguration());
            base.OnModelCreating(modelBuilder);
        }
    }
}
