﻿// Licensed to the .NET Foundation under one or more agreements.
// The .NET Foundation licenses this file to you under the MIT license.

using ESGenesis.Core.Sdk.CQRS.Commands;
using Microsoft.AspNetCore.Mvc;

namespace ModuleName.Models.Commands
{
    public class ModelEntityCreateCommand
        : ICommand<ModelEntityCreateResponse>
    {
        public ModelEntityCreateCommandModel ModelEntityCreateCommandModel { get; private set; }
        public ModelEntityCreateCommand(ModelEntityCreateCommandModel animalCreateCommandModel)
            : base()
        {
            ModelEntityCreateCommandModel = animalCreateCommandModel;
        }
    }
}
