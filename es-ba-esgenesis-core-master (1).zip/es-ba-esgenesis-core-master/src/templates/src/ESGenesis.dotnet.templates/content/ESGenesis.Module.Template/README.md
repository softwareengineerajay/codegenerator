AppShortCode - ModuleName  

Add below relevent entries in main docker compose file

  nov.es.appshortcode.modulename.webapi:
    image: ghcr.io/nationaloilwellvarco/appshortcode-backend/nov.es.appshortcode.modulename.webapi:${TAG}
    build:
      context: .
      dockerfile: Modules/ModuleName/src/ModuleName/ModuleName.WebAPI/Dockerfile

  nov.es.appshortcode.modulename.worker:
    image: ghcr.io/nationaloilwellvarco/appshortcode-backend/nov.es.appshortcode.modulename.worker:${TAG}
    build:
      context: .
      dockerfile: Modules/ModuleName/src/ModuleName/ModuleName.Worker/Dockerfile

Add below relevent entries in github workflow *cicd.yml

      # modulename - detect file changed
      - uses: marceloprado/has-changed-path@v1.0.1
        id: modulename
        with:
          paths: src/Modules/ModuleName

      - name: modulename webapi
        if: steps.modulename.outputs.changed == 'true'
        run: |
          echo "SERVICESTOBUILD=$SERVICESTOBUILD{\"run\":\"src/Modules/ModuleName/deploymentinputjson/modulename-webapi-service.json\"}," >> $GITHUB_ENV
          echo "HASCHANGED=1" >> $GITHUB_ENV

      - name: modulename worker
        if: steps.modulename.outputs.changed == 'true'
        run: |
          echo "SERVICESTOBUILD=$SERVICESTOBUILD{\"run\":\"src/Modules/ModuleName/deploymentinputjson/modulename-worker-service.json\"}," >> $GITHUB_ENV
          echo "HASCHANGED=1" >> $GITHUB_ENV
		  
Add below relevent entries in github workflow *all.yml before this line # Close services to be build matrix json

      # modulename
      - name: modulename webapi
        run: |
          echo "SERVICESTOBUILD=$SERVICESTOBUILD{\"run\":\"src/Modules/ModuleName/deploymentinputjson/modulename-webapi-service.json\"}," >> $GITHUB_ENV
          echo "HASCHANGED=1" >> $GITHUB_ENV

      - name: modulename worker
        run: |
          echo "SERVICESTOBUILD=$SERVICESTOBUILD{\"run\":\"src/Modules/ModuleName/deploymentinputjson/modulename-worker-service.json\"}," >> $GITHUB_ENV
          echo "HASCHANGED=1" >> $GITHUB_ENV
