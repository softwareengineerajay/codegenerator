﻿// Licensed to the .NET Foundation under one or more agreements.
// The .NET Foundation licenses this file to you under the MIT license.

namespace ModuleName.Models
{
    public enum ModelEntityExportResultCode
    {
        None,
        Success,
        Error,
        NotFound,
        AlreadyExists,
        InvalidItem,
        ItemNotFound,
        NullItemInput,
        DataValidationError,        
        ExportOverMax
    }
}
