﻿// Licensed to the .NET Foundation under one or more agreements.
// The .NET Foundation licenses this file to you under the MIT license.

using AutoMapper;
using ESGenesis.Core.Sdk.CQRS.Queries;
using ModuleName.Business.DataAccess.Entities;
using ModuleName.Business.DataAccess.Repositories;
using ModuleName.Models.Queries;
using ModuleName.Models;
using Microsoft.Extensions.Logging;
using ESGenesis.Core.Sdk.Pagination;

namespace ModuleName.Business.Application.QueryHandlers
{
    public class GetModelEntitysQueryHandler
        : IQueryHandler<GetModelEntitysQuery, ModelEntitysResponse>
    {
        private readonly ILogger<GetModelEntitysQueryHandler> logger;
        private readonly IMapper mapper;
        private readonly IModelEntityRepository animalRepository;

        public GetModelEntitysQueryHandler(
            ILogger<GetModelEntitysQueryHandler> logger,
            IMapper mapper,
            IModelEntityRepository animalRepository)
        {
            this.logger = logger;
            this.mapper = mapper;
            this.animalRepository = animalRepository;
        }

        public async Task<ModelEntitysResponse> Handle(GetModelEntitysQuery request, CancellationToken cancellationToken)
        {
            if (request == null) throw new ArgumentException(nameof(request));

            logger.LogInformation($"----- Get ModelEntity Details By Id QueryHandler Request: {request}");

            Paging pagingParameter = new Paging();
            pagingParameter.SortColumn = request.ModelEntityListProfile.SortColumn;
            pagingParameter.SortDirection = request.ModelEntityListProfile.SortOrder;

            var result = animalRepository.Search(pagingParameter,
                request.ModelEntityListProfile.Keyword,
                request.ModelEntityListProfile.NameSearchType,
                request.ModelEntityListProfile.Name,
                request.ModelEntityListProfile.IncludeInActive);

            if (result == null)
            {
                logger.LogWarning($"----- Get ModelEntity Details By Id QueryHandler Request: {request} - Not Found");
                return null;
            }

            var animalsResponse = this.mapper.Map<PagedResult<ModelEntity>, ModelEntitysResponse>(result);

            return animalsResponse;

        }
    }
}
