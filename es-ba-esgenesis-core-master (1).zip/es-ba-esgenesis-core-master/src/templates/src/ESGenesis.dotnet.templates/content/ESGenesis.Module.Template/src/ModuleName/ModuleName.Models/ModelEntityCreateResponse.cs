﻿// Licensed to the .NET Foundation under one or more agreements.
// The .NET Foundation licenses this file to you under the MIT license.

namespace ModuleName.Models
{
    public class ModelEntityCreateResponse
    {
        /// <summary>
        ///   A link to get the ModelEntity  by Id
        /// </summary>
        public string ModelEntityUri { get; set; }
    }
}
