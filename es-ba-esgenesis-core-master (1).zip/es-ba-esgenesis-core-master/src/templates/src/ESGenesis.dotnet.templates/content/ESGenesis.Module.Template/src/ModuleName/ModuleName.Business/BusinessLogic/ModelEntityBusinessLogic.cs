﻿// Licensed to the .NET Foundation under one or more agreements.
// The .NET Foundation licenses this file to you under the MIT license.

using ESGenesis.Core.Sdk.Authentication;
using ESGenesis.Core.Sdk.Helpers;
using ESGenesis.Core.Sdk.Models;
using ModuleName.Business.DataAccess.Entities;
using ModuleName.Business.DataAccess.Repositories;
using ModuleName.Models;
using Microsoft.Extensions.Logging;

namespace ModuleName.Business.BusinessLogic
{

    public interface IModelEntityBusinessLogic
    {
        Task<IBusinessResult<ModelEntityResultCode, ModelEntity>> CreateAsyn(ModelEntityCreateCommandModel commandModel);
        Task<IBusinessResult<ModelEntityResultCode, ModelEntity>> EditAsync(ModelEntityEditCommandModel commandModel);
        Task<IBusinessResult<ModelEntityResultCode, ModelEntity>> DeleteAsync(int id);
    }

    public partial class ModelEntityBusinessLogic
        : IModelEntityBusinessLogic
    {
        public static readonly IDictionary<ModelEntityResultCode, string> ErrorMessages = new Dictionary<ModelEntityResultCode, string>
                                                                                     {
                                                                                         { ModelEntityResultCode.None, string.Empty },
                                                                                         { ModelEntityResultCode.Success, string.Empty },
                                                                                         { ModelEntityResultCode.InvalidItem, "Invalid Item." },
                                                                                         { ModelEntityResultCode.ItemNotFound, "ModelEntity Not Found." },
                                                                                         { ModelEntityResultCode.AlreadyExists, "ModelEntity already exists." },
                                                                                         { ModelEntityResultCode.Error, "Unexpected error." },
                                                                                         { ModelEntityResultCode.DataValidationError, "Invalid Data Model." },
                                                                                         { ModelEntityResultCode.NullItemInput, "No access log was provided." },
                                                                                     };

        private readonly ILogger<ModelEntityBusinessLogic> logger;
        private readonly IModelEntityRepository animalRepository;
        private readonly ILoggedInUser loggedInUser;

        public ModelEntityBusinessLogic(ILogger<ModelEntityBusinessLogic> logger,
                                   IModelEntityRepository animalRepository,
                                   ILoggedInUser loggedInUser)
        {
            this.logger = logger;
            this.animalRepository = animalRepository;
            this.loggedInUser = loggedInUser;
        }

        public async Task<IBusinessResult<ModelEntityResultCode, ModelEntity>> CreateAsyn(ModelEntityCreateCommandModel createCommandModel)
        {
            if (createCommandModel == null)
            {
                logger.LogCritical(new ArgumentNullException(nameof(createCommandModel)), "ModelEntityBusinessLogic.Create error");

                return new BusinessResult<ModelEntityResultCode, ModelEntity>(false, ModelEntityResultCode.NullItemInput, null, ModelEntityResultCode.NullItemInput.ToString(), ErrorMessages[ModelEntityResultCode.NullItemInput]);
            }

            var modelValidationResult = DataAnnotationsHelper.ValidateModel(createCommandModel);
            if (modelValidationResult.IsFailure == true)
            {
                logger.LogCritical(new ArgumentNullException(nameof(createCommandModel)), "ModelEntityBusinessLogic.Create command model validation error: {0}", createCommandModel);

                return new BusinessResult<ModelEntityResultCode, ModelEntity>(false, ModelEntityResultCode.DataValidationError, null, modelValidationResult.ErrorMessagesWithKeys);
            }

            try
            {
                //  check if there is already a ModelEntity record
                var alreadyExist = await animalRepository.DoesModelEntityAlreadyExistAsync(createCommandModel.Name);
                if (alreadyExist)
                {
                    return new BusinessResult<ModelEntityResultCode, ModelEntity>(false, ModelEntityResultCode.AlreadyExists, null, ModelEntityResultCode.AlreadyExists.ToString(), ErrorMessages[ModelEntityResultCode.AlreadyExists]);
                }


                var item = MapForCreate(createCommandModel);

                await animalRepository.AddAsync(item);


                return new BusinessResult<ModelEntityResultCode, ModelEntity>(true, ModelEntityResultCode.Success, item, "", "");
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "ModelEntityBusinessLogic.Create command model validation error: {0}", createCommandModel);
                return new BusinessResult<ModelEntityResultCode, ModelEntity>(false, ModelEntityResultCode.Error, null, ModelEntityResultCode.Error.ToString(), ErrorMessages[ModelEntityResultCode.Error]);
            }
        }
        public async Task<IBusinessResult<ModelEntityResultCode, ModelEntity>> EditAsync(ModelEntityEditCommandModel editCommandModel)
        {
            if (editCommandModel == null)
            {
                logger.LogCritical(new ArgumentNullException(nameof(editCommandModel)), "ModelEntityBusinessLogic.Edit error");

                return new BusinessResult<ModelEntityResultCode, ModelEntity>(false, ModelEntityResultCode.NullItemInput, null, ModelEntityResultCode.NullItemInput.ToString(), ErrorMessages[ModelEntityResultCode.NullItemInput]);
            }

            var modelValidationResult = DataAnnotationsHelper.ValidateModel(editCommandModel);
            if (modelValidationResult.IsFailure == true)
            {
                logger.LogWarning(new ArgumentNullException(nameof(editCommandModel)), "ModelEntityBusinessLogic.Edit command model validation error {0}", editCommandModel);

                return new BusinessResult<ModelEntityResultCode, ModelEntity>(false, ModelEntityResultCode.DataValidationError, null, modelValidationResult.ErrorMessagesWithKeys);
            }

            try
            {
                //var currentLoginId = this._ApplicationUserInfo.CurrentLoginId;
                //if (currentLoginId.HasValue == false)
                //{
                //    return new BusinessResult<ModelEntityResultCode, ModelEntity>(false, ModelEntityResultCode.UserNotFound, null, ModelEntityResultCode.UserNotFound.ToString(), ModelEntityBusinessLogic.ErrorMessages[ModelEntityResultCode.UserNotFound]);
                //}

                //  Get ModelEntity based on Id
                var existingModelEntityEntity = await animalRepository.GetDetailsAsync(editCommandModel.Id);
                if (existingModelEntityEntity == null)
                {
                    return new BusinessResult<ModelEntityResultCode, ModelEntity>(false, ModelEntityResultCode.ItemNotFound, null, ModelEntityResultCode.ItemNotFound.ToString(), ErrorMessages[ModelEntityResultCode.ItemNotFound]);
                }

                // If we are changing the name, verify that animal doesn't already exist
                if (editCommandModel.Name != existingModelEntityEntity.Name)
                {
                    var animalWithNameAlreadyExist = await animalRepository.DoesModelEntityAlreadyExistAsync(editCommandModel.Name);
                    if (animalWithNameAlreadyExist)
                    {
                        return new BusinessResult<ModelEntityResultCode, ModelEntity>(false, ModelEntityResultCode.AlreadyExists, null, ModelEntityResultCode.AlreadyExists.ToString(), ErrorMessages[ModelEntityResultCode.AlreadyExists]);
                    }
                }

                // Update entity from model
                MapForEdit(editCommandModel, existingModelEntityEntity);

                //existingModelEntityEntity.UpdatedByLoginId = currentLoginId.Value;
                //existingModelEntityEntity.UpdatedDateTime = DateTimeOffset.Now;

                //this._ModelEntityDataService.SaveChanges();
                await animalRepository.SaveChangesAsync();

                return new BusinessResult<ModelEntityResultCode, ModelEntity>(true, ModelEntityResultCode.Success, existingModelEntityEntity, "", "");
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "ModelEntityBusinessLogic.Edit command model validation error: {0}", editCommandModel);
                return new BusinessResult<ModelEntityResultCode, ModelEntity>(false, ModelEntityResultCode.Error, null, ModelEntityResultCode.Error.ToString(), ErrorMessages[ModelEntityResultCode.Error]);
            }
        }

        public async Task<IBusinessResult<ModelEntityResultCode, ModelEntity>> DeleteAsync(int id)
        {
            if (id < 1)
            {
                logger.LogCritical(new ArgumentNullException(nameof(id)), "ModelEntityBusinessLogic.Delete null item input error");
                return new BusinessResult<ModelEntityResultCode, ModelEntity>(false, ModelEntityResultCode.InvalidItem, null, ModelEntityResultCode.InvalidItem.ToString(), ErrorMessages[ModelEntityResultCode.InvalidItem]);
            }

            try
            {
                //var currentLoginId = this.loggedInUser?.EmailId;
                //if (currentLoginId.HasValue == false)
                //{
                //    this._RigIsLogger.LogError("ModelEntityBusinessLogic.Delete user not found error", new ArgumentNullException(nameof(id)), ErrorSeverity.Critical);
                //    return new BusinessResult<ModelEntityResultCode, ModelEntity>(false, ModelEntityResultCode.UserNotFound, null, ModelEntityResultCode.UserNotFound.ToString(), ModelEntityService.ErrorMessages[ModelEntityResultCode.UserNotFound]);
                //}

                //  Get ModelEntity based on Id
                var existingModelEntityEntity = await animalRepository.GetDetailsAsync(id);
                if (existingModelEntityEntity == null)
                {
                    logger.LogCritical(new ArgumentNullException(nameof(id)), "ModelEntityBusinessLogic.Delete item not found error");
                    return new BusinessResult<ModelEntityResultCode, ModelEntity>(false, ModelEntityResultCode.ItemNotFound, null, ModelEntityResultCode.ItemNotFound.ToString(), ErrorMessages[ModelEntityResultCode.ItemNotFound]);
                }

                // Update entity from model
                MapForDelete(existingModelEntityEntity);

                await animalRepository.SaveChangesAsync();

                return new BusinessResult<ModelEntityResultCode, ModelEntity>(true, ModelEntityResultCode.Success, existingModelEntityEntity, "", "");
            }
            catch (Exception exception)
            {
                logger.LogError(exception, "ModelEntityBusinessLogic.Delete error: {0}", id);
                return new BusinessResult<ModelEntityResultCode, ModelEntity>(false, ModelEntityResultCode.Error, null, ModelEntityResultCode.Error.ToString(), ErrorMessages[ModelEntityResultCode.Error]);
            }
        }

        private ModelEntity MapForCreate(ModelEntityCreateCommandModel createCommandModel)
        {
            var now = DateTimeOffset.Now;

            return new ModelEntity
            {
                Name = createCommandModel.Name,                
            };
        }

        private void MapForEdit(ModelEntityEditCommandModel source, ModelEntity target)
        {
            target.Name = source.Name;
        }

        private void MapForDelete(ModelEntity model)
        {
            model.IsActive = false;
        }
    }
}
