﻿// Licensed to the .NET Foundation under one or more agreements.
// The .NET Foundation licenses this file to you under the MIT license.

using ESGenesis.Core.Sdk.Authentication;
using Microsoft.Extensions.Logging;

namespace ModuleName.Worker
{
    public interface IWorkerService
    {
        void RunWorkers();
    }
    public class WorkerService : IWorkerService
    {
        private readonly ILogger<WorkerService> logger;
        private readonly ILoggedInUser loggedInUser;

        public WorkerService(ILogger<WorkerService> logger, ILoggedInUser loggedInUser)
        {
            this.logger = logger;
            this.loggedInUser = loggedInUser;
        }

        public void RunWorkers()
        {
            Console.WriteLine("Worker Service is running");
            try
            {
                AppDomain.CurrentDomain.ProcessExit += (s, e) =>
                {
                    Console.WriteLine("Exiting");

                    //if (connection.IsOpen == true)
                    //{
                    //    connection.Close();
                    //    Console.WriteLine("ModelEntity Import Worker Connection has been closed");
                    //}
                    //else
                    //{
                    //    Console.WriteLine("ModelEntity Import Worker Connection was already closed");
                    //}
                };

                this.logger.LogInformation($"ModelEntityImportWorker Started : {DateTime.Now}");

            }
            catch (Exception ex)
            {
                logger.LogError(ex, "Error in Worker Service");
            }
        }
    }
}
