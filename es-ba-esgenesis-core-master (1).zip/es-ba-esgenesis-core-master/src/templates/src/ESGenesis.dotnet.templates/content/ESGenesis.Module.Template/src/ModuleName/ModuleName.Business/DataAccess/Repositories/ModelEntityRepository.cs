﻿// Licensed to the .NET Foundation under one or more agreements.
// The .NET Foundation licenses this file to you under the MIT license.

using System.Linq;
using ESGenesis.Core.Sdk.Data;
using ESGenesis.Core.Sdk.Data.Repositories;
using ESGenesis.Core.Sdk.Data.Repository;
using ESGenesis.Core.Sdk.Helpers;
using ESGenesis.Core.Sdk.Pagination;
using ModuleName.Business.DataAccess.Entities;
using Microsoft.EntityFrameworkCore;

namespace ModuleName.Business.DataAccess.Repositories
{
    public interface IModelEntityRepository
        : IReadRepository<ModelEntity>, IWriteDbRepository<ModelEntity>
    {
        Task<ModelEntity> GetDetailsAsync(int id);
        PagedResult<ModelEntity> Search(Paging parameters, string keyword, SearchComparerType nameSearchType, string name, bool? includeInActive);
        Task<ModelEntity> AddAsync(ModelEntity item);        
        Task<bool> DoesModelEntityAlreadyExistAsync(string name);
    }

    public class ModelEntityRepository
        : GenericRepository<ModelEntity>, IModelEntityRepository
    {
        private readonly ModuleNameDbContext dbContext;

        public ModelEntityRepository(ModuleNameDbContext dbContext)
            : base(dbContext)
        {
            this.dbContext = dbContext;
        }

        
        public async Task<bool> DoesModelEntityAlreadyExistAsync(string name)
        {
            if (string.IsNullOrWhiteSpace(name) == false)
            {
                return false;
            }

            var filter = PredicateBuilder.Create<ModelEntity>(x => x.IsActive);
            filter = filter.And(x => x.Name == name);

            var result = await this.GetExistsAsync(filter);
            return result;
        }
        public async Task<ModelEntity> GetDetailsAsync(int id)
        {
            return await this.GetOneAsync(x => x.Id == id);
        }

        public async Task<ModelEntity> AddAsync(ModelEntity item)
        {
            this.Create(item);
            await this.SaveChangesAsync();
            return item;
        }

        public PagedResult<ModelEntity> Search(Paging parameters, string keyword, SearchComparerType nameSearchType, string name, bool? includeInActive)
        {
            var filter = PredicateBuilder.True<ModelEntity>();
            if (string.IsNullOrWhiteSpace(keyword) == false)
            {
                var containsKeyword = $"%{keyword}%";
                var nameFilter = PredicateBuilder.False<ModelEntity>()
                                                 .Or(animal => EF.Functions.Like(animal.Name, containsKeyword));

                filter = filter.And(nameFilter);
            }


            if (string.IsNullOrWhiteSpace(name) == false)
            {
                switch (nameSearchType)
                {
                    case SearchComparerType.EqualTo:
                        filter = filter.And(animal => animal.Name == name);
                        break;

                    case SearchComparerType.Contains:

                        var containsValue = $"%{name}%";
                        var containsvalueFilter = PredicateBuilder.False<ModelEntity>()
                            .Or(animal => EF.Functions.Like(animal.Name, containsValue));
                        filter = filter.And(containsvalueFilter);
                        break;

                    case SearchComparerType.BeginsWith:
                        var beginWithValue = $"{name}%";
                        var beginWithValueFilter = PredicateBuilder.False<ModelEntity>()
                            .Or(animal => EF.Functions.Like(animal.Name, beginWithValue));
                        filter = filter.And(beginWithValueFilter);
                        break;

                    case SearchComparerType.EndsWith:
                        var endsWithValue = $"%{name}";
                        var endsWithValueFilter = PredicateBuilder.False<ModelEntity>()
                            .Or(animal => EF.Functions.Like(animal.Name, endsWithValue));
                        filter = filter.And(endsWithValueFilter);
                        break;

                    case SearchComparerType.NotEqualTo:
                        filter = filter.And(animal => animal.Name != name);
                        break;
                }
            }
            if (includeInActive == null || includeInActive == false)
            {
                filter = filter.And(animal => animal.IsActive == true);
            }

            var queryResult = this.dbContext.ModelEntitys.AsQueryable().Where(filter);
            var pagingResult = PagingExtensions.GetPagedResult(queryResult, parameters);
            return pagingResult;
        }
    }
}
