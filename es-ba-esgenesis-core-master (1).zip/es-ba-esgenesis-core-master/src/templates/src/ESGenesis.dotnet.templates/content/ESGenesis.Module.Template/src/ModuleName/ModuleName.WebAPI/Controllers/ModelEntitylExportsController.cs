﻿using ESGenesis.Core.Sdk.CQRS.Commands;
using ESGenesis.Core.Sdk.CQRS.Queries;
using ESGenesis.Core.Sdk.Models;
using ModuleName.Models;
using ModuleName.Models.Queries;
using Microsoft.AspNetCore.Mvc;

namespace ModuleName.WebAPI.Controllers
{

    /// <summary>
    ///   ModelEntityExport API Controller
    /// </summary>
    [ApiVersion("1")]
    [Route("api/v{version:apiVersion}/[controller]")]
    [ApiController]
    public class ModelEntityExportsController : ControllerBase
    {
        private const string DelimiterType = "text/csv";

        private readonly ILogger<ModelEntityExportsController> logger;
        private readonly IQueryBus queryBus;

        public ModelEntityExportsController(
            ILogger<ModelEntityExportsController> logger,
            IQueryBus queryBus)
        {
            this.logger = logger;
            this.queryBus = queryBus;
        }

        /// <summary>
        /// This method returns service name.
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("ServiceName")]
        public IActionResult ServiceName()
        {
            return Ok("ModelEntity Export Service. ");
        }

        /// <summary>
        ///   Get method to export animals with max limit of 5000
        /// </summary>
        /// <remarks>
        ///   Sample request:
        ///   GET /ModelEntityExports?Keyword=1
        /// </remarks>
        /// <param name="exportSearchProfile"></param>
        /// <returns name="ModelEntitysResponse">List of animals in csv format.</returns>
        /// <response code="200">The list of animals found with parameters given.</response>
        /// <response code="204">No animal could be found with parameters.</response>
        /// <response code="400">A Bad Request was sent. The Response will contain the error messages.</response>
        /// <response code="401">Not Authorized. You need to be authorized to use the API.</response>
        /// <response code="404">Not Found. Resource is not found on the server</response>
        [HttpGet]
        [ProducesResponseType(typeof(byte[]), 200)]
        [ProducesResponseType(400)]
        [ProducesResponseType(404)]
        public ActionResult Get([FromQuery] ModelEntityExportSearchProfile exportSearchProfile)
        {
            var query = new ExportModelEntitysQuery(exportSearchProfile);
            var result = this.queryBus.Send<ExportModelEntitysQuery, IBusinessResult<ModelEntityExportResultCode, byte[]>>(query).Result;
            if (result.IsSuccessful == false || result.Result == null)
            {
                return this.BadRequest(result.ErrorMessages);
            }

            var fileName = String.Format("ModelEntitys_{0}.csv", DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"));
            return this.File(result.Result, ModelEntityExportsController.DelimiterType, fileName);
        }
    }
}
