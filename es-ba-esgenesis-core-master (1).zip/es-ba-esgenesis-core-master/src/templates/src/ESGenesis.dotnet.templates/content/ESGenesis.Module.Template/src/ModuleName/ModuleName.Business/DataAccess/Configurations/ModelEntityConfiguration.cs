﻿// Licensed to the .NET Foundation under one or more agreements.
// The .NET Foundation licenses this file to you under the MIT license.

using ModuleName.Business.DataAccess.Entities;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore;

namespace ModuleName.Business.DataAccess.Configurations
{
    internal class ModelEntityConfiguration : IEntityTypeConfiguration<ModelEntity>
    {
        public void Configure(EntityTypeBuilder<ModelEntity> builder)
        {
            builder.ToTable("ModelEntity", ModuleNameDbContext.ModuleSchemaName);
            builder.HasKey(x => x.Id);
            builder.Property(x => x.Id).ValueGeneratedOnAdd();
            builder.Property(x => x.IsActive).HasDefaultValueSql("1");
            builder.Property(x => x.DateCreated).HasDefaultValueSql("GETUTCDATE()");
            builder.Property(x => x.DateModified).HasDefaultValueSql("GETUTCDATE()");
        }
    }
}
