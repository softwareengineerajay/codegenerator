﻿using ESGenesis.Core.Sdk.Helpers;

namespace ModuleName.Models
{
    public class ModelEntityExportSearchProfile
    {
        /// <summary>
        ///   Keyword for searching a animal's name and description.
        ///   Default : &lt;blank&gt;
        public string? Keyword { get; set; }

        /// <summary>
        /// Name Search Type.
        /// Default : Equals
        public SearchComparerType NameSearchType { get; set; } = SearchComparerType.EqualTo;

        /// <summary>
        /// Name search.
        /// Default : &lt;blank&gt;
        public string? Name { get; set; }

        /// <summary>
        ///   Use True to return InActive and Active items.
        ///   False and Null will return only Active items.
        ///   Default : Null
        /// </summary>
        public bool? IncludeInActive { get; set; }
    }

}
