﻿// Licensed to the .NET Foundation under one or more agreements.
// The .NET Foundation licenses this file to you under the MIT license.

using ESGenesis.Core.Sdk.CQRS.Queries;

namespace ModuleName.Models.Queries
{
    public class GetModelEntitysQuery : IQuery<ModelEntitysResponse>
    {
        public ModelEntityListProfile ModelEntityListProfile { get; private set; }
        public GetModelEntitysQuery(ModelEntityListProfile animalListProfile)
        {
            this.ModelEntityListProfile = animalListProfile;
        }
    }
}
