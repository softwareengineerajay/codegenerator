﻿// Licensed to the .NET Foundation under one or more agreements.
// The .NET Foundation licenses this file to you under the MIT license.

using Elastic.Apm.SerilogEnricher;
using Elastic.CommonSchema.Serilog;
using ESGenesis.Core.Sdk.Authentication;
using ModuleName.Worker;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Serilog;
using Serilog.Exceptions;
using Serilog.Exceptions.Core;
using Serilog.Exceptions.EntityFrameworkCore.Destructurers;
using Serilog.Sinks.Elasticsearch;

Console.WriteLine("ModuleName Worker!");

try
{
    Console.WriteLine("Creating Application Host Builder");

    var host = CreateAppHostBuilder(args);

    Serilog.Log.Information("---------------------------------------------------------------------");
    Serilog.Log.Information("ModuleName worker console application starting");

    #region Collect and display the environment variables
    if (args == null)
    {
        Serilog.Log.Information("No command line argument found");
    }
    else
    {
        foreach (string arg in args)
        {
            Console.WriteLine("\t{0}", arg);
        }
    }
    #endregion

    #region Service Account ILoggedInUser
    Serilog.Log.Information("Getting ILoggedInUser Instance.");
    ILoggedInUser loggedInUser = host.Services.GetRequiredService<ILoggedInUser>();
    if (loggedInUser == null)
    {
        Serilog.Log.Information("ILoggedInUser is null");
        loggedInUser = new LoggedInUser();
    }
    loggedInUser.IsExternalApp = false;
    loggedInUser.EmailId = "ModuleName.Worker@nov.com";
    #endregion

    host.Services.GetRequiredService<IWorkerService>().RunWorkers(); 

    Serilog.Log.Information("ModuleName worker console application finished");
    Serilog.Log.Information("---------------------------------------------------------------------");

}
catch (Exception ex)
{
    string type = ex.GetType().Name;
    if (type.Equals("StopTheHostException", StringComparison.Ordinal))
    {
        throw;
    }
    Serilog.Log.Fatal(ex, "Program terminated unexpectedly ({ApplicationContext})!", Program.AppName);
}
finally
{
    Console.WriteLine("ModuleName Worker is shutting down.");
    Serilog.Log.CloseAndFlush();
}
IHost CreateAppHostBuilder(string[] args)
{


return Host.CreateDefaultBuilder(args)
    .ConfigureServices((hostingContext, services) =>
{

services.Configure<HostOptions>(hostOptions =>
{
hostOptions.BackgroundServiceExceptionBehavior = BackgroundServiceExceptionBehavior.Ignore;
});

var configuration = hostingContext.Configuration;
services
.AddCustomDbContext(configuration)
.AddWorkerDomainCoreDependecy();
})
    .ConfigureAppConfiguration(appBuilder =>
{

appBuilder.AddJsonFile("appsettings.json", optional: false, reloadOnChange: true);
appBuilder.AddJsonFile($"appsettings.{Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT")}.json", optional: true, reloadOnChange: true);
appBuilder.AddUserSecrets<Startup>();
appBuilder.AddEnvironmentVariables();
appBuilder.AddCommandLine(args);
})
   .ConfigureLogging((hostingContext, logging) =>
{
// Ensure HttpContextAccessor is accessible
// var httpAccessor = hostingContext.Configuration.Get<HttpContextAccessor>();

var elkConfig = GetElasticsearchSinkOptions(hostingContext);

var logger = new LoggerConfiguration()
        .MinimumLevel.Override("Microsoft.EntityFrameworkCore.Database.Command", Serilog.Events.LogEventLevel.Verbose)
        .Enrich.FromLogContext()
        //.Enrich.WithEcsHttpContext(httpAccessor)
        //.Enrich.With(new ThreadIdEnricher())
        .Enrich.WithExceptionDetails(new DestructuringOptionsBuilder()
             .WithDefaultDestructurers()
             .WithDestructurers(new[] { new DbUpdateExceptionDestructurer() }))
        .Enrich.WithMachineName()
        .Enrich.WithElasticApmCorrelationInfo()
        .Enrich.WithProperty("Environment", $"{hostingContext.Configuration["ASPNETCORE_ENVIRONMENT"]}")
        .Enrich.WithProperty("Application", Program.AppName)
        .WriteTo.Console()
        .WriteTo.Debug()
        .WriteTo.Elasticsearch(elkConfig)
    .CreateBootstrapLogger();

logging.ClearProviders();
logging.AddSerilog(logger: logger, dispose: true);
})
   .UseSerilog((hostingContext, config) =>
{
// Ensure HttpContextAccessor is accessible
// var httpAccessor = hostingContext.Configuration.Get<HttpContextAccessor>();

var elkConfig = GetElasticsearchSinkOptions(hostingContext);

config
    .MinimumLevel.Override("Microsoft.EntityFrameworkCore.Database.Command", Serilog.Events.LogEventLevel.Verbose)
    .Enrich.FromLogContext()
    //.Enrich.WithEcsHttpContext(httpAccessor)
    //.Enrich.With(new ThreadIdEnricher())
    .Enrich.WithExceptionDetails(new DestructuringOptionsBuilder()
         .WithDefaultDestructurers()
         .WithDestructurers(new[] { new DbUpdateExceptionDestructurer() }))
    .Enrich.WithMachineName()
    .Enrich.WithElasticApmCorrelationInfo()
    .WriteTo.Console()
    .WriteTo.Debug()
    .Enrich.WithProperty("Environment", $"{hostingContext.Configuration["ASPNETCORE_ENVIRONMENT"]}")
    .Enrich.WithProperty("Application", Program.AppName)
    .WriteTo.Elasticsearch(elkConfig);
})
   .Build();
}

ElasticsearchSinkOptions GetElasticsearchSinkOptions(HostBuilderContext hostingContext)
{
var elkConfig = new ElasticsearchSinkOptions(
           new Uri(hostingContext.Configuration["ElasticSearchUrl"])
           )
{
ModifyConnectionSettings = x =>
x.BasicAuthentication(
    hostingContext.Configuration["ElasticSearchUserName"],
    hostingContext.Configuration["ElasticSearchPassword"]),
AutoRegisterTemplate = true,
AutoRegisterTemplateVersion = AutoRegisterTemplateVersion.ESv6,
CustomFormatter = new EcsTextFormatter(),
IndexFormat = $"{hostingContext.Configuration["ElasticSearchEcsIndex"]}-{hostingContext.Configuration["ASPNETCORE_ENVIRONMENT"]}".ToLower()
};

return elkConfig;
}


#pragma warning disable S3903 // Types should be defined in named namespaces
public static partial class Program
#pragma warning restore S3903 // Types should be defined in named namespaces
{
    public static readonly string AppName = "ModuleName-Worker";
}

public class Startup
{

}
