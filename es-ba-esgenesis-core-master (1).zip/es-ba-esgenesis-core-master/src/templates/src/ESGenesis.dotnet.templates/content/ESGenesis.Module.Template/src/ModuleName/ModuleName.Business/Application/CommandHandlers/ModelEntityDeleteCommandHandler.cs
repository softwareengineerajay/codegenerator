﻿// Licensed to the .NET Foundation under one or more agreements.
// The .NET Foundation licenses this file to you under the MIT license.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AutoMapper;
using ESGenesis.Core.Sdk.CQRS.Commands;
using ModuleName.Business.BusinessLogic;
using ModuleName.Models.Commands;
using Microsoft.Extensions.Logging;

namespace ModuleName.Business.Application.CommandHandlers
{
    public class ModelEntityDeleteCommandHandler
        : ICommandHandler<ModelEntityDeleteCommand, bool>
    {
        private readonly ILogger<ModelEntityDeleteCommandHandler> logger;
        private readonly IMapper mapper;
        private readonly IModelEntityBusinessLogic animalService;

        public ModelEntityDeleteCommandHandler(
            ILogger<ModelEntityDeleteCommandHandler> logger
            , IMapper mapper
            , IModelEntityBusinessLogic animalService)
        {
            this.logger = logger;
            this.mapper = mapper;
            this.animalService = animalService;
        }

        public async Task<bool> Handle(ModelEntityDeleteCommand request, CancellationToken cancellationToken)
        {
            if (request == null) throw new ArgumentException(nameof(request));

            logger.LogInformation($"----- Remove animal record Request: {request}");

            var response = await animalService.DeleteAsync(request.ModelEntityId);

            if (response == null || response.IsSuccessful == false)
            {
                throw new Exception("Failed to remove animal record.");
            }

            return true;
        }
    }
}
