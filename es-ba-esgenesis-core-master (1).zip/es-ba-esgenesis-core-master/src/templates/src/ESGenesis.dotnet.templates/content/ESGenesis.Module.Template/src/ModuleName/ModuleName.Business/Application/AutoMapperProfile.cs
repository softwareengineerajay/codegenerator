﻿// Licensed to the .NET Foundation under one or more agreements.
// The .NET Foundation licenses this file to you under the MIT license.

using ModuleName.Business.DataAccess.Entities;
using ModuleName.Models;
using AutoMapper;
using ESGenesis.Core.Sdk.Pagination;

namespace ModuleName.Business.Application
{
    public static class AutoMapperCompatibilityExtensions
    {
        // Summary:
        //     Resolve destination member using a custom value resolver callback. Used instead
        //     of MapFrom when not simply redirecting a source member This method cannot be
        //     used in conjunction with LINQ query projection
        //
        // Parameters:
        //   resolver:
        //     Callback function to resolve against source type
        public static void ResolveUsing<TSource, TDestination, TMember, TResult>(this IMemberConfigurationExpression<TSource, TDestination, TMember> member, Func<TSource, TResult> resolver) => member.MapFrom((Func<TSource, TDestination, TResult>)((src, dest) => resolver(src)));
    }

    public class AutoMapperProfile : Profile
    {
        public AutoMapperProfile()
        {
            this.CreateMap<ModelEntity, ModelEntityResponse>()
                .ForMember(dest => dest.CreatedDateTime, opt => opt.MapFrom(src => src.DateCreated))
                .ForMember(dest => dest.UpdatedDateTime, opt => opt.MapFrom(src => src.DateModified));

            this.CreateMap<ModelEntity, ModelEntityCreateResponse>()
                .ForMember(dest => dest.ModelEntityUri, opt => opt.ResolveUsing(src => $"GetModelEntity/{src.Id}"));

            this.CreateMap<PagedResult<ModelEntity>, ModelEntitysResponse>()
                .ForMember(dest => dest.ModelEntitys, opt => opt.MapFrom(src => src.Items));


        }
    }
}
