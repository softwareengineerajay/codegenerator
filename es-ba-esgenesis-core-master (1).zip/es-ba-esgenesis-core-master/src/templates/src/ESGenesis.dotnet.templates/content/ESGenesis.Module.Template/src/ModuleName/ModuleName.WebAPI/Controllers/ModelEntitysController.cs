﻿// Licensed to the .NET Foundation under one or more agreements.
// The .NET Foundation licenses this file to you under the MIT license.

using ESGenesis.Authorization.Sdk.Attributes;
using ESGenesis.Core.Sdk.CQRS.Commands;
using ESGenesis.Core.Sdk.CQRS.Queries;
using ESGenesis.Core.Sdk.Exceptions;
using ModuleName.Business.DataAccess.Entities;
using ModuleName.Models;
using ModuleName.Models.Commands;
using ModuleName.Models.Queries;
using Microsoft.AspNetCore.Mvc;

namespace ModuleName.WebAPI.Controllers
{
    /// <summary>
    ///   ModelEntity API Controller
    /// </summary>
    [ApiVersion("1")]
    [Route("api/v{version:apiVersion}/[controller]")]
    [ApiController]
    public class ModelEntitysController : ControllerBase
    {
        private readonly ILogger<ModelEntitysController> logger;
        private readonly IQueryBus queryBus;
        private readonly ICommandBus commandBus;

        public ModelEntitysController(
            ILogger<ModelEntitysController> logger,
            IQueryBus queryBus,
            ICommandBus commandBus)
        {
            this.logger = logger;
            this.queryBus = queryBus;
            this.commandBus = commandBus;
        }

        /// <summary>
        /// This method returns service name.
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("ServiceName")]
        
        [AuthorizePermissionAttribute("Change Usage Customer", "Edit")]
        public IActionResult ServiceName()
        {
            return Ok("ModelEntity Service. ");
        }

        /// <summary>
        ///   Get method gets ModelEntity details
        /// </summary>
        /// <remarks>
        ///   Sample request:
        ///   GET /ModelEntitys/{id}
        /// </remarks>
        /// <param name="id">ModelEntity Id</param>
        /// <returns name="ModelEntityResponse">ModelEntity Details</returns>
        /// <response code="200">
        ///   The ModelEntity details for the id provided.
        /// </response>
        /// <response code="204">No ModelEntity could be found by Id.</response>
        /// <response code="401">Not Authorized. You need to be authorized to use the API.</response>        
        //[HttpGet("{id}", Name = "GetModelEntity")]
        [HttpGet]
        [Route("GetModelEntity/{id}")]
        [ProducesResponseType(typeof(ModelEntity), 200)]
        [ProducesResponseType(204)]
        [ProducesResponseType(401)]
        public async Task<IActionResult> Get([FromRoute] int id)
        {
            var query = new GetModelEntityDetailsByIdQuery(id);
            var result = await this.queryBus.Send<GetModelEntityDetailsByIdQuery, ModelEntityResponse>(query);

            if (result == null)
            {
                return this.NoContent();
            }

            return this.Ok(result);
        }

        /// <summary>
        ///   Get method searches for ModelEntitys by ModelEntityListProfile object
        /// </summary>
        /// <remarks>
        ///   Sample request:
        ///   GET /ModelEntitys?ApplicationId=1
        /// </remarks>
        /// <param name="animalListProfile">The ModelEntity List Profile Parameters</param>
        /// <returns name="ModelEntitysResponse">Paged List of ModelEntitys with Total Result Count.</returns>
        /// <response code="200">The list of ModelEntitys found with parameters given.</response>
        /// <response code="204">No ModelEntity could be found with parameters.</response>
        /// <response code="400">A Bad Request was sent. The Response will contain the error messages.</response>
        /// <response code="401">Not Authorized. You need to be authorized to use the API.</response>
        /// <response code="404">Not Found. Resource is not found on the server</response>
        [HttpGet]
        [Route("GetModelEntitys")]
        [ProducesResponseType(typeof(ModelEntitysResponse), 200)]
        [ProducesResponseType(204)]
        [ProducesResponseType(typeof(ErrorModel), 400)]
        [ProducesResponseType(401)]
        [ProducesResponseType(404)]
        public async Task<IActionResult> Get([FromQuery] ModelEntityListProfile animalListProfile)
        {
            var query = new GetModelEntitysQuery(animalListProfile);
            var result = await this.queryBus.Send<GetModelEntitysQuery, ModelEntitysResponse>(query);

            if (result == null)
            {
                return this.NoContent();
            }

            return this.Ok(result);
        }

        /// <summary>
        ///   Create method to add the animal to the ModelEntity table
        /// </summary>
        /// <param name="animalCreateCommandModel"></param>
        /// <returns>Task<ActionResult></ActionResult></returns>
        /// <response code="201">ModelEntity has been successfully created.</response>
        /// <response code="400">A Bad Request was sent. The Response will contain the error messages.</response>
        /// <response code="401">Not Authorized. You need to be authorized to use the API.</response>
        /// <response code="404">Not Found. Resource is not found on the server</response>
        [HttpPost]
        [ProducesResponseType(typeof(ModelEntitysResponse), 201)]
        [ProducesResponseType(typeof(ErrorModel), 400)]
        [ProducesResponseType(401)]
        [ProducesResponseType(404)]
        //[AuthorizePermission("EBS_RECEIPT_CREATE || EBS_SUBINVENTORYTRANSFER_CREATE")]
        public async Task<IActionResult> Create([FromBody] ModelEntityCreateCommandModel animalCreateCommandModel)
        {
            var command = new ModelEntityCreateCommand(animalCreateCommandModel);
            var animalResult = await this.commandBus.Send<ModelEntityCreateCommand, ModelEntityCreateResponse>(command);

            if (animalResult == null)
            {
                return this.BadRequest("Failed to create record.");
            }

            return this.Created(animalResult.ModelEntityUri, animalResult);
        }

        /// <summary>
        ///   Edit method to edit the animal on the ModelEntity table
        /// </summary>
        /// <param name="animalEditCommandModel"></param>
        /// <returns>Task<ActionResult></ActionResult></returns>
        /// <response code="200">ModelEntity has been successfully edited.</response>
        /// <response code="400">A Bad Request was sent. The Response will contain the error messages.</response>
        /// <response code="401">Not Authorized. You need to be authorized to use the API.</response>
        /// <response code="404">Not Found. Resource is not found on the server</response>
        [HttpPut]
        [ProducesResponseType(200)]
        [ProducesResponseType(typeof(ErrorModel), 400)]
        [ProducesResponseType(401)]
        [ProducesResponseType(404)]
        //[Me]
        // TODO: Uncomment once this permission is added, and remove the Me attribute
        //[AuthorizePermission("ARCHETYPE_ANIMAL_EDIT")]
        public async Task<IActionResult> Edit([FromBody] ModelEntityEditCommandModel animalEditCommandModel)
        {
            var command = new ModelEntityEditCommand(animalEditCommandModel);
            var result = await this.commandBus.Send<ModelEntityEditCommand, bool>(command);
            if (result == false)
            {
                return this.BadRequest("Failed to update the record.");
            }

            return this.Ok();
        }

        /// <summary>
        ///   POST method to Delete ModelEntity record
        /// </summary>
        /// <param name="id">The ModelEntity Id</param>
        /// <returns name="ModelEntityResponse">Task<ActionResult></ActionResult></returns>
        /// <response code="200">The ModelEntity record has been deleted successfully.</response>
        /// <response code="400">A Bad Request was sent. The Response will contain the error messages.</response>
        /// <response code="401">Not Authorized. You need to be authorized to use the API.</response>
        [HttpPost]
        [Route("{id}/Delete")]
        [ProducesResponseType(200)]
        [ProducesResponseType(typeof(ErrorModel), 400)]
        [ProducesResponseType(401)]
        //[Me]
        // TODO: Uncomment once this permission is added, and remove the Me attribute
        //[AuthorizePermission("ARCHETYPE_ANIMAL_DELETE")]
        public async Task<IActionResult> Delete(int id)
        {
            var command = new ModelEntityDeleteCommand(id);
            var result = await this.commandBus.Send<ModelEntityDeleteCommand, bool>(command);
            if (result == false)
            {
                return this.BadRequest("Failed to remove the record.");
            }

            return this.Ok();
        }
    }
}
