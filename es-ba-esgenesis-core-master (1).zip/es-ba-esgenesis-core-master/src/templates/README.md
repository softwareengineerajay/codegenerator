Track A Tool - Code Generator  

This template creates Titan Module Template.

Install:

From Local:
1. Clone the code tat-backend
2. navigate to folder tat-backend\src\codegenerator\src
3. create nuget package dotnet pack
4. install project template dotnet new install ./bin/debug/NOV.ES.TitanModule.Templates.1.0.0.nupkg

Generate:
CLI:
dotnet new titanmodule -n NewTransferSlip 

Visual Studio:

1. Right Click on Modules and select add Project
2. Search for NOV or Titan project Template in the Wizard
3. Select Titan Module Web Project Template
4. Provide Module name
5. Chnage the Destination folder to Modules
6. You can opt to create only Read or Write service if you want. (By Default both are selected.)
7. Click on Generate. 
This action will generates the domain, domainservice, domaininfrastructure, read api, read test,write api, and write test projects.

Add Solution Folder as shown below and move the respective projects.

-- Modules
---- NewTransferSlip
------ Domain
-------- NOV.ES.TAT.NewTransferSlip.Domain
-------- NOV.ES.TAT.NewTransferSlip.DomainService
-------- NOV.ES.TAT.NewTransferSlip.Infrastructure
------ ReadService
-------- API
---------- NOV.ES.TAT.NewTransferSlip.Read.API
-------- Test
---------- NOV.ES.TAT.NewTransferSlip.Read.Test
------ WriteService
-------- API
---------- NOV.ES.TAT.NewTransferSlip.Write.API
-------- Test
---------- NOV.ES.TAT.NewTransferSlip.Write.Test