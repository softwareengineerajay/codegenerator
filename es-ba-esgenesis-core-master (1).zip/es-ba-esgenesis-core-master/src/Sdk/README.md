## Welcome to ESGenesis reference architecture SDK 

This repository contains a reference architecture and core functionality needed to create .NET projects
