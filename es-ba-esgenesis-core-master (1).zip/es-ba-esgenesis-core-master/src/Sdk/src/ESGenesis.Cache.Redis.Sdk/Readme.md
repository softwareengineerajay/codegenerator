﻿ESGenesis Cache using Redis SDK V1.0.0
