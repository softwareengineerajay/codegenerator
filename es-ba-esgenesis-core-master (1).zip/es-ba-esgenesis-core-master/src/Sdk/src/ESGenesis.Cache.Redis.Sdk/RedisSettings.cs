﻿namespace ESGenesis.Cache.Redis.Sdk
{
    public class RedisSettings
    {
        public required string ConnectionString { get; set; }
    }
}
