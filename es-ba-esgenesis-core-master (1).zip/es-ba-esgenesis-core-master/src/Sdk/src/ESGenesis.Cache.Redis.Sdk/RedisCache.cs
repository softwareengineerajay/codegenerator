﻿using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using ESGenesis.Core.Sdk.Caching;
using StackExchange.Redis;

namespace ESGenesis.Cache.Redis.Sdk
{
    public class RedisCache : ICache
    {
        private readonly ILogger<RedisCache> logger;
        private readonly RedisSettings config;
        //private readonly ConnectionMultiplexer connection;
        //private readonly IDatabase cache;
        private Lazy<IConnectionMultiplexer>? lazyConnection = null;
        private Lazy<IConnectionMultiplexer>? lazyConnectionWrite = null;

        public RedisCache(IOptions<RedisSettings> configs, ILogger<RedisCache> logger)
        {
            config = configs.Value;
            this.logger = logger;
            //connection = GetConnection();
            //cache = connection.GetDatabase();
            lazyConnection = new Lazy<IConnectionMultiplexer>(() =>
            {
                ConnectionMultiplexer redis = ConnectionMultiplexer.Connect(config.ConnectionString);
                return redis;
            });

            lazyConnectionWrite = new Lazy<IConnectionMultiplexer>(() =>
            {
                ConnectionMultiplexer redis = ConnectionMultiplexer.Connect(config.ConnectionString);
                return redis;
            });
        }

        //for the 'GetSubscriber()' and another Databases
        private IConnectionMultiplexer Connection
        {
            get
            {
                if (lazyConnection == null)
                {
                    throw new InvalidOperationException("Lazy connection is not initialized.");
                }
                return lazyConnection.Value;
            }
        }

        private IConnectionMultiplexer WriteConnection
        {
            get
            {
                if (lazyConnectionWrite == null)
                {
                    throw new InvalidOperationException("Lazy write connection is not initialized.");
                }
                return lazyConnectionWrite.Value;
            }
        }

        //for the default database
        private IDatabase cache => Connection.GetDatabase();
        private IDatabase writeCache => WriteConnection.GetDatabase();

        #region Sync Methods
        /// <summary>
        /// Get all keys Asynchronously
        /// </summary>
        /// <returns></returns>
        public IEnumerable<RedisKey> GetAllCacheKeys()
        {
            var server = GetDataCacheServer();

            var keys = server.Keys();
            return keys;
        }

        /// <summary>
        /// Get the value by key
        /// </summary>
        /// <typeparam name="TItem"></typeparam>
        /// <param name="key"></param>
        /// <returns></returns>
        public TItem Get<TItem>(string key)
        {
            string? value = cache.StringGet(key);
            if (value == null)
                return default(TItem)!;

            JsonSerializerSettings jsonSerializerSettings1 = new JsonSerializerSettings()
            {
                ContractResolver = new CamelCasePropertyNamesContractResolver()
            };

            return JsonConvert.DeserializeObject<TItem>(value)!;
        }

        /// <summary>
        /// Add the value
        /// </summary>
        /// <param name="key"></param>
        /// <param name="value"></param>
        public void Add(string key, object value)
        {
            if (value == null) throw new ArgumentNullException("value cannot be null");

            // get key
            string serialized = JsonConvert.SerializeObject(value);
            writeCache.StringSet(key, serialized);
        }

        /// <summary>
        /// Add the value and set expiration
        /// </summary>
        /// <param name="key"></param>
        /// <param name="value"></param>
        /// <param name="expiration"></param>
        public void Add(string key, object value, TimeSpan expiration)
        {
            if (value == null) throw new ArgumentNullException("value cannot be null");
            //if (expiration.total) throw new ArgumentNullException("expiration cannot be null");

            string serialized = JsonConvert.SerializeObject(value);
            if(expiration.TotalSeconds < 1)
                writeCache.StringSet(key, serialized); 
            else
                writeCache.StringSet(key, serialized, expiration);
        }


        /// <summary>
        /// Add the value
        /// </summary>
        /// <param name="key"></param>
        /// <param name="value"></param>
        public bool AddWithLock(string key, object value, TimeSpan lockExpiration)
        {
            if (value == null) throw new ArgumentNullException("value cannot be null");
            bool isSuccess = false;

            var lockKey = key + "_distlock";
            var lockValue = Guid.NewGuid().ToString();
            logger.LogInformation("AddWithLock: lockKey: {0}, lockValue: {1}", lockKey, lockValue);

            // get key
            if (writeCache.LockTake(lockKey, lockValue, lockExpiration))
            {
                logger.LogInformation("AddWithLock: lockKey: {0}, lockValue: {1} is taken", lockKey, lockValue);
                try
                {
                    string serialized = JsonConvert.SerializeObject(value);
                    writeCache.StringSet(key, serialized);
                    isSuccess = true;
                }
                catch (Exception ex)
                {
                    logger.LogError("AddWithLock: Error in add key: {0} exception: {1}", key, ex.ToString());
                }
                finally
                {
                    writeCache.LockRelease(lockKey, lockValue);
                    logger.LogInformation("AddWithLock: lockKey: {0}, lockValue: {1} is released", lockKey, lockValue);
                }
            }
            else
            {
                logger.LogInformation("AddWithLock: lockKey: {0}, lockValue: {1} is not taken", lockKey, lockValue);
            }

            return isSuccess;
        }

        public bool AddWithLock(string key, object value, TimeSpan expiration, TimeSpan lockExpiration)
        {
            if (value == null) throw new ArgumentNullException("value cannot be null");
            if (expiration.TotalSeconds <= 1) throw new ArgumentNullException("Key expiration should be greater than 1s");
            if (expiration.TotalMilliseconds <= 10) throw new ArgumentNullException("Lock expiration should be greater than 10ms");

            bool isSuccess = false;

            var lockKey = key + "_distlock";
            var lockValue = Guid.NewGuid().ToString();
            logger.LogInformation("AddWithLock: lockKey: {0}, lockValue: {1}", lockKey, lockValue);

            // get key
            if (writeCache.LockTake(lockKey, lockValue, lockExpiration))
            {
                logger.LogInformation("AddWithLock: lockKey: {0}, lockValue: {1} is taken", lockKey, lockValue);
                try
                {
                    string serialized = JsonConvert.SerializeObject(value);
                    writeCache.StringSet(key, serialized, expiration);
                    isSuccess = true;
                }
                catch (Exception ex)
                {
                    logger.LogError("AddWithLock: Error in add key with expiration: {0} exception: {1}", key, ex.ToString());
                }
                finally
                {
                    writeCache.LockRelease(lockKey, lockValue);
                    logger.LogInformation("AddWithLock: lockKey: {0}, lockValue: {1} is released", lockKey, lockValue);
                }
            }
            else
            {
                logger.LogInformation("AddWithLock: lockKey: {0}, lockValue: {1} is not taken", lockKey, lockValue);
            }

            return isSuccess;

        }
       
        public bool Remove(string key)
        {
            bool isSuccess = false;

            try
            {
                isSuccess = writeCache.KeyDelete(key);
            }
            catch
            {
                logger.LogError("Error in removing key: {0}", key);
            }

            return isSuccess;
        }

        /// <summary>
        /// remove specific key
        /// </summary>
        /// <param name="key"></param>
        /// <returns></returns>
        public bool RemoveWithLock(string key, TimeSpan lockExpiration)
        {
            bool isSuccess = false;


            var lockKey = key + "_distlock";
            var lockValue = Guid.NewGuid().ToString();
            logger.LogInformation("RemoveWithLock: lockKey: {0}, lockValue: {1}", lockKey, lockValue);

            // get key
            if (writeCache.LockTake(lockKey, lockValue, lockExpiration))
            {
                logger.LogInformation("RemoveWithLock: lockKey: {0}, lockValue: {1} is taken", lockKey, lockValue);
                try
                {
                    isSuccess = writeCache.KeyDelete(key);
                }
                catch (Exception ex)
                {
                    logger.LogError("RemoveWithLock: Error in removing key: {0} exception: {1}", key, ex.ToString());
                }
                finally
                {
                    writeCache.LockRelease(lockKey, lockValue);
                    logger.LogInformation("RemoveWithLock: lockKey: {0}, lockValue: {1} is released", lockKey, lockValue);
                }
            }
            else
            {
                logger.LogInformation("RemoveWithLock: lockKey: {0}, lockValue: {1} is not taken", lockKey, lockValue);
            }

            return isSuccess;

        }


        /// <summary>
        /// Remove all from the cache
        /// </summary>
        public void RemoveAll()
        {
            IEnumerable<RedisKey> keys = GetAllCacheKeys();
            foreach (RedisKey redisKey in keys)
            {
                writeCache.KeyDelete(redisKey);
            }
        }

        /// <summary>
        /// Remove all from the cache
        /// </summary>
        public void RemoveAll(string serverTypePrefix)
        {
            IEnumerable<RedisKey> keys = GetAllCacheKeys();
            foreach (RedisKey redisKey in keys)
            {
                string keyName = redisKey.ToString();
                if (keyName.StartsWith(serverTypePrefix) == true)
                {
                    writeCache.KeyDelete(redisKey);
                }
            }
        }

        private ConnectionMultiplexer GetConnection()
        {
            return ConnectionMultiplexer.Connect(config.ConnectionString);
        }
        #endregion

        #region Async Methods

        /// <summary>
        /// Get the value by key asynchronously
        /// </summary>
        /// <typeparam name="TItem"></typeparam>
        /// <param name="key"></param>
        /// <returns></returns>
        public async Task<TItem> GetAsync<TItem>(string key)
        {
            string value = await cache.StringGetAsync(key);
            if (value == null)
                return default(TItem);

            JsonSerializerSettings jsonSerializerSettings1 = new JsonSerializerSettings()
            {
                ContractResolver = new CamelCasePropertyNamesContractResolver()
            };

            return JsonConvert.DeserializeObject<TItem>(value);
        }

        /// <summary>
        /// Add the value and set expiration asynchronously
        /// </summary>
        /// <param name="key"></param>
        /// <param name="value"></param>
        /// <param name="expiration"></param>
        public async Task<bool> AddAsync(string key, object value, TimeSpan expiration)
        {
            if (value == null) throw new ArgumentNullException("value cannot be null");
            //if (expiration.total) throw new ArgumentNullException("expiration cannot be null");

            bool result = false;

            string serialized = JsonConvert.SerializeObject(value);
            if (expiration.TotalSeconds < 1)
                result = await writeCache.StringSetAsync(key, serialized);
            else
                result = await writeCache.StringSetAsync(key, serialized, expiration);

            return result;
        }

        /// <summary>
        /// Add the value asynchronously
        /// </summary>
        /// <param name="key"></param>
        /// <param name="value"></param>
        public async Task<bool> AddAsync(string key, object value)
        {
            if (value == null) throw new ArgumentNullException("value cannot be null");

            // get key
            string serialized = JsonConvert.SerializeObject(value);
            return await writeCache.StringSetAsync(key, serialized);
        }

        /// <summary>
        /// Add the value asynchronously
        /// </summary>
        /// <param name="key"></param>
        /// <param name="value"></param>
        public async Task<bool> AddWithLockAsync(string key, object value, TimeSpan lockExpiration)
        {
            if (value == null) throw new ArgumentNullException("value cannot be null");
            bool isSuccess = false;

            var lockKey = key + "_distlock";
            var lockValue = Guid.NewGuid().ToString();
            logger.LogInformation("AddWithLock: lockKey: {0}, lockValue: {1}", lockKey, lockValue);

            // get key
            if (await writeCache.LockTakeAsync(lockKey, lockValue, lockExpiration))
            {
                logger.LogInformation("AddWithLock: lockKey: {0}, lockValue: {1} is taken", lockKey, lockValue);
                try
                {
                    string serialized = JsonConvert.SerializeObject(value);
                    isSuccess = await writeCache.StringSetAsync(key, serialized);
                }
                catch (Exception ex)
                {
                    logger.LogError("AddWithLock: Error in add key: {0} exception: {1}", key, ex.ToString());
                }
                finally
                {
                    await writeCache.LockReleaseAsync(lockKey, lockValue);
                    logger.LogInformation("AddWithLock: lockKey: {0}, lockValue: {1} is released", lockKey, lockValue);
                }
            }
            else
            {
                logger.LogInformation("AddWithLock: lockKey: {0}, lockValue: {1} is not taken", lockKey, lockValue);
            }

            return isSuccess;
        }

        public async Task<bool> AddWithLockAsync(string key, object value, TimeSpan expiration, TimeSpan lockExpiration)
        {
            if (value == null) throw new ArgumentNullException("value cannot be null");
            if (expiration.TotalSeconds <= 1) throw new ArgumentNullException("Key expiration should be greater than 1s");
            if (expiration.TotalMilliseconds <= 10) throw new ArgumentNullException("Lock expiration should be greater than 10ms");

            bool isSuccess = false;

            var lockKey = key + "_distlock";
            var lockValue = Guid.NewGuid().ToString();
            logger.LogInformation("AddWithLock: lockKey: {0}, lockValue: {1}", lockKey, lockValue);

            // get key
            if (await writeCache.LockTakeAsync(lockKey, lockValue, lockExpiration))
            {
                logger.LogInformation("AddWithLock: lockKey: {0}, lockValue: {1} is taken", lockKey, lockValue);
                try
                {
                    string serialized = JsonConvert.SerializeObject(value);
                    isSuccess = await writeCache.StringSetAsync(key, serialized, expiration);
                    //isSuccess = true;
                }
                catch (Exception ex)
                {
                    logger.LogError("AddWithLock: Error in add key with expiration: {0} exception: {1}", key, ex.ToString());
                }
                finally
                {
                    await writeCache.LockReleaseAsync(lockKey, lockValue);
                    logger.LogInformation("AddWithLock: lockKey: {0}, lockValue: {1} is released", lockKey, lockValue);
                }
            }
            else
            {
                logger.LogInformation("AddWithLock: lockKey: {0}, lockValue: {1} is not taken", lockKey, lockValue);
            }

            return isSuccess;

        }

        public async Task<bool> RemoveAsync(string key)
        {
            bool isSuccess = false;

            try
            {
                isSuccess = await writeCache.KeyDeleteAsync(key);
            }
            catch
            {
                logger.LogError("Error in removing key: {0}", key);
            }

            return isSuccess;
        }

        /// <summary>
        /// remove specific key
        /// </summary>
        /// <param name="key"></param>
        /// <returns></returns>
        public async Task<bool> RemoveWithLockAsync(string key, TimeSpan lockExpiration)
        {
            bool isSuccess = false;


            var lockKey = key + "_distlock";
            var lockValue = Guid.NewGuid().ToString();
            logger.LogInformation("RemoveWithLock: lockKey: {0}, lockValue: {1}", lockKey, lockValue);

            // get key
            if (await writeCache.LockTakeAsync(lockKey, lockValue, lockExpiration))
            {
                logger.LogInformation("RemoveWithLock: lockKey: {0}, lockValue: {1} is taken", lockKey, lockValue);
                try
                {
                    isSuccess = await writeCache.KeyDeleteAsync(key);
                }
                catch (Exception ex)
                {
                    logger.LogError("RemoveWithLock: Error in removing key: {0} exception: {1}", key, ex.ToString());
                }
                finally
                {
                    await writeCache.LockReleaseAsync(lockKey, lockValue);
                    logger.LogInformation("RemoveWithLock: lockKey: {0}, lockValue: {1} is released", lockKey, lockValue);
                }
            }
            else
            {
                logger.LogInformation("RemoveWithLock: lockKey: {0}, lockValue: {1} is not taken", lockKey, lockValue);
            }

            return isSuccess;

        }

        /// <summary>
        /// Remove all from the cache asynchronously
        /// </summary>
        public async Task<bool> RemoveAllAsync()
        {
            bool isSuccess = true;
            IEnumerable<RedisKey> keys = GetAllCacheKeys();
            foreach (RedisKey redisKey in keys)
            {
                await writeCache.KeyDeleteAsync(redisKey);
            }
            return isSuccess;
        }
        
        /// <summary>
        /// Remove all from the cache
        /// </summary>
        public async Task<bool> RemoveAllAsync(string serverTypePrefix)
        {
            IEnumerable<RedisKey> keys = GetAllCacheKeys();
            foreach (RedisKey redisKey in keys)
            {
                string keyName = redisKey.ToString();
                if (keyName.StartsWith(serverTypePrefix) == true)
                {
                    await writeCache.KeyDeleteAsync(redisKey);
                }
            }

            return true;
        }

        private async Task<ConnectionMultiplexer> GetConnectionAsync()
        {
            return await ConnectionMultiplexer.ConnectAsync(config.ConnectionString);
        }


        #endregion

        private IServer GetDataCacheServer()
        {

            var endpoints = Connection.GetEndPoints();
            var server = Connection.GetServer(endpoints.First());

            return server;
        }
        
    }
}
