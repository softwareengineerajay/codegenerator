﻿namespace ESGenesis.Authentication.Sdk
{
    
    public class TokenValidatorSettings
    {
        public List<KeyValuePair<string, TokenValidator>> Properties { get; set; }

        public TokenValidator GetTokenValidatorByClientId(string clientId)
        {
            if(Properties == null || Properties.Count < 1)
            {
                return null;
            }

            var tokenValidator = Properties.Find(x => x.Value.ClientId == clientId);
            return tokenValidator.Value;
        }

        public TokenValidator GetTokenValidatorByIssuer(string issuer)
        {
            if (Properties == null || Properties.Count < 1)
            {
                return null;
            }

            var tokenValidator = Properties.Find(x => x.Value.Issuer == issuer);
            return tokenValidator.Value;
        }
    }

    public class TokenIssuerSettings 
    {
        public List<KeyValuePair<string, TokenIssuer>> Properties { get; set; }

        public TokenIssuer GetTokenIssuerByClientId(string clientId)
        {
            if (Properties == null || Properties.Count < 1)
            {
                return null;
            }

            var tokenIssuer = Properties.Find(x => x.Value.ClientId == clientId);
            return tokenIssuer.Value;
        }

        public TokenIssuer GetTokenIssuerByIssuer(string issuer)
        {
            if (Properties == null || Properties.Count < 1)
            {
                return null;
            }

            var tokenIssuer = Properties.Find(x => x.Value.Issuer == issuer);
            return tokenIssuer.Value;
        }
    }

    public class TokenValidator
    { 
        public string IssuerKey { get; set; }
        public string ClientId { get; set; }
        public string Issuer { get; set; }
        public string Audience { get; set; }
        public string AuthServer { get; set; }
        public bool RequireHttps { get; set; }
        public string DefaultUserEmailId { get; set; }
        public string UserEmailHeaderKey { get; set; }
        public string ImpersonatedUserId { get; set; }
    }

    public class TokenIssuer : TokenValidator
    {
        public string ClientSecret { get; set; }
        public string Scope { get; set; }
    }

    public class TatSigningKeys
    {
        public List<KeyValuePair<string, string>> Properties { get; set; }
        public string GetTokenSigningKeysByIssuerKey(string issuerKey)
        {
            if (Properties == null || Properties.Count < 1)
            {
                return null;
            }

            var issuerSigninKey = Properties.Find(x => x.Key == issuerKey);
            return issuerSigninKey.Value;
        }

    }
    
}
