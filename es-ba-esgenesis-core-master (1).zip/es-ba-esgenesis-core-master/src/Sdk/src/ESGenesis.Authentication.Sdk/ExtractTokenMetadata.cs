﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Primitives;
using System.Security.Claims;

namespace ESGenesis.Authentication.Sdk
{
    public static class ExtractTokenMetadata
    {
        public static string GetToken(IHttpContextAccessor httpContextAccessor)
        {
            StringValues authHeaders = string.Empty;

            if (httpContextAccessor != null && httpContextAccessor.HttpContext != null)
            {
                httpContextAccessor.HttpContext?.Request.Headers
                    .TryGetValue("Authorization", out authHeaders);
            }

            return authHeaders != String.Empty ? authHeaders.ToString().Substring(6) : String.Empty;
        }

        /// <summary>  
        /// Added summary for the method  
        /// </summary>  
        /// <param name="identity"></param>  
        /// <returns></returns>  
        public static string GetClientId(ClaimsIdentity identity)
        {
            string cid = string.Empty;

            if (identity != null)
            {
                var claim = identity.Claims.FirstOrDefault(static c => c.Type == "cid");
                if (claim != null)
                {
                    cid = claim.Value;
                }
            }

            return cid;
        }
    }
}
