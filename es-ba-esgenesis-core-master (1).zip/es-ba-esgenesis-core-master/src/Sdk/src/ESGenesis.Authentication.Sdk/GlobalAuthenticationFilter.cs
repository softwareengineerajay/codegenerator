﻿using System.IdentityModel.Tokens.Jwt;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.IdentityModel.Tokens;
using System.Collections.ObjectModel;
using System.Net;
using System.Text.RegularExpressions;
using Microsoft.Extensions.Configuration;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Protocols;
using Microsoft.IdentityModel.Protocols.OpenIdConnect;
using ESGenesis.Core.Sdk.Caching;
using ESGenesis.Core.Sdk.Authentication;
using ESGenesis.Core.Sdk.Exceptions;
using ESGenesis.Core.Sdk.UtilityClasses;
using ESGenesis.Core.Sdk.Extensions;

namespace ESGenesis.Authentication.Sdk
{
    public class GlobalAuthenticationFilter
         : Attribute, IAuthorizationFilter
    {
        private ILogger<GlobalAuthenticationFilter> logger;
        private ICache cache;
        //private IUserProfileService userProfileService;
        private IConfiguration configuration;

        public GlobalAuthenticationFilter()
        {

        }

        public void OnAuthorization(AuthorizationFilterContext context)
        {
            bool hasAllowAnonymous = context.ActionDescriptor.EndpointMetadata
                                 .Any(em => em.GetType() == typeof(AllowAnonymousAttribute)); //< -- Here it is

            if (hasAllowAnonymous) return;

            // get ILogger<GlobalAuthenticationFilter> from service collection
            logger = context.HttpContext.RequestServices.GetService<ILogger<GlobalAuthenticationFilter>>();

            logger.LogInformation("GlobalAuthenticationFilter.OnAuthorization() called");

            // get ICache from service collection
            cache = context.HttpContext.RequestServices.GetService<ICache>();

            // get ILoggedInUser from service collection
            var loggedInUser = context.HttpContext.RequestServices.GetService<ILoggedInUser>();

            // get IConfiguration
            configuration = context.HttpContext.RequestServices.GetService<IConfiguration>();

            // get the token from the header
            var token = context.HttpContext.Request.Headers["Authorization"].FirstOrDefault()?.Split(" ").Last();

            var tokenValidator = ValidateToken(context, token).Result;

            if (token != null)
            {
                loggedInUser.AccessToken = token;
                var erpSystemIdString = context.HttpContext.Request.Headers["ErpSystemId"].FirstOrDefault();
                loggedInUser.CurentErpSystemId = string.IsNullOrEmpty(erpSystemIdString) || !Regex.IsMatch(erpSystemIdString, @"^\d+$") ? null : int.Parse(erpSystemIdString);
                loggedInUser.CurentErpSystem = context.HttpContext.Request.Headers["ErpSystem"].FirstOrDefault();
            }

            if (tokenValidator != null)
            {
                loggedInUser.TokenIssuerKey = tokenValidator.IssuerKey;
                loggedInUser.IsExternalApp = tokenValidator.IssuerKey != "TATUI";
                loggedInUser.DefaultUserEmailId = tokenValidator.DefaultUserEmailId;
                loggedInUser.ClientId = tokenValidator.ClientId;
                var userEmail = context.HttpContext.Items["user_email_id"]?.ToString();
                loggedInUser.EmailId = userEmail ?? "Unknown";
                loggedInUser.DefaultUserEmailId = tokenValidator.DefaultUserEmailId;
                loggedInUser.ImpersonatedUserId = tokenValidator.ImpersonatedUserId;
                loggedInUser.AppId = configuration.GetValue<int>("ApplicationId");
            }
        }

        // write a method to validate the token and return the ILoggedInUser object
        private async Task<TokenValidator> ValidateToken(AuthorizationFilterContext context,
            string token)
        {
            if (string.IsNullOrEmpty(token))
            {
                logger.LogError("GlobalAuthenticationFilter.ValidateToken: Token is null or empty");
                context.Result = new UnauthorizedResult();
                return null;
            }

            // get TokenValidatorSettings from configuration service collection                        
            var tokenValidatorSettings = context.HttpContext.RequestServices.GetService<TokenValidatorSettings>();


            // get issuer from jwt token
            var jwtToken = new JwtSecurityTokenHandler().ReadJwtToken(token);
            string issuer = string.IsNullOrEmpty(jwtToken?.Issuer) ? null : jwtToken?.Issuer;
            string clientId = jwtToken.Claims.FirstOrDefault(x => x.Type == "cid")?.Value;
            if (string.IsNullOrEmpty(clientId))
            {
                clientId = jwtToken.Claims.FirstOrDefault(x => x.Type == "azp")?.Value;
            }

            var tokenValidator = tokenValidatorSettings.GetTokenValidatorByClientId(clientId);

            if (tokenValidator == null)
            {
                logger.LogError($"GlobalAuthenticationFilter.ValidateToken: TokenValidator not found for clientid {clientId}. Please check TokenValidatorSettings.");
                //context.Result = new UnauthorizedResult();
                return HandleMissingTokenValidatorSetting(context, clientId);
            }

            // To roll back Reading Authentication Key from Configuration

            // Rollback-1. Uncomment below two lines
            var signingKeys = await GetSigningKeysFromCache(tokenValidator.IssuerKey,
                tokenValidator.Issuer);

            // Rollback-2. Comment below two lines
            //var signingKeys = await GetSigningKeysFromConfig(tokenValidator.IssuerKey,
            //   tokenValidator.Issuer);

            var validationParameters = new TokenValidationParameters
            {
                RequireExpirationTime = true,
                RequireSignedTokens = true,
                ValidateIssuer = true,
                ValidIssuer = issuer,
                ValidateIssuerSigningKey = false,
                IssuerSigningKeys = signingKeys,
                SignatureValidator = delegate (string token, TokenValidationParameters parameters)
                {
                    var jwt = new JwtSecurityToken(token);
                    return jwt;
                },
                ValidateLifetime = true,
                // Allow for some drift in server time
                // (a lower value is better; we recommend two minutes or less)
                ClockSkew = TimeSpan.FromMinutes(2),
                // See additional validation for aud below
                ValidateAudience = true,
                ValidAudience = tokenValidator.Audience,
            };

            try
            {
                var principal = new JwtSecurityTokenHandler()
                    .ValidateToken(token, validationParameters, out var rawValidatedToken);

                var sub = ((JwtSecurityToken)rawValidatedToken).Subject;
                sub = string.Compare(sub, clientId, true) == 0 || !sub.Contains("@") ? null : sub;
                context.HttpContext.Items["UserEmailHeaderKey"] = tokenValidator.UserEmailHeaderKey;
                if (sub == null && context.HttpContext.Request.Headers.ContainsKey(tokenValidator.UserEmailHeaderKey))
                {
                    Microsoft.Extensions.Primitives.StringValues userEmailVal;
                    if (context.HttpContext.Request.Headers.TryGetValue(tokenValidator.UserEmailHeaderKey, out userEmailVal))
                    {
                        string userEmail = userEmailVal.FirstOrDefault();
                        //sub = userEmail ?? sub;
                        sub = !string.IsNullOrEmpty(userEmail) ? userEmail : sub;
                    }
                }

                sub = sub ?? (!string.IsNullOrEmpty(tokenValidator.DefaultUserEmailId) &&
                            tokenValidator.IssuerKey != "TATUI" ? tokenValidator.DefaultUserEmailId :
                            sub);

                context.HttpContext.Items["user_email_id"] = sub;
                context.HttpContext.Items["access_token"] = (JwtSecurityToken)rawValidatedToken;
                context.HttpContext.Items["issuer-key"] = tokenValidator?.IssuerKey;
            }
            catch (SecurityTokenValidationException ex)
            {
                // Logging, etc.
                logger.LogError("Security Token validation Exception: " + ex.ToString());

                // Rollback-3. Uncomment below line
                // await DeleteSigningKeysFromCacheAsync(tokenValidator.IssuerKey);

                SetResponseUnauthorized(context, ex, tokenValidator);
            }

            // if token is valid
            //return tokenValidator?.IssuerKey;
            return tokenValidator;
        }

        private static TokenValidator HandleMissingTokenValidatorSetting(AuthorizationFilterContext context, string clientId)
        {
            ErrorModel errorModel = new ErrorModel()
            {
                Code = (int)HttpStatusCode.InternalServerError,
                Error = "Cannot validate token.",
                Message = $"TokenValidator not found for clientid {clientId}. Please check TokenValidatorSettings.",
                Details = $"TokenValidator not found for clientid {clientId}. Please check TokenValidatorSettings.",
                RequestId = Guid.NewGuid().ToString(), //context.HttpContext.Request.Headers.RequestId,
                TraceId = "TraceId-",
                HelpUrl = "https://esgenesishelp.nov.cloud"
            };
            context.Result = new ContentResult
            {
                Content = Newtonsoft.Json.JsonConvert.SerializeObject(errorModel),
                ContentType = "text/json",
                StatusCode = errorModel.Code
            };
            return null;
        }

        //private async Task<ICollection<SecurityKey>> GetSigningKeysFromConfig(string issuerKey, string issuer)
        //{
        //    logger.LogInformation("GlobalAuthenticationFilter:GetSigningKeysFromConfig: Getting signing keys from configuration for issuer key: " + issuerKey);
        //    ICollection<SecurityKey> signingKeysValue = null;
        //    string issuerSigningKeys = null;
        //    //var issuerSigningKeysConfig = configuration.GetSection("TatSigningKeysConfig");
        //    //TatSigningKeys signingKeys = Newtonsoft.Json.JsonConvert.DeserializeObject<TatSigningKeys>(issuerSigningKeysConfig.Value);

        //    //var issuerSigningKeys = signingKeys.GetTokenSigningKeysByIssuerKey(issuerKey);

        //    if (issuerKey == "internalidentity")
        //    {
        //        return await GetSigningKeysFromIssuer(issuer);
        //    }

        //    switch (issuerKey)
        //    {
        //        case "Automic":
        //            issuerSigningKeys = configuration.GetValue<string>("AutomicSigningkey");
        //            break;
        //        case "Boomi":
        //            issuerSigningKeys = configuration.GetValue<string>("BoomiSigningkey");
        //            break;
        //        case "D365":
        //            issuerSigningKeys = configuration.GetValue<string>("D365Signingkey");
        //            break;
        //        case "TATAudit":
        //            issuerSigningKeys = configuration.GetValue<string>("TATAuditSigningkey");
        //            break;
        //        case "EDS":
        //            issuerSigningKeys = configuration.GetValue<string>("EDSSigningkey");
        //            break;
        //        case "TSM":
        //            issuerSigningKeys = configuration.GetValue<string>("TSMSigningkey");
        //            break;
        //        case "TATUI":
        //            issuerSigningKeys = configuration.GetValue<string>("TATUISigningkey");
        //            break;
        //        case "TATv1.0":
        //            issuerSigningKeys = configuration.GetValue<string>("TATv1.0Signingkey");
        //            break;

        //    }
        //    //issuerSigningKeys = configuration.GetValue<string>("AutomicSigninkey"); //"[{\"AdditionalData\":{},\"Alg\":null,\"Crv\":null,\"D\":null,\"DP\":null,\"DQ\":null,\"E\":\"AQAB\",\"K\":null,\"KeyId\":\"60KuO4FmvqQtgD1cRpMtzEFkqX74oEZCBWGoFG5a7mg\",\"Kid\":\"60KuO4FmvqQtgD1cRpMtzEFkqX74oEZCBWGoFG5a7mg\",\"Kty\":\"RSA\",\"N\":\"wTfQ-EPndGXJrNJhRZZL5EBK82oMTLbRaNPHu2QuiP-J1h5e3m-NH17o-AQooZdSmY-MNaqJR_j37Qw5ZGz-9JusMxeE7psJBHwIW9vKDInMWhp5pgRQ5cufOIvR0DPW6SLcFBKWBMI2ziwjQEaUiUadUh3xJhE47JfFSN80oJLoJg6UjUCB5SsHo7lLX7Rdp87L-mYrzeNn8JI7otA4z7eIXgMWK5BQIrQkoP4TihlneTYkyluOonYu3v5GdoWghMIZX2LS4LNswbNy6fqcUestYjkZvn6uezFsNzrMReMt0tqHzphLOZ3JaHlRiZ2MESh40zX22Dridojv44mUxw\",\"Oth\":null,\"P\":null,\"Q\":null,\"QI\":null,\"Use\":null,\"X\":null,\"X5t\":null,\"X5tS256\":null,\"X5u\":null,\"Y\":null,\"KeySize\":2048,\"HasPrivateKey\":false,\"CryptoProviderFactory\":{\"CryptoProviderCache\":{},\"CustomCryptoProvider\":null,\"CacheSignatureProviders\":true,\"SignatureProviderObjectPoolCacheSize\":32}}]";

        //    if (string.IsNullOrEmpty(issuerSigningKeys))
        //    {
        //        logger.LogError("GlobalAuthenticationFilter:GetSigningKeysFromConfig: Signing keys not found in configuration for issuer key: " + issuerKey);
        //        return null;
        //    }

        //    var jwkSigningKeys = Newtonsoft.Json.JsonConvert.DeserializeObject<List<JsonWebKey>>(issuerSigningKeys);
        //    if (jwkSigningKeys != null)
        //    {
        //        signingKeysValue = new Collection<SecurityKey>(jwkSigningKeys.ToArray<SecurityKey>());
        //    }

        //    return signingKeysValue;
        //}

        private async Task<ICollection<SecurityKey>> GetSigningKeysFromCache(string issuerKey, string issuer)
        {
            var cacheKey = $"{issuerKey}-{CommonMethods.GetEnviornment()}";
            ICollection<SecurityKey> jwkSigningKeys = await GetCachedSigningKeysAsync(cacheKey);

            // if signing keys are not present in ICache, return null
            if (jwkSigningKeys == null)
            {
                var signingKeys = await GetSigningKeysFromIssuer(issuer);
                if (signingKeys != null)
                {
                    jwkSigningKeys = await CacheSigningKeysAsync(cacheKey, signingKeys);
                }
            }

            // if signing keys are present in ICache, return the signing keys
            return jwkSigningKeys;
        }

        private ICollection<SecurityKey> CacheSigningKeys(string cacheKey, ICollection<SecurityKey> signingKeys)
        {
            Collection<SecurityKey> collection = null;
            List<JsonWebKey> jwKeys = new List<JsonWebKey>();
            foreach (var key in signingKeys)
            {
                var jwKey = JsonWebKeyConverter.ConvertFromSecurityKey(key);
                jwKeys.Add(jwKey);
            }
            collection = new Collection<SecurityKey>(jwKeys.ToArray<SecurityKey>());
            try
            {
                // cache the signing keys in ICache
                TimeSpan expirationTime = new TimeSpan(24, 0, 0);
                cache.AddWithLock(cacheKey, jwKeys, expirationTime, new TimeSpan(0,0,1));
            }
            catch (System.Exception ex)
            {
                logger.LogError("GlobalAuthenticationFilter: Exception thrown while caching signing keys in ICache: " + ex.ToString());
            }

            return collection;

        }

        private async Task<ICollection<SecurityKey>> CacheSigningKeysAsync(string cacheKey, ICollection<SecurityKey> signingKeys)
        {
            Collection<SecurityKey> collection = null;
            List<JsonWebKey> jwKeys = new List<JsonWebKey>();
            foreach (var key in signingKeys)
            {
                var jwKey = JsonWebKeyConverter.ConvertFromSecurityKey(key);
                jwKeys.Add(jwKey);
            }
            collection = new Collection<SecurityKey>(jwKeys.ToArray<SecurityKey>());
            try
            {
                // cache the signing keys in ICache
                TimeSpan expirationTime = new TimeSpan(24, 0, 0);
                await cache.AddWithLockAsync(cacheKey, jwKeys, expirationTime, new TimeSpan(0, 0, 1));
            }
            catch (System.Exception ex)
            {
                logger.LogError("GlobalAuthenticationFilter: Exception thrown while caching signing keys in ICache: " + ex.ToString());
            }

            return collection;

        }

        private void DeleteSigningKeysFromCache(string issuerKey)
        {
            var cacheKey = $"{issuerKey}-{CommonMethods.GetEnviornment()}";
            try
            {
                // delete the signing keys from ICache
                cache.RemoveWithLock(cacheKey, new TimeSpan(0, 0, 1));
            }
            catch (System.Exception ex)
            {
                logger.LogError("GlobalAuthenticationFilter: Exception thrown while deleting signing keys from ICache: " + ex.ToString());
            }
        }

        private async Task<bool> DeleteSigningKeysFromCacheAsync(string issuerKey)
        {
            var cacheKey = $"{issuerKey}-{CommonMethods.GetEnviornment()}";
            bool result = false;
            try
            {
                // delete the signing keys from ICache
                result = await cache.RemoveWithLockAsync(cacheKey, new TimeSpan(0, 0, 1));
            }
            catch (System.Exception ex)
            {
                logger.LogError("GlobalAuthenticationFilter: Exception thrown while deleting signing keys from ICache: " + ex.ToString());
            }

            return result;
        }

        private ICollection<SecurityKey> GetCachedSigningKeys(string cacheKey)
        {
            ICollection<SecurityKey> signingKeys = null;
            try
            {
                // get the signing keys from ICache
                var jwkSigningKeys = cache.Get<List<JsonWebKey>>(cacheKey);
                if (jwkSigningKeys != null)
                {
                    signingKeys = new Collection<SecurityKey>(jwkSigningKeys.ToArray<SecurityKey>());
                }
            }
            catch (System.Exception ex)
            {
                logger.LogError("GlobalAuthenticationFilter: Exception thrown while getting signing keys from ICache: " + ex.ToString());
            }
            return signingKeys;
        }

        private async Task<ICollection<SecurityKey>> GetCachedSigningKeysAsync(string cacheKey)
        {
            ICollection<SecurityKey> signingKeys = null;
            try
            {
                // get the signing keys from ICache
                var jwkSigningKeys = await cache.GetAsync<List<JsonWebKey>>(cacheKey);
                if (jwkSigningKeys != null)
                {
                    signingKeys = new Collection<SecurityKey>(jwkSigningKeys.ToArray<SecurityKey>());
                }
            }
            catch (System.Exception ex)
            {
                logger.LogError("GlobalAuthenticationFilter: Exception thrown while getting signing keys from ICache: " + ex.ToString());
            }
            return signingKeys;
        }


        // write a method to get the signing keys from the issuer
        private async Task<ICollection<SecurityKey>> GetSigningKeysFromIssuer(string issuer)
        {
            // get the configuration manager
            var configurationManager = new ConfigurationManager<OpenIdConnectConfiguration>(
                               $"{issuer}/.well-known/openid-configuration",
                                              new OpenIdConnectConfigurationRetriever(),
                                                             new HttpDocumentRetriever());

            Task.Delay(TimeSpan.FromMilliseconds(100)).Wait();

            // get the open id configuration
            var openIdConfig = await configurationManager.GetConfigurationAsync();

            // return the signing keys
            return openIdConfig.SigningKeys;
        }

        private void SetResponseUnauthorized(AuthorizationFilterContext context,
            System.Exception ex,
            TokenValidator tokenValidatorSetting)
        {
            logger.LogError($"{DateTime.UtcNow} User access restricted  ... Exception thrown in Global Authentication Filter." +
                $"Issuer Key : {tokenValidatorSetting.IssuerKey}" +
                $"issuer : {tokenValidatorSetting.Issuer}" +
                $"audience : {tokenValidatorSetting.Audience}");

            logger.LogError(ex.StackTrace);
            context.Result = new UnauthorizedResult();
        }

    }
}
