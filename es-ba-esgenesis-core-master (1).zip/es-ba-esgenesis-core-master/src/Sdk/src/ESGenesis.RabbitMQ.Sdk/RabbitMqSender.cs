﻿// Licensed to the .NET Foundation under one or more agreements.
// The .NET Foundation licenses this file to you under the MIT license.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using RabbitMQ.Client;

namespace ESGenesis.RabbitMQ.Sdk
{
    public interface IRabbitMqSender
    {
        bool Send(RabbitMqMessageInfo messageInfo);
    }

    public class RabbitMqSender : IRabbitMqSender
    {
        private readonly IModel channel;
        private readonly IBasicProperties messageProperties;
        private readonly ILogger<RabbitMqSender> logger;

        public RabbitMqSender(ILogger<RabbitMqSender> logger, IConnection connection)
        {
            this.channel = connection.CreateModel();
            this.messageProperties = this.channel.CreateBasicProperties();
            this.messageProperties.Persistent = true;
            this.logger = logger;
        }

        public bool Send(RabbitMqMessageInfo messageSendInfo)
        {
            try
            {
                var json = JsonConvert.SerializeObject(messageSendInfo.Item);
                var message = Encoding.UTF8.GetBytes(json);

                this.channel.BasicPublish(
                    messageSendInfo.Exchange,
                    messageSendInfo.RoutingKey,
                    this.messageProperties,
                    message);

                return true;
            }
            catch (Exception ex)
            {
                this.logger.LogCritical(ex, "Send Message");
                Console.WriteLine(ex.Message);
                return false;
            }
        }
    }

}
