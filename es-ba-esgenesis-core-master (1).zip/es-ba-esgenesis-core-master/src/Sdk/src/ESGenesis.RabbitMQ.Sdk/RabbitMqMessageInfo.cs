﻿namespace ESGenesis.RabbitMQ.Sdk
{
    public class RabbitMqMessageInfo
    {
        public required string Exchange { get; set; }

        public required string RoutingKey { get; set; }

        // this is the object to send,
        // serialization will be done by the message sender
        public required object Item { get; set; }
    }
}
