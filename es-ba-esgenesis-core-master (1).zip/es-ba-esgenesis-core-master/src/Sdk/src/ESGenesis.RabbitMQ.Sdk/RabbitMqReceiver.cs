﻿// Licensed to the .NET Foundation under one or more agreements.
// The .NET Foundation licenses this file to you under the MIT license.

using System.Text;
using Microsoft.Extensions.Logging;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;

namespace ESGenesis.RabbitMQ.Sdk
{
    public interface IRabbitMqPullReceiver
    {
        void MessageReceived(string message);

        void Receive(string queueName);
    }

    public class RabbitMqReceiver : IRabbitMqPullReceiver
    {
        private readonly IConnection connection;
        private readonly IMessageProcessor messageProcessor;
        private readonly ILogger<RabbitMqReceiver> logger;
        private IModel? channel;

        public RabbitMqReceiver(ILogger<RabbitMqReceiver> logger,
            IConnection connection,
            IMessageProcessor messageProcessor)
        {
            this.messageProcessor = messageProcessor;
            this.connection = connection;
            this.logger = logger;
        }

        public void Receive(string queueName)
        {
            try
            {
                if (this.channel == null || this.channel.IsClosed)
                {
                    this.channel = this.connection.CreateModel();
                    this.channel.BasicQos(0, 1000, false);
                }


                var consumer = new EventingBasicConsumer(this.channel);

                consumer.Received += (model, ea) =>
                {
                    try
                    {
                        var message = Encoding.Default.GetString(ea.Body.ToArray());
                        this.MessageReceived(message);
                        this.channel.BasicAck(ea.DeliveryTag, false);
                    }
                    catch (Exception ex)
                    {
                        // if an uncaught exception filters up to the top
                        // do not acknowledge the message and requeue (is that really
                        // what we want to do here?)
                        Console.WriteLine(ex.Message);
                        this.channel.BasicNack(ea.DeliveryTag, false, true);
                    }
                };

                this.channel.BasicConsume(queueName, false, consumer);

                #region Depricated QueueingBasicConsumer
                //var processMore = true;
                //var consumer = new QueueingBasicConsumer(this._Channel);
                //this._Channel.BasicConsume(queueName, false, consumer);

                //BasicDeliverEventArgs deliveryArgs = null;

                //while (processMore)
                //{
                //    try
                //    {
                //        // set 1 sec timeout for receiving message
                //        consumer.Queue.Dequeue(1000, out deliveryArgs);
                //        // if no more message to process
                //        if (deliveryArgs != null)
                //        {
                //            var message = Encoding.Default.GetString(deliveryArgs.Body.ToArray());
                //            //  Console.WriteLine("Message Recieved - {0}", message);
                //            this.MessageReceived(message);
                //            this.channel.BasicAck(deliveryArgs.DeliveryTag, false);
                //        }
                //        else
                //        {
                //            processMore = false;
                //        }
                //    }
                //    catch (Exception ex)
                //    {
                //        // if an uncaught exception filters up to the top
                //        // do not acknowledge the message and requeue (is that really
                //        // what we want to do here?)
                //        Console.WriteLine(ex.Message);
                //        this.channel.BasicNack(deliveryArgs.DeliveryTag, false, true);
                //    }
                //}

                //this.channel.BasicCancel(consumer.ConsumerTag);
                #endregion
            }
            catch (Exception ex)
            {
                this.logger.LogCritical(ex, "Pull Receive Message");
                this.logger.LogCritical(ex.ToString());
                Console.WriteLine(ex.Message);
            }
        }

        public void MessageReceived(string message)
        {
            // All we're doing here is getting the data and processing the
            // message based on the message processor sent in
            this.messageProcessor.Process(message);
        }
    }
}
