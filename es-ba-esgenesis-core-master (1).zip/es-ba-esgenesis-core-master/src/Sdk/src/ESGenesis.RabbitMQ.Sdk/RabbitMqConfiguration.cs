﻿// Licensed to the .NET Foundation under one or more agreements.
// The .NET Foundation licenses this file to you under the MIT license.

namespace ESGenesis.RabbitMQ.Sdk
{
    public class RabbitMqConfiguration
    {
        public required string HostName { get; set; }
        public required string UserName { get; set; }
        public required string Password { get; set; }
        public required string VirtualHost { get; set; }
        public bool AutomaticRecoveryEnabled { get; set; }
        public ushort RequestedHeartbeat { get; set; }
    }
}
