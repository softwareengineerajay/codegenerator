﻿// Licensed to the .NET Foundation under one or more agreements.
// The .NET Foundation licenses this file to you under the MIT license.

namespace ESGenesis.RabbitMQ.Sdk
{
    /// <summary>
    ///   Interface to connect receiver and business logic interaction
    /// </summary>
    public interface IMessageProcessor
    {
        /// <summary>
        ///   Process the incoming message and calls business logic
        /// </summary>
        bool Process(string message);
    }
}
