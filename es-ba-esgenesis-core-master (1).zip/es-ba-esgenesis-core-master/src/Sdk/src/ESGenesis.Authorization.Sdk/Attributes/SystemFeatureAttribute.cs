﻿using ESGenesis.Authorization.Sdk.Clients;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.AspNetCore.Routing;
using Microsoft.Extensions.DependencyInjection;

namespace ESGenesis.Authorization.Sdk.Attributes
{
    [AttributeUsage(AttributeTargets.Class, AllowMultiple = true, Inherited = true)]
    public class SystemFeatureAttribute : Attribute, IAuthorizationFilter
    {
        public string FeatureCode { get; }
        public string Operation { get; set; }
        public SystemFeatureAttribute(string featureCode, string operation)
        {
            FeatureCode = featureCode;
            Operation = operation;
        }

        public void OnAuthorization(AuthorizationFilterContext context)
        {
            var userSecurityContext = context.HttpContext.RequestServices.GetService<IUserSecurityContext>();
            #region Get Controller and action name 
            var routeData = context.HttpContext.GetRouteData();
            // Get the controller and action names
            var controllerName = routeData.Values["controller"]?.ToString();
            #endregion
            if (userSecurityContext != null)
            {
                var hasAccess = userSecurityContext.CheckAccessAuthority(FeatureCode, Operation, controllerName);
                if (!hasAccess.Result)
                {
                    context.Result = new JsonResult(new { message = $"Unauthorized : You are not authorized , Feature : {FeatureCode} : Operation :{Operation}" })
                    {
                        StatusCode = StatusCodes.Status401Unauthorized
                    };
                }
            }
        }
    }
}
