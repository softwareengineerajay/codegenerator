﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.AspNetCore.Routing;
using Microsoft.AspNetCore.Mvc;
using ESGenesis.Authorization.Sdk.Clients;

namespace ESGenesis.Authorization.Sdk.Attributes
{
    [AttributeUsage(AttributeTargets.Method, AllowMultiple = true, Inherited = true)]
    public class AuthorizePermissionAttribute : Attribute, IAuthorizationFilter
    {
        public string FeatureCode { get; }
        public string Operation { get; set; }
        public AuthorizePermissionAttribute(string featureCode, string operation)
        {
            FeatureCode = featureCode;
            Operation = operation;
        }

        public void OnAuthorization(AuthorizationFilterContext context)
        {
            var userSecurityContext = context.HttpContext.RequestServices.GetService<IUserSecurityContext>();

            #region Get Controller and action name 
            var routeData = context.HttpContext.GetRouteData();

            var controllerName = routeData.Values["controller"]?.ToString();
            var actionName = routeData.Values["action"]?.ToString();
            #endregion

            if (userSecurityContext != null)
            {
                var hasAccess = userSecurityContext.CheckAccessAuthority(FeatureCode, Operation, controllerName, actionName);
                if (!hasAccess.Result)
                {
                    context.Result = new JsonResult(new { message = $"Unauthorized : You are not authorized , Feature : {FeatureCode} : Operation :{Operation}" })
                    {
                        StatusCode = StatusCodes.Status401Unauthorized
                    };
                }
            }
        }
    }
}
