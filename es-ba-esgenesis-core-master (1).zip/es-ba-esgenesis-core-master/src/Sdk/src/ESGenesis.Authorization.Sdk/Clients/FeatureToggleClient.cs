﻿using ESGenesis.Authorization.Sdk.Helpers;
using ESGenesis.Authorization.Sdk.Models;
using ESGenesis.Core.Sdk.Authentication;
using ESGenesis.Core.Sdk.Caching;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.Net.Http.Headers;
using System.Net.Http.Headers;
using System.Net.Http.Json;

namespace ESGenesis.Authorization.Sdk.Clients
{
    public interface IFeatureToggleClient
    {
        public Task<ToggleFeatures> GetUserToggleFeatures();
        bool HasAllowed(string feature);
    }

    public class FeatureToggleClient : IFeatureToggleClient
    {
        private readonly HttpClient httpClient;
        private readonly IHttpContextAccessor httpContextAccessor;
        private readonly IConfiguration configuration;
        private readonly ILogger<FeatureToggleClient> logger;
        private readonly ICache cache;
        private readonly ILoggedInUser loggedInUser;

        public FeatureToggleClient(HttpClient httpClient
            , IHttpContextAccessor httpContextAccessor
            , IConfiguration configuration
            , ICache cache
            , ILogger<FeatureToggleClient> logger
            , ILoggedInUser loggedInUser)
        {
            this.httpClient = httpClient;
            this.httpContextAccessor = httpContextAccessor;
            this.configuration = configuration;

            this.cache = cache;
            this.logger = logger;
            this.loggedInUser = loggedInUser;
        }

        public async Task<ToggleFeatures> GetUserToggleFeatures()
        {
            ToggleFeatures toggleFeatures = new ToggleFeatures();

            //var emailId = httpContextAccessor.HttpContext.Items["user_email_id"];
            //context.HttpContext.Items["user_email_id"]

            string? emailId = null;// = (string)httpContextAccessor.HttpContext.Items["user_email_id"];
            bool isImpersonatedUser = false;
            if (loggedInUser != null)
            {
                isImpersonatedUser = loggedInUser.IsExternalApp && !string.IsNullOrEmpty(loggedInUser.ImpersonatedUserId);
                emailId = isImpersonatedUser
                ? loggedInUser.ImpersonatedUserId
                    : loggedInUser.EmailId;
            }

            if (string.IsNullOrEmpty(emailId))
                throw new ArgumentException("Common-UserProfileService: user_email_id can not be null or empty");

            if (emailId != null)
            {
                logger.LogInformation($"User Toggle Features for user {emailId} will be fetched from cache.");
                toggleFeatures = await RedisCacheUtils.GetUserToggleFeaturesFromCacheAsync(loggedInUser.AppId, emailId.ToString(), cache);
            }

            if (toggleFeatures == null)
            {
                logger.LogInformation($"User Toggle Features for user {emailId} not found in cache. Fetching from UPM.");
                toggleFeatures = await GetUserToggleFeaturesFromUpm();
                if (toggleFeatures != null)
                {
                    await RedisCacheUtils.SetUserToggleFeaturesToCacheAsync(loggedInUser.AppId, emailId.ToString(), cache, toggleFeatures);
                }
            }
            else
            {
                logger.LogInformation($"User Toggle Features for user {emailId} found in cache.");
            }

            return toggleFeatures;

        }

        private async Task<ToggleFeatures> GetUserToggleFeaturesFromUpm()
        {
            ToggleFeatures toggleFeatures = new ToggleFeatures();

            var accessToken = httpContextAccessor.HttpContext?.Request.Headers[HeaderNames.Authorization];
            httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer"
                , accessToken.ToString().Replace("Bearer", string.Empty).Replace("bearer", string.Empty).Trim());

            string clientId = string.Empty;
            if (httpContextAccessor.HttpContext.Request.Headers.TryGetValue("Client_Id", out var id))
                clientId = id;

            httpClient.DefaultRequestHeaders.Add("Client_Id", string.IsNullOrEmpty(clientId) ? configuration["Default_Client_Id"] : clientId);

            // This is to pass the ACTIONBY header to UPM
            var actionBy = httpContextAccessor.HttpContext.Request.Headers["ACTIONBY"].FirstOrDefault();
            if (!string.IsNullOrEmpty(actionBy))
            {
                httpClient.DefaultRequestHeaders.Add("ACTIONBY", actionBy);
            }

            using (var result = await httpClient.GetAsync(Constants.UPM_FeatureToggle_URI))
            {
                if (result.IsSuccessStatusCode)
                {
                    toggleFeatures = await result.Content.ReadFromJsonAsync<ToggleFeatures>();
                }
            }
            return toggleFeatures;
        }
        public bool HasAllowed(string feature)
        {
            ToggleFeatures toggleFeatures = (ToggleFeatures)httpContextAccessor.HttpContext.Items["ToggleFeatures"];
            return toggleFeatures.ToggleFeatureList?.FirstOrDefault(x => x.FeatureCode.Equals(feature)) != null;

        }
    }
}
