﻿using ESGenesis.Authorization.Sdk.Helpers;
using ESGenesis.Authorization.Sdk.Models;
using ESGenesis.Core.Sdk.Authentication;
using ESGenesis.Core.Sdk.Caching;
using ESGenesis.Upm.Sdk.Models;

namespace ESGenesis.Authorization.Sdk.Clients
{
    public interface IUserSecurityContext
    {
        Task<bool> CheckAccessAuthority(string feature, string permissions, string controllerName = "", string actionName = "");
        //Task<bool> HasCompanyAccess(string companyCode);
        //Task<bool> HasCCAccess(string costCenterCode);
        //Task<bool> HasCompanyCCAccess(string companyCode, string costCenterCode);
    }

    public class UserSecurityContext : IUserSecurityContext
    {
        private readonly ICache cache;
        private readonly IUserProfileClient userProfileService;
        private readonly ILoggedInUser loggedInUser;

        public UserSecurityContext(
           IUserProfileClient userProfileService,
           ICache cache,
           ILoggedInUser loggedInUser)
        {
            this.userProfileService = userProfileService;
            this.cache = cache;
            this.loggedInUser = loggedInUser;
        }

        public async Task<bool> CheckAccessAuthority(string feature, string permissions, string controllerName = "", string actionName = "")
        {
            bool hasAccess = false;

            if (loggedInUser.IsExternalApp)
            {
                return await CheckExternalAppAccess(controllerName, actionName);
            }

            //UserProfileResponse userProfile = await RedisCacheUtils.GetUserProfileFromCacheAsync(loggedInUser.AppId, loggedInUser.EmailId, cache);

            //if (userProfile == null)
            //{
            //    userProfile = await userProfileService.GetUserProfile();
            //}

            UserProfileResponse userProfile = await userProfileService.GetUserProfile();

            if (userProfile != null)
            {
                hasAccess = userProfile.IsSuperAdmin;

                if (!hasAccess)
                {
                    var featureArray = feature.ToUpper().Split(new[] { "||" },
                        StringSplitOptions.RemoveEmptyEntries)
                        .Select(x => x.Trim())
                        .Where(x => string.IsNullOrWhiteSpace(x) == false);

                    hasAccess = userProfile.UserSystemFeaturePermissions
                        .Where(x => featureArray.Contains(x.SystemFeatureCode.ToUpper())
                        && x.PermissionName.Equals(permissions)).ToList().Count > 0;

                    //hasAccess = userProfile.UserSystemFeaturePermissions
                    //    .Where(x => x.SystemFeatureCode.Equals(feature)
                    //    && x.PermissionName.Equals(permissions)).ToList().Count > 0;
                }
            }
            return hasAccess;
        }

        private async Task<bool> CheckExternalAppAccess(string controllerName, string actionName)
        {
            if (!string.IsNullOrEmpty(loggedInUser.ImpersonatedUserId) && loggedInUser.TokenIssuerKey.ToLower() == "carbon")
            {
                var checkUserProfileForExternalUser = await userProfileService.CheckUserProfileForExternalUser(controllerName, actionName);
                return checkUserProfileForExternalUser;
            }
            return true;

        }

        //public async Task<bool> HasCompanyAccess(string companyCode)
        //{
        //    bool hasAccess = false;

        //    if (loggedInUser.IsExternalApp)
        //    {
        //        return true;
        //    }

        //    UserProfile userProfile = await RedisCacheUtils.GetUserProfileFromCacheAsync(loggedInUser.AppId, loggedInUser.EmailId, cache);
        //    if (userProfile == null)
        //    {
        //        userProfile = await userProfileService.GetUserProfile();
        //    }
        //    if (userProfile != null)
        //    {
        //        hasAccess = userProfile.IsSuperAdmin || userProfile.IsAdmin || userProfile.IsAllCompanyAccess || userProfile.IsAllBuAccess;
        //        if (!hasAccess)
        //        {
        //            hasAccess = userProfile.UserCompanies
        //                .Where(x => x.Code.Equals(companyCode)).ToList().Count > 0;
        //        }
        //        //if (!hasAccess)
        //        //{
        //        //    hasAccess = userProfile.UserBusinessUnits
        //        //        .Where(x => x.companycode.Equals(companyCode)).ToList().Count > 0;
        //        //}
        //    }
        //    return hasAccess;
        //}

        //public async Task<bool> HasCCAccess(string costCenterCode)
        //{
        //    bool hasAccess = false;

        //    if (loggedInUser.IsExternalApp)
        //    {
        //        return true;
        //    }

        //    UserProfile userProfile = await RedisCacheUtils.GetUserProfileFromCacheAsync(loggedInUser.AppId, loggedInUser.EmailId, cache);
        //    if (userProfile == null)
        //    {
        //        userProfile = await userProfileService.GetUserProfile();
        //    }
        //    if (userProfile != null)
        //    {
        //        hasAccess = userProfile.IsSuperAdmin || userProfile.IsAdmin || userProfile.IsAllCompanyAccess || userProfile.IsAllBuAccess;
        //        if (!hasAccess)
        //        {
        //            hasAccess = userProfile.UserBusinessUnits
        //                .Where(x => x.Businessunitcode.Equals(costCenterCode)).ToList().Count > 0;
        //        }
        //    }
        //    return hasAccess;
        //}
        //public async Task<bool> HasCompanyCCAccess(string companyCode, string costCenterCode)
        //{
        //    bool hasAccess = false;
        //    bool hasCompanyAccess = false;
        //    bool hasCCAccess = false;
        //    if (loggedInUser.IsExternalApp)
        //    {
        //        return true;
        //    }
        //    UserProfile userProfile = await RedisCacheUtils.GetUserProfileFromCacheAsync(loggedInUser.AppId, loggedInUser.EmailId, cache);
        //    if (userProfile == null)
        //    {
        //        userProfile = await userProfileService.GetUserProfile();
        //    }
        //    if (userProfile != null)
        //    {
        //        hasAccess = userProfile.IsSuperAdmin || userProfile.IsAdmin || userProfile.IsAllCompanyAccess || userProfile.IsAllBuAccess;
        //        if (!hasAccess)
        //        {
        //            hasCCAccess = userProfile.UserBusinessUnits
        //                .Where(x => x.Businessunitcode.Equals(costCenterCode)).ToList().Count > 0;
        //        }
        //        if (!hasAccess)
        //        {
        //            hasCompanyAccess = userProfile.UserCompanies
        //                .Where(x => x.Code.Equals(companyCode)).ToList().Count > 0;
        //        }
        //        if (hasCCAccess && hasCompanyAccess)
        //            hasAccess = true;
        //    }
        //    return hasAccess;
        //}
    }
}
