﻿using ESGenesis.Authorization.Sdk.Helpers;
using ESGenesis.Authorization.Sdk.Models;
using ESGenesis.Core.Sdk.Authentication;
using ESGenesis.Core.Sdk.Caching;
using ESGenesis.Core.Sdk.CQRS.Queries;
using ESGenesis.Core.Sdk.Exceptions;
using ESGenesis.Core.Sdk.Models;
using ESGenesis.Upm.Sdk.Models;
using ESGenesis.Upm.Sdk.Models.Query;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.Net.Http.Headers;
using System.Net;
using System.Net.Http.Headers;
using System.Net.Http.Json;

namespace ESGenesis.Authorization.Sdk.Clients
{
    public interface IUserProfileClient
    {
        public Task<UserProfileResponse> GetUserProfile();
        Task<bool> CheckUserProfileForExternalUser(string controllername, string actionname);
        // public Task<UserProfile> GetUserProfileByRedisCache();
    }

    public class UserProfileClient
        : IUserProfileClient
    {

        private const int dafaultCacheExpirationInDays = 1;
        private const int dafaultCacheExpirationInMinutes = 3;
        private readonly HttpClient httpClient;
        private readonly IHttpContextAccessor httpContextAccessor;
        private readonly IConfiguration configuration;
        private readonly ILogger<UserProfileClient> logger;
        private readonly ICache cache;
        private readonly ILoggedInUser loggedInUser;
        //private readonly IQueryBus queryBus;

        public UserProfileClient(HttpClient httpClient
            , IHttpContextAccessor httpContextAccessor
            , IConfiguration configuration
            , ICache cache
            , ILogger<UserProfileClient> logger
            , ILoggedInUser loggedInUser)
        //IQueryBus queryBus)
        {
            this.httpClient = httpClient;

            this.httpContextAccessor = httpContextAccessor;
            this.configuration = configuration;
            this.cache = cache;
            this.logger = logger;
            httpClient.DefaultRequestHeaders.CacheControl = new System.Net.Http.Headers.CacheControlHeaderValue
            {
                NoCache = true,
                NoStore = true
            };
            this.httpClient.Timeout = TimeSpan.FromMinutes(5);
            this.loggedInUser = loggedInUser;
            // this.queryBus = queryBus;
        }
        public async Task<UserProfileResponse> GetUserProfile()
        {
            UserProfileResponse? userProfile = null;

            string? emailId = null;// = (string)httpContextAccessor.HttpContext.Items["user_email_id"];
            bool isImpersonatedUser = false;
            if (loggedInUser != null)
            {
                isImpersonatedUser = loggedInUser.IsExternalApp && !string.IsNullOrEmpty(loggedInUser.ImpersonatedUserId);
                emailId = isImpersonatedUser
                    ? loggedInUser.ImpersonatedUserId
                    : loggedInUser.EmailId;
            }

            if (string.IsNullOrEmpty(emailId))
                throw new ArgumentException("Common-UserProfileService: user_email_id can not be null or empty");

            if (emailId != null)
            {
                logger.LogInformation($"Common-UserProfileService: User Profile for user {emailId} will be fetched from cache.");
                userProfile = await RedisCacheUtils.GetUserProfileFromCacheAsync(loggedInUser.AppId, emailId.ToString(), cache);
            }

            if (userProfile == null)
            {
                logger.LogInformation($"Common-UserProfileService: User Profile for user {emailId} not found in cache. Fetching from UPM.");
                userProfile = await GetUserProfileFromUpm();
                //userProfile = await GetUserProfileFromUpmByQuery();
                if (userProfile != null)
                {
                    await RedisCacheUtils.SetUserProfileToCacheAsync(loggedInUser.AppId, userProfile.Email, cache, userProfile);
                }
            }
            else
            {
                logger.LogInformation($"Common-UserProfileService: User Profile for user {emailId} found in cache.");
            }

            return userProfile;
        }

        //private async Task<UserProfileResponse> GetUserProfileFromUpmByQuery()
        //{
        //    var appId = configuration.GetValue<int>("ApplicationId");

        //    GetUserProfileQuery getUserProfileQuery = new GetUserProfileQuery(appId);
        //    var result = await queryBus.Send<GetUserProfileQuery, IBusinessResult<UserResponseResult, UserProfileResponse>>(getUserProfileQuery);

        //    if (result.IsFailure || result.Result == null)
        //    {
        //        return null;
        //    }
        //    else
        //    {
        //        return result.Result;
        //    }
        //}

        private async Task<UserProfileResponse> GetUserProfileFromUpm()
        {
            UserProfileResponse? userProfile = null; //new UserProfile();

            string clientId = configuration["Default_Client_Id"] ?? string.Empty;
            string appId = configuration["ApplicationId"] ?? string.Empty;
            if (httpContextAccessor.HttpContext.Request.Headers.TryGetValue("Client_Id", out var id))
                clientId = id;
            var accessToken = httpContextAccessor.HttpContext.Request.Headers[HeaderNames.Authorization];

            httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer"
                , accessToken.ToString().Replace("Bearer", "").Replace("bearer", "").Trim());

            httpClient.DefaultRequestHeaders.Add("Client_Id", string.IsNullOrEmpty(clientId) ? configuration["Default_Client_Id"] : clientId);

            // This is to pass the ACTIONBY header to UPM
            var actionBy = httpContextAccessor.HttpContext.Request.Headers["ACTIONBY"].FirstOrDefault();
            if (!string.IsNullOrEmpty(actionBy))
            {
                httpClient.DefaultRequestHeaders.Add("ACTIONBY", actionBy);
            }

            //using (var result = await httpClient.GetAsync(configuration["UPM_User_Profile_URI"]))
            using (var result = await httpClient.GetAsync($"{Helpers.Constants.UPM_User_Profile_URI}{appId}"))
            {
                if (result.IsSuccessStatusCode)
                {
                    userProfile = await result.Content.ReadFromJsonAsync<UserProfileResponse>();
                }
            }

            return userProfile;
        }

        public async Task<bool> CheckUserProfileForExternalUser(string controllername, string actionname)
        {
            var externalAppAcccessResponse = new List<ExternalApiAccessResponse>();
            string clientId = string.Empty;
            if (httpContextAccessor.HttpContext.Request.Headers.TryGetValue("Client_Id", out var id))
                clientId = id;
            var accessToken = httpContextAccessor.HttpContext.Request.Headers[HeaderNames.Authorization];

            httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer"
                , accessToken.ToString().Replace("Bearer", "").Replace("bearer", "").Trim());

            httpClient.DefaultRequestHeaders.Add("Client_Id", string.IsNullOrEmpty(clientId) ? configuration["Default_Client_Id"] : clientId);

            // This is to pass the ACTIONBY header to UPM
            var actionBy = httpContextAccessor.HttpContext.Request.Headers["ACTIONBY"].FirstOrDefault();
            if (!string.IsNullOrEmpty(actionBy))
            {
                httpClient.DefaultRequestHeaders.Add("ACTIONBY", actionBy);
            }
            string url = configuration["TitanInternalServiceBaseUrl"] + Helpers.Constants.UPM_External_ACCESS;
            using (var result = await httpClient.GetAsync(url))
            {
                if (result.IsSuccessStatusCode)
                {

                    externalAppAcccessResponse = await result.Content.ReadFromJsonAsync<List<ExternalApiAccessResponse>>();
                    return externalAppAcccessResponse.Any(x => x.ApiController == controllername && x.ApiActionMethod == actionname);
                }
                else
                {
                    return false;
                }

            }
        }
    }
}
