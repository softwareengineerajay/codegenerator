﻿
namespace ESGenesis.Authorization.Sdk.Helpers
{
    public static class Constants
    {
        #region Feature Toggle Constants

        public const string Features_Toggle_Unauthorized_Error = "Features flag of Feature:{0} is OFF for User";

        public readonly static string UPM_FeatureToggle_URI = "/upmsvc/api/ToggleFeatures/User";

        #endregion

        #region User Permission Constants
        public const string ADD = "Add";
        public const string EDIT = "Edit";
        public const string DELETE = "Delete";
        public const string DEFAULT_ERP_SYSTEM = "JDE";
#if DEBUG
        public readonly static string UPM_User_Profile_URI = "/api/v1/UserProfiles/";
        public readonly static string UPM_External_ACCESS = "/api/v1/UserProfiles/ExternalAppApiAccess/";
#else
        public readonly static string UPM_User_Profile_URI = "/upmsvc/api/v1/UserProfiles/";
        public readonly static string UPM_External_ACCESS = "/upmsvc/api/v1/UserProfiles/ExternalAppApiAccess.";
#endif
#endregion
    }
}
