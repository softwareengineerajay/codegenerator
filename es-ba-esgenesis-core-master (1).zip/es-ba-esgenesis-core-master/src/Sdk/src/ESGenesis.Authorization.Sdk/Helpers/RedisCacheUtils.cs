﻿using System.Text.RegularExpressions;
using System.Text;
using ESGenesis.Core.Sdk.UtilityClasses;
using ESGenesis.Authorization.Sdk.Models;
using ESGenesis.Core.Sdk.Caching;
using ESGenesis.Upm.Sdk.Models;

namespace ESGenesis.Authorization.Sdk.Helpers
{
    public static class RedisCacheUtils
    {

        private static string GetUserToggleFeaturesRedisKey(int appId, string currentUserEmailId)
        {
            var enviornmentCode = CommonMethods.GetEnviornment();
            var email = $"{appId}-{currentUserEmailId.Trim()}-ft-{enviornmentCode}";
            return ConvertEmailToRedisKey(email);
        }

        private static string GetUserRedisKey(int appId, string currentUserEmailId)
        {
            var enviornmentCode = CommonMethods.GetEnviornment();
            var email = $"{appId}-{currentUserEmailId.Trim()}-{enviornmentCode}";
            return ConvertEmailToRedisKey(email);
        }

        private static string ConvertEmailToRedisKey(string emailAddress)
        {
            if(string.IsNullOrEmpty(emailAddress))
            {
                throw new System.ArgumentException("RedisCacheUtils.ConvertEmailToRedisKey: Email address cannot be null or empty", nameof(emailAddress));
            }

            // Remove special characters and replace them with underscores
            string sanitizedEmail = Regex.Replace(emailAddress.Trim().ToLower(), @"[^0-9a-zA-Z]+", "_");

            // Encode the string to ensure it's safe for use as a Redis key
            byte[] encodedBytes = Encoding.UTF8.GetBytes(sanitizedEmail);
            string redisKey = Convert.ToBase64String(encodedBytes);

            return redisKey;
        }

        #region User Profile Cache Methods
        // write a method to get UserProfile from ICache using GetUserRedisKey
        public static async Task<UserProfileResponse> GetUserProfileFromCacheAsync(int appId, string currentUserEmailId, ICache cache)
        {
            UserProfileResponse userProfile = null;
            try
            {
                var userRedisKey = GetUserRedisKey(appId, currentUserEmailId);
                userProfile = await cache.GetAsync<UserProfileResponse>(userRedisKey);
            }
            catch (System.Exception ex)
            {
                //logger.LogError("Exception thrown while getting user profile from ICache: " + ex.ToString());
            }
            return userProfile;
        }

        // write a method to set UserProfile to ICache using GetUserRedisKey
        public static async Task SetUserProfileToCacheAsync(int appId, string currentUserEmailId, ICache cache, UserProfileResponse userProfile)
        {
            try
            {
                var userRedisKey = GetUserRedisKey(appId, currentUserEmailId);
                await cache.AddWithLockAsync(userRedisKey, userProfile, new TimeSpan(24,0,0), new TimeSpan(0,0,1));
            }
            catch (System.Exception ex)
            {
                //logger.LogError("Exception thrown while setting user profile to ICache: " + ex.ToString());
            }
        }

        public static async Task<bool> RemoveUserProfileFromCacheAsync(int appId, string currentUserEmailId, ICache cache)
        {
            bool isDeleted = false;
            try
            {
                var userRedisKey = GetUserRedisKey(appId, currentUserEmailId);
                isDeleted = await cache.RemoveWithLockAsync(userRedisKey, new TimeSpan(0,0,1));
            }
            catch (System.Exception ex)
            {
                //logger.LogError("Exception thrown while setting user profile to ICache: " + ex.ToString());
            }
            return isDeleted;
        }
        #endregion

        #region User Feature Toggle Cache Methods
        // write a method to get UserProfile from ICache using GetUserRedisKey
        public static async Task<ToggleFeatures> GetUserToggleFeaturesFromCacheAsync(int appId, string currentUserEmailId, ICache cache)
        {
            ToggleFeatures userToggleFeatures = null;
            try
            {
                var userToggleFeaturesRedisKey = GetUserToggleFeaturesRedisKey(appId, currentUserEmailId);
                userToggleFeatures = await cache.GetAsync<ToggleFeatures>(userToggleFeaturesRedisKey);
            }
            catch (System.Exception ex)
            {
                //logger.LogError("Exception thrown while getting user profile from ICache: " + ex.ToString());
            }
            return userToggleFeatures;
        }

        // write a method to set UserProfile to ICache using GetUserRedisKey
        public static async Task SetUserToggleFeaturesToCacheAsync(int appId, string currentUserEmailId, ICache cache, ToggleFeatures toggleFeatures)
        {
            try
            {
                var userToggleFeaturesRedisKey = GetUserToggleFeaturesRedisKey(appId, currentUserEmailId);
                await cache.AddWithLockAsync(userToggleFeaturesRedisKey, toggleFeatures, new TimeSpan(24, 0, 0), new TimeSpan(0, 0, 1));
            }
            catch (System.Exception ex)
            {
                //logger.LogError("Exception thrown while setting user profile to ICache: " + ex.ToString());
            }
        }

        public static async Task<bool> RemoveUserToggleFeaturesFromCacheAsync(int appId, string currentUserEmailId, ICache cache)
        {
            bool isDeleted = false;
            try
            {
                var userToggleFeaturesRedisKey = GetUserToggleFeaturesRedisKey(appId, currentUserEmailId);
                isDeleted = await cache.RemoveWithLockAsync(userToggleFeaturesRedisKey, new TimeSpan(0, 0, 1));
            }
            catch (System.Exception ex)
            {
                //logger.LogError("Exception thrown while setting user profile to ICache: " + ex.ToString());
            }
            return isDeleted;
        }
        #endregion

    }
}
