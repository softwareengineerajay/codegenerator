﻿using ESGenesis.Core.Sdk.Authentication;
using Microsoft.AspNetCore.Mvc.Filters;
using Serilog.Context;

namespace ESGenesis.Authorization.Sdk.ActionFilters
{
    [AttributeUsage(AttributeTargets.All)]
    public class LogLoggedInUserResourceFilter
        : Attribute, IResourceFilter
    {
        private readonly ILoggedInUser loggedInUser;

        public LogLoggedInUserResourceFilter(ILoggedInUser loggedInUser)
        {
            this.loggedInUser = loggedInUser;
        }

        public void OnResourceExecuted(ResourceExecutedContext context)
        {
            LogLoggedInUser();
        }

        public void OnResourceExecuting(ResourceExecutingContext context)
        {
            LogLoggedInUser();
        }

        private void LogLoggedInUser()
        {
            if (loggedInUser != null)
            {
                LogContext.PushProperty("LoggedInUser", string.IsNullOrEmpty(loggedInUser.EmailId) ? "-" : loggedInUser.EmailId);
                LogContext.PushProperty("TokenIssuerKey", loggedInUser.TokenIssuerKey ?? "");
                LogContext.PushProperty("ImpersonatedUser", loggedInUser.ImpersonatedUserId ?? "");
            }
            else
            {
                LogContext.PushProperty("LoggedInUser", "Logged in user instance not available");
            }
        }
    }
}
