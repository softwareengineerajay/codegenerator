﻿namespace ESGenesis.Authorization.Sdk.Models
{
    public class ToggleFeature
    {
        public int AppId { get; set; }
        public required string ModuleName​ { get; set; }
        public string? FeatureDescription { get; set; }
        public required string FeatureCode​ { get; set; }
        public string? JiraTicket​ { get; set; }
    }
}
