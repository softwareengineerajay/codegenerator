﻿namespace ESGenesis.Authorization.Sdk.Models
{
    public class UserSystemFeaturePermissions
    {
        public required string PermissionId { get; set; }
        public required string Code { get; set; }
        public string? Description { get; set; }
        public string? PermissionName { get; set; }
    }
}
