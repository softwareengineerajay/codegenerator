﻿namespace ESGenesis.Authorization.Sdk.Models
{
    public class UserServiceLocation
    {
        public string? Ticket { get; set; }
        public int ServiceLocationId { get; set; }
        public int UserId { get; set; }
    }
}
