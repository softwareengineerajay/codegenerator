﻿namespace ESGenesis.Authorization.Sdk.Models
{
    public class UserCompany
    {
        public int? Companyid { get; set; }
        public string? Name { get; set; }
        public string? Code { get; set; }
        public string? Currency { get; set; }
        public string? Email { get; set; }
        public bool IsToolMovementDocRequired { get; set; }
        public bool Isshiptopsrequired { get; set; }
        public bool IsSlipSequenceChangeAllowed { get; set; }
        public bool ProcesserpItems { get; set; }
        public bool IsJobRequired { get; set; }
        public bool IsRemitoAllowed { get; set; }
    }
}

