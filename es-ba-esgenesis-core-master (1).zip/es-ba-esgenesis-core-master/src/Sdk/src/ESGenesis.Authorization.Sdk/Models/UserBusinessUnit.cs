﻿namespace ESGenesis.Authorization.Sdk.Models
{
    public class UserBusinessUnit
    {
        public int? Businessunitid { get; set; }
        public int? Companyid { get; set; }
        public string? Businessunitname { get; set; }
        public string? Businessunitcode { get; set; }
        public string? RelatedBu { get; set; }
        public string? CountryCode { get; set; }
        public string? DivisionCode { get; set; }
        public string? Email { get; set; }

    }
}
