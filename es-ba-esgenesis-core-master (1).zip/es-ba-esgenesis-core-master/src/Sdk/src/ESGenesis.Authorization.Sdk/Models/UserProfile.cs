﻿using ESGenesis.Upm.Sdk.Models;

namespace ESGenesis.Authorization.Sdk.Models
{
    //public class UserProfile
    //{
    //    public int Id { get; set; }
    //    public required string Email { get; set; }
    //    public string? Firstname { get; set; }
    //    public string? LastName { get; set; }
    //    public string? NTLoginID { get; set; }
    //    public bool IsAdmin { get; set; }
    //    public bool IsSuperAdmin { get; set; }
    //    public bool IsAllBuAccess { get; set; }
    //    public bool IsAllCompanyAccess { get; set; }
    //    public bool IsAllServiceLocationAccess { get; set; }
    //    public required string ClientId { get; set; }
    //    public int AppId { get; set; }
    //    public List<UserSystemFeaturePermissions> UserSystemFeaturePermissions { get; set; }
    //    public List<UserCompany> UserCompanies { get; set; }
    //    public List<UserBusinessUnit> UserBusinessUnits { get; set; }
    //    public List<UserServiceLocation> UserServiceLocations { get; set; }
    //}

    public class  UserProfile
    {
        public int Id { get; set; }
        public int AppId { get; set; }
        public required string ClientId { get; set; }
        public required string Email { get; set; }
        public string? GenercEmail { get; set; }
        public string? FirstName { get; set; }
        public string? LastName { get; set; }
        public string? NtLoginId { get; set; }
        public bool IsSuperAdmin { get; set; }
        public int? Pin { get; set; }
        public string? ModifiedBy { get; set; }
        public DateTime? ModifiedDate { get; set; }
        public List<UserSystemFeaturePermission>? UserSystemFeaturePermissions { get; set; }
    }
}
