﻿namespace ESGenesis.Authorization.Sdk.Models
{
    public class ToggleFeatures
    {
        public List<ToggleFeature>? ToggleFeatureList { get; set; }
    }
}
