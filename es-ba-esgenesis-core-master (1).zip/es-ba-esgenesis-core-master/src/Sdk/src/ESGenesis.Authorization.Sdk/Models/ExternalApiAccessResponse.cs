﻿namespace ESGenesis.Authorization.Sdk.Models
{
    public class ExternalApiAccessResponse
    {
        public int Id { get; set; }
        public required string ApiUrl { get; set; }
        public required string HttpMethod { get; set; }
        public required string ApiController { get; set; }
        public required string ApiActionMethod { get; set; }
        public required string UserEmail { get; set; }
    }
}
