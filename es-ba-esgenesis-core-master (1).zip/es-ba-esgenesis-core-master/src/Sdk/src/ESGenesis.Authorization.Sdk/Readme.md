﻿ESGenesis Authorization SDK V1.0.0
