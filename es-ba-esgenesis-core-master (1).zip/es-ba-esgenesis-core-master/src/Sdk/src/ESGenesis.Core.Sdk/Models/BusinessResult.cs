﻿// Licensed to the .NET Foundation under one or more agreements.
// The .NET Foundation licenses this file to you under the MIT license.

using System.Diagnostics.CodeAnalysis;
using System.Runtime.Serialization;

namespace ESGenesis.Core.Sdk.Models
{
    /// <summary>
    ///   Class to return a BusinessResult, aka return an IsSuccessful value, a ResultCode indicating error code, and a Result
    ///   value
    /// </summary>
    /// <typeparam name="TResultCode">enum to represent the different possible Result Codes</typeparam>
    /// <typeparam name="TResult">Return value if sucsessful</typeparam>
    public class BusinessResult<TResultCode, TResult> : IBusinessResult<TResultCode, TResult>
        where TResultCode : struct, IConvertible
        where TResult : class
    {
        /// <summary>
        ///   Constructs a Failed Business Result
        /// </summary>
        /// <param name="resultCode">The error result code to return</param>
        /// <param name="errorKey">Key for error message (can be blank)</param>
        /// <param name="errorMessage">Error message</param>
        public BusinessResult(TResultCode resultCode, string errorKey, string errorMessage)
            : this(false, resultCode, null, errorKey, errorMessage)
        {
        }

        /// <summary>
        ///   Constructs a Failed Business Result
        /// </summary>
        /// <param name="resultCode">The error result code to return</param>
        /// <param name="errorMessage">Error message</param>
        /// <remarks>
        ///   error Key will be blank
        /// </remarks>
        public BusinessResult(TResultCode resultCode, string errorMessage)
            : this(false, resultCode, null, String.Empty, errorMessage)
        {
        }

        /// <summary>
        ///   Constructs a Business Result
        /// </summary>
        /// <param name="isSuccessful">Is this a Success? (false if it represents a failure)</param>
        /// <param name="resultCode">The error result code to return</param>
        /// <param name="errorMessage">Error message</param>
        /// <remarks>
        ///   error Key will be blank
        /// </remarks>
        public BusinessResult(bool isSuccessful, TResultCode resultCode, string errorMessage)
            : this(isSuccessful, resultCode, null, String.Empty, errorMessage)
        {
        }

        /// <summary>
        ///   Constructs a Failed Business Result
        /// </summary>
        /// <param name="resultCode">The error result code to return</param>
        /// <remarks>
        ///   error Key and message will be null
        /// </remarks>
        public BusinessResult(TResultCode resultCode)
            : this(false, resultCode, null, null, null)
        {
        }

        /// <summary>
        ///   Constructs a Successful Business Result
        /// </summary>
        /// <param name="resultCode">The result code to return (usually an Okay code)</param>
        /// <param name="result">Result value from the success</param>
        public BusinessResult(TResultCode resultCode, TResult result)
            : this(true, resultCode, result, null, null)
        {
        }

        /// <summary>
        ///   Constructs a Business Result
        /// </summary>
        /// <param name="isSuccessful">Is this a Success? (false if it represents a failure)</param>
        /// <param name="resultCode">The error result code to return (or an Okay if this is a success)</param>
        /// <param name="result">Result value from the success</param>
        /// <param name="errorKey">Key for error message (can be blank)</param>
        /// <param name="errorMessage">Error message</param>
        /// <remarks>
        ///   This is the constructor that allows complete control
        /// </remarks>
        public BusinessResult(bool isSuccessful, TResultCode resultCode, TResult result, string errorKey, string errorMessage)
            : this()
        {
            this.Success = isSuccessful;
            this.ResultCode = resultCode;
            this.Result = result;
            if ((String.IsNullOrEmpty(errorKey) == false) || (String.IsNullOrEmpty(errorMessage) == false))
            {
                this.AddError(errorKey ?? String.Empty, errorMessage ?? String.Empty);
            }
        }

        /// <summary>
        ///   Constructs a Business Result
        /// </summary>
        /// <param name="isSuccessful">Is this a Success? (false if it represents a failure)</param>
        /// <param name="resultCode">The error result code to return (or an Okay if this is a success)</param>
        /// <param name="result">Result value from the success</param>
        /// <param name="errors">Dictionary of errors (keys and messages)</param>
        /// <remarks>
        ///   This is the constructor that allows complete control
        /// </remarks>
        [SuppressMessage("Microsoft.Design", "CA1006:DoNotNestGenericTypesInMemberSignatures", Justification = "Desired API")]
        public BusinessResult(bool isSuccessful, TResultCode resultCode, TResult result, IEnumerable<KeyValuePair<string, string>> errors)
            : this()
        {
            this.Success = isSuccessful;
            this.ResultCode = resultCode;
            this.Result = result;
            this.AddError(errors);
        }

        private BusinessResult()
        {
            this.Errors = new List<KeyValuePair<string, string>>();
            this.ResultCode = default(TResultCode);
        }

        protected bool Success { get; set; }

        [DataMember]
        public bool IsSuccessful { get { return this.Success == true; } }

        [DataMember]
        public bool IsFailure { get { return this.Success == false; } }

        [SuppressMessage("Microsoft.Design", "CA1006:DoNotNestGenericTypesInMemberSignatures")]
        [DataMember]
        protected ICollection<KeyValuePair<string, string>> Errors { get; private set; }

        [DataMember]
        public TResult Result { get; set; }

        [DataMember]
        public TResultCode ResultCode { get; set; }

        [DataMember]
        public bool HasErrorMessages { get { return this.Errors.Count > 0; } }

        [SuppressMessage("Microsoft.Design", "CA1006:DoNotNestGenericTypesInMemberSignatures")]
        public IEnumerable<KeyValuePair<string, string>> ErrorMessagesWithKeys { get { return this.Errors; } }

        public IEnumerable<string> ErrorMessages { get { return this.Errors.Select(x => x.Value).ToList(); } }

        public void AddError(string errorKey, string errorMessage)
        {
            this.Errors.Add(new KeyValuePair<string, string>(errorKey, errorMessage));
        }

        public void AddError(KeyValuePair<string, string> errorPair)
        {
            this.AddError(errorPair.Key, errorPair.Value);
        }

        [SuppressMessage("Microsoft.Design", "CA1006:DoNotNestGenericTypesInMemberSignatures")]
        public void AddError(IEnumerable<KeyValuePair<string, string>> errors)
        {
            foreach (var error in errors)
            {
                this.Errors.Add(error);
            }
        }
    }

}
