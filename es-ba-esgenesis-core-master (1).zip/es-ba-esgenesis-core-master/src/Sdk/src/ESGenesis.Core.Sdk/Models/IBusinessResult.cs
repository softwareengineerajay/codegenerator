﻿// Licensed to the .NET Foundation under one or more agreements.
// The .NET Foundation licenses this file to you under the MIT license.

using System.Diagnostics.CodeAnalysis;
using System.Runtime.Serialization;

namespace ESGenesis.Core.Sdk.Models
{
    public interface IBusinessResult<TResultCode, TResult>
        where TResultCode : struct, IConvertible
    {
        [DataMember]
        TResult Result { get; set; }

        [DataMember]
        TResultCode ResultCode { get; set; }

        [DataMember]
        bool HasErrorMessages { get; }

        [SuppressMessage("Microsoft.Design", "CA1006:DoNotNestGenericTypesInMemberSignatures")]
        [DataMember]
        IEnumerable<KeyValuePair<string, string>> ErrorMessagesWithKeys { get; }

        [DataMember]
        IEnumerable<string> ErrorMessages { get; }

        [DataMember]
        bool IsSuccessful { get; }

        [DataMember]
        bool IsFailure { get; }

        void AddError(string errorKey, string errorMessage);
        void AddError(KeyValuePair<string, string> errorPair);

        [SuppressMessage("Microsoft.Design", "CA1006:DoNotNestGenericTypesInMemberSignatures")]
        void AddError(IEnumerable<KeyValuePair<string, string>> errors);
    }

}
