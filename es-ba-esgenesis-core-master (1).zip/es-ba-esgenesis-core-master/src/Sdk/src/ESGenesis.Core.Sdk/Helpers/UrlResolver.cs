﻿//// Licensed to the .NET Foundation under one or more agreements.
//// The .NET Foundation licenses this file to you under the MIT license.

//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;
//using AutoMapper;
//using ESGenesis.Core.Sdk.Helpers.Models;
//using Microsoft.AspNetCore.Mvc;

//namespace ESGenesis.Core.Sdk.Helpers
//{
//    /// <summary>
//    /// Resolves the URL links that are needed for self referenced Ids in the objects that are returned as part of the API. Used by AutoMapper to generate the links in the response object.
//    /// </summary>
//    public class UrlResolver : IMemberValueResolver<object, object, RouteUrlInfo, String>
//    {
//        /// <summary>
//        /// Initializes a new instance of the <see cref="UrlResolver"/> class.
//        /// </summary>
//        /// <param name="urlHelper"></param>
//        public UrlResolver(IUrlHelper urlHelper)
//        {
//            this._UrlHelper = urlHelper;
//        }

//        private IUrlHelper _UrlHelper { get; set; }

//        /// <summary>
//        /// This method will return the link to the object that is referenced by the Id field that matches.
//        /// </summary>
//        /// <param name="source"></param>
//        /// <param name="destination"></param>
//        /// <param name="sourceMember"></param>
//        /// <param name="destMember"></param>
//        /// <param name="context"></param>
//        /// <returns>URL for API call to get Details of object</returns>
//        public virtual string Resolve(object source, object destination, RouteUrlInfo sourceMember, string destMember, ResolutionContext context)
//        {
//            return this._UrlHelper.Link(sourceMember.RouteName, sourceMember.RouteParams);
//        }
//    }
//}
