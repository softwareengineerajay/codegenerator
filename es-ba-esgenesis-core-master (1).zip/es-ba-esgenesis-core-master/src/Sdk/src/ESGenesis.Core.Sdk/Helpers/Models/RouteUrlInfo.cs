﻿// Licensed to the .NET Foundation under one or more agreements.
// The .NET Foundation licenses this file to you under the MIT license.

namespace ESGenesis.Core.Sdk.Helpers.Models
{
    /// <summary>
    /// The Url information that is used to Resolve the Links needed for self referencing links in the response objects.
    /// </summary>
    public class RouteUrlInfo
    {
        /// <summary>
        /// Gets or sets name of the Route needed. Will match with the Http Method Attribute on the controller method.
        /// </summary>
        public String RouteName { get; set; }

        /// <summary>
        /// Gets or sets parameters needed to call the named route.
        /// </summary>
        public object RouteParams { get; set; }
    }
}
