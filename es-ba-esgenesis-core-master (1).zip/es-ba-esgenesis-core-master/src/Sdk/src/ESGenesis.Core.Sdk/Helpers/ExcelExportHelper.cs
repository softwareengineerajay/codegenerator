﻿using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Spreadsheet;

namespace ESGenesis.Core.Sdk.Helpers
{
    public static class ExcelExportHelper
    {
        public static string WriteExportToExcel<T>(IEnumerable<T> data, string fileName, string filePath, Dictionary<string, string> columnskeyValuePairs, string sheetName = "Records")
        {
            var fullFilename = Path.Combine(filePath, fileName);
            using (SpreadsheetDocument xl = SpreadsheetDocument.Create(fullFilename, SpreadsheetDocumentType.Workbook))
            {
                List<OpenXmlAttribute> oxa;
                OpenXmlWriter oxw;

                xl.AddWorkbookPart();
                WorksheetPart wsp = xl.WorkbookPart.AddNewPart<WorksheetPart>();

                oxw = OpenXmlWriter.Create(wsp);
                oxw.WriteStartElement(new Worksheet());
                oxw.WriteStartElement(new SheetData());

                var columns = columnskeyValuePairs.Select(x => x.Value).ToList();

                //For Columns header
                for (int i = 1; i <= 1; ++i)
                {
                    oxa = new List<OpenXmlAttribute>();
                    oxa.Add(new OpenXmlAttribute("r", null, i.ToString()));
                    oxw.WriteStartElement(new Row(), oxa);
                    foreach (var item in columns)
                    {
                        oxa = new List<OpenXmlAttribute>();
                        oxa.Add(new OpenXmlAttribute("t", null, "str"));
                        oxw.WriteStartElement(new Cell(), oxa);
                        oxw.WriteElement(new CellValue(item));
                        oxw.WriteEndElement();
                    }
                    oxw.WriteEndElement();
                }

                //For Row records
                int j = 2;
                foreach (var item in data)
                {
                    oxa = new List<OpenXmlAttribute>();
                    oxa.Add(new OpenXmlAttribute("r", null, j.ToString()));
                    oxw.WriteStartElement(new Row(), oxa);
                    foreach (var column in columnskeyValuePairs)
                    {
                        oxa = new List<OpenXmlAttribute>();
                        oxa.Add(new OpenXmlAttribute("t", null, "str"));
                        oxw.WriteStartElement(new Cell(), oxa);
                        oxw.WriteElement(new CellValue(item.GetType().GetProperty(column.Key).GetValue(item)?.ToString()));
                        oxw.WriteEndElement();
                    }
                    oxw.WriteEndElement();
                    j++;
                }

                oxw.WriteEndElement();
                oxw.WriteEndElement();
                oxw.Close();

                oxw = OpenXmlWriter.Create(xl.WorkbookPart);
                oxw.WriteStartElement(new Workbook());
                oxw.WriteStartElement(new Sheets());
                oxw.WriteElement(new Sheet()
                {
                    Name = "Sheet1",
                    SheetId = 1,
                    Id = xl.WorkbookPart.GetIdOfPart(wsp)
                });
                oxw.WriteEndElement();
                oxw.WriteEndElement();
                oxw.Close();
            }
            return fullFilename;
        }
    }
}
