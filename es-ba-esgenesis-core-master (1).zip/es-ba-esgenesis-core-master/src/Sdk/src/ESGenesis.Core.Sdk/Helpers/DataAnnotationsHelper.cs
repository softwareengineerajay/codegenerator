﻿// Licensed to the .NET Foundation under one or more agreements.
// The .NET Foundation licenses this file to you under the MIT license.

using System.ComponentModel.DataAnnotations;
using ESGenesis.Core.Sdk.Models;

namespace ESGenesis.Core.Sdk.Helpers
{
    public enum DataAnnotationsValidationResultCode
    {
        None = 0,
        Okay = 1,
        Invalid = -1
    }

    public static class DataAnnotationsHelper
    {
        public static IBusinessResult<DataAnnotationsValidationResultCode, TModel> ValidateModel<TModel>(TModel model)
            where TModel : class
        {
            var validationResults = new List<ValidationResult>();
            var context = new ValidationContext(model, null, null);
            Validator.TryValidateObject(model, context, validationResults, true);

            if (validationResults.Count > 0)
            {
                var errorMessages = validationResults.Select(x => new KeyValuePair<string, string>("DataAnnotationValidationError", x.ErrorMessage)).ToList();
                return new BusinessResult<DataAnnotationsValidationResultCode, TModel>(false, DataAnnotationsValidationResultCode.Invalid, null, errorMessages);
            }

            return new BusinessResult<DataAnnotationsValidationResultCode, TModel>(true, DataAnnotationsValidationResultCode.Okay, null, String.Empty, String.Empty);
        }
    }

}
