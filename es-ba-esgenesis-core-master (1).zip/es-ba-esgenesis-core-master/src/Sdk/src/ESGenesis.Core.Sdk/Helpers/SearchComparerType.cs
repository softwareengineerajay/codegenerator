﻿// Licensed to the .NET Foundation under one or more agreements.
// The .NET Foundation licenses this file to you under the MIT license.

namespace ESGenesis.Core.Sdk.Helpers
{
    public enum SearchComparerType
    {
        EqualTo = 0,
        BeginsWith = 1,
        Contains = 2,
        EndsWith = 3,
        NotEqualTo = 4
    }
}
