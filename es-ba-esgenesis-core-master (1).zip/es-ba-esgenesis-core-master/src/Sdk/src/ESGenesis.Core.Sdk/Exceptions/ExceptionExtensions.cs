﻿using System.Net;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.Extensions.Logging;

namespace ESGenesis.Core.Sdk.Exceptions
{
    public static class ExceptionExtensions
    {
        private static readonly Dictionary<string, Func<ExceptionContext, int, string, ErrorModel>> exceptionMap
            = new Dictionary<string, Func<ExceptionContext, int, string, ErrorModel>>()
        {
                {Constants.ArgumentException, ArgumentExceptionHandler},
                {Constants.NullReferenceException, NullReferenceExceptionHandler},
                {Constants.TimeoutException, TimeoutExceptionHandler},
                {Constants.SqlException , SqlExceptionHandler }

        };
        private const string GUID_Error_Key = "ErrorId:";
        public static ErrorModel GetCustomErrorModel(ExceptionContext context, string requestId, string traceId, int moduleNo, string baseHelpUrl)
        {
            var errorModel = new ErrorModel
            {
                Code = (int)HttpStatusCode.InternalServerError,
                Error = $"{moduleNo}-{Constants.UNKNOWN}",
                Message = Constants.EX_INTERNAL_ERROR,
                Details = context.Exception.Message,
                RequestId = requestId,
                TraceId = traceId,
                HelpUrl = $"{baseHelpUrl}/ISE"
            };

            if (exceptionMap.TryGetValue(context.Exception.GetType().Name
                , out Func<ExceptionContext, int, string, ErrorModel> customExceptionHandler))
                errorModel = customExceptionHandler(context, moduleNo, baseHelpUrl);

            return errorModel;

        }
        private static ErrorModel ArgumentExceptionHandler(ExceptionContext context, int moduleNo, string baseHelpUrl)
        {
            var errorModel = new ErrorModel
            {
                Code = (int)HttpStatusCode.BadRequest,
                Error = $"{moduleNo}-{Constants.ARGUMENT_EXCEPTION}",
                Message = Constants.EX_ARGUMENT_EXCEPTION,
                Details = context.Exception.Message,
                RequestId = string.Empty,
                TraceId = string.Empty,
                HelpUrl = $"{baseHelpUrl}/BadRequestError"
            };
            return errorModel;
        }
        private static ErrorModel TimeoutExceptionHandler(ExceptionContext context, int moduleNo, string baseHelpUrl)
        {
            var errorModel = new ErrorModel
            {
                Code = (int)HttpStatusCode.RequestTimeout,
                Error = $"{moduleNo}-{Constants.CONNECTION_LOST}",
                Message = Constants.EX_CONNECTION_TIMEOUT,
                Details = context.Exception.Message,
                RequestId = string.Empty,
                TraceId = string.Empty,
                HelpUrl = $"{baseHelpUrl}/TimeoutError"
            };
            return errorModel;
        }
        private static ErrorModel NullReferenceExceptionHandler(ExceptionContext context, int moduleNo, string baseHelpUrl)
        {
            var errorModel = new ErrorModel
            {
                Code = (int)HttpStatusCode.InternalServerError,
                Error = $"{moduleNo}-{Constants.NULL_REFERENCE}",
                Message = Constants.EX_NULL_REFERENCE,
                Details = context.Exception.Message,
                RequestId = string.Empty,
                TraceId = string.Empty,
                HelpUrl = $"{baseHelpUrl}/NullReferenceError"
            };
            return errorModel;

        }
        private static ErrorModel SqlExceptionHandler(ExceptionContext context, int moduleNo, string baseHelpUrl)
        {
            var errorModel = new ErrorModel
            {
                Code = (int)HttpStatusCode.InternalServerError,
                Error = $"{moduleNo}-{Constants.SQL_EXCEPTION}",
                Message = Constants.EX_SQL_EXCEPTION,
                Details = context.Exception.Message,
                RequestId = string.Empty,
                TraceId = string.Empty,
                HelpUrl = $"{baseHelpUrl}/SqlExceptionError"
            };
            return errorModel;
        }

        public static string ConcatErrorString(string oldMessage, string newMessage)
        {
            string splitString = $"<strong>{GUID_Error_Key}</strong>";
            string returnMessage = string.Empty;
            string[] oldMessageArray = null;
            string[] newMessageArray = null;

            if (string.IsNullOrEmpty(oldMessage) && !string.IsNullOrEmpty(newMessage)) returnMessage = newMessage;
            if (!string.IsNullOrEmpty(oldMessage) && string.IsNullOrEmpty(newMessage)) returnMessage = oldMessage;

            if (!string.IsNullOrEmpty(oldMessage) && !string.IsNullOrEmpty(newMessage))
            {
                if (oldMessage.Contains(splitString) && newMessage.Contains(splitString))
                {
                    oldMessageArray = oldMessage.Split(splitString);
                    newMessageArray = newMessage.Split(splitString);
                    returnMessage = oldMessageArray[0];
                    if (!oldMessageArray[0].Contains(newMessageArray[0]))
                        returnMessage = oldMessageArray[0] + newMessageArray[0];
                    returnMessage += splitString + oldMessageArray[1] + newMessageArray[1];
                }
                else
                {
                    returnMessage = oldMessage + " " + newMessage;
                }
            }
            return returnMessage;
        }

        public static string LogErrorAndReturnGuid(System.Exception exception, string functionName, string customErrorMsgForUI, string additionalInfotoLog, ILogger logger)
        {
            string errorMessage = string.Empty;
            string errorMessage_Kibana = string.Empty;
            string returnMessage = string.Empty;
            Guid _value = Guid.NewGuid();

            additionalInfotoLog = Convert.ToString(additionalInfotoLog);
            customErrorMsgForUI = Convert.ToString(customErrorMsgForUI);
            functionName = Convert.ToString(functionName);
            if (exception != null)
            {
                errorMessage = " AdditionalInfo: " + additionalInfotoLog + " Exception: " + exception.ToString();
            }
            else
            {
                errorMessage = " Custom-Error-Message: " + customErrorMsgForUI + " AdditionalInfo: " + additionalInfotoLog;
            }

            errorMessage_Kibana = $" {GUID_Error_Key} {_value.ToString()} Function Name: {functionName} {errorMessage} ";
            logger.LogError(errorMessage_Kibana);

            returnMessage = customErrorMsgForUI;
            if (exception != null)
            {
                returnMessage = "If the issue still persists after resubmitting the slip, please contact TAT Administrator.";
            }
            returnMessage = $"<li>{returnMessage}</li><strong>{GUID_Error_Key}</strong><div>{_value.ToString()}</div>";
            return returnMessage;
        }
    }
}
