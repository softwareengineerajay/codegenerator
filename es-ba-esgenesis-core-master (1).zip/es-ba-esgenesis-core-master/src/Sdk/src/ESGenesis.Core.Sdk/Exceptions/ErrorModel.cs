﻿namespace ESGenesis.Core.Sdk.Exceptions
{
    public class ErrorModel
    {
        public int Code { get; set; }
        public string? Error { get; set; }
        public required string Message { get; set; }
        public string? Details { get; set; }
        public string? RequestId { get; set; }
        public string? TraceId { get; set; }
        public required string HelpUrl { get; set; } = "https://www.example.com";
    }
}
