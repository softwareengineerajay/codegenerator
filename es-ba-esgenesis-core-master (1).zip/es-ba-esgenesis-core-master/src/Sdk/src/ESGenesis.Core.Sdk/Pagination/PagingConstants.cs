﻿namespace ESGenesis.Core.Sdk.Constants
{
    public class PagingConstants
    {
        public const int DEFAULT_PAGE_SIZE = 100;

        public const int DEFAULT_PAGE_INDEX = 0;
    }
}
