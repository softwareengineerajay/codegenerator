﻿using System.Collections;
using System.Linq.Expressions;
using System.Reflection;
using ESGenesis.Core.Sdk.Constants;

namespace ESGenesis.Core.Sdk.Pagination
{
    public static class PagingExtensions
    {
        /// <summary>
        /// The collection types that should be avoided for the sort column.
        /// </summary>
        private static List<Type> collections = new List<Type>() { typeof(IEnumerable<>), typeof(IEnumerable) };

        /// <summary>
        /// Gets the paged result.
        /// </summary>
        /// <typeparam name="T">The type.</typeparam>
        /// <param name="query">The query.</param>
        /// <param name="paging">The paging.</param>
        /// <returns>The paged result.</returns>
        public static PagedResult<T> GetPagedResult<T>(this IQueryable<T> query, Paging paging)
        {
            int count = query.Count();
            Paging validatedPaging = ResetPagingObjectIfInvalid(paging, count);
            return new PagedResult<T>(query.SortAndPage(validatedPaging).ToArray(), count, validatedPaging);
        }

        /// <summary>
        /// Gets the paged result and converts the result.
        /// </summary>
        /// <typeparam name="T1">The type of the query elements.</typeparam>
        /// <typeparam name="T2">The resulting type of the conversion.</typeparam>
        /// <param name="query">The query.</param>
        /// <param name="paging">The paging.</param>
        /// <param name="convert">The convert.</param>
        /// <returns>The paged result.</returns>
        public static PagedResult<T2> GetPagedResult<T1, T2>(this IQueryable<T1> query, Paging paging, Func<T1, T2> convert)
        {
            int count = query.Count();
            Paging validatedPaging = ResetPagingObjectIfInvalid(paging, count);
            return new PagedResult<T2>(query.SortAndPage(validatedPaging).AsEnumerable().Select(x => convert(x)).ToArray(), count, validatedPaging);
        }

        /// <summary>
        /// Extends a query with paging and sorting.
        /// </summary>
        /// <typeparam name="T">The type.</typeparam>
        /// <param name="query">The query.</param>
        /// <param name="paging">The <see cref="Paging"/>.</param>
        /// <returns>The extended query.</returns>
        public static IQueryable<T> SortAndPage<T>(this IQueryable<T> query, Paging paging)
        {

            if (paging == null)
            {
                // If paging object is not provided then use default page size and page index
                paging = new Paging(PagingConstants.DEFAULT_PAGE_INDEX, PagingConstants.DEFAULT_PAGE_SIZE);
            }

            // If no sort column is provided use a property of the type, a sort column is required to use the 'Skip' method together with SQL-Server
            if (string.IsNullOrEmpty(paging.SortColumn))
            {
                paging.SortColumn = typeof(T).GetProperties()
                    .Where(p => p.PropertyType == typeof(string) || !p.PropertyType.GetInterfaces().Any(i => collections.Any(c => i == c)))
                    .First()
                    .Name;
            }

            // Sorting required
            var parameter = Expression.Parameter(typeof(T), "p");

            var command = paging.SortDirection == SortDirection.Descending ? "OrderByDescending" : "OrderBy";

            // If sort column is a nested property like 'CreatedBy.FirstName'
            var parts = paging.SortColumn.Split(new char[] { '.' }, StringSplitOptions.RemoveEmptyEntries);

            PropertyInfo property = typeof(T).GetProperty(parts[0]);
            if (property == null)
            {
                throw new ArgumentException($"Sort column {parts[0]} does not exist.");
            }

            MemberExpression member = Expression.MakeMemberAccess(parameter, property);
            for (int i = 1; i < parts.Length; i++)
            {
                property = property.PropertyType.GetProperty(parts[i]);
                member = Expression.MakeMemberAccess(member, property);
            }

            var orderByExpression = Expression.Lambda(member, parameter);

            Expression resultExpression = Expression.Call(
                typeof(Queryable),
                command,
                new Type[] { typeof(T), property.PropertyType },
                query.Expression,
                Expression.Quote(orderByExpression));

            query = query.Provider.CreateQuery<T>(resultExpression);

            return query.Skip(paging.PageIndex * paging.PageSize).Take(paging.PageSize);
        }

        public static IQueryable<T> SortAndPageV1<T>(this IQueryable<T> query, Paging paging)
        {

            if (paging == null)
            {
                // If paging object is not provided then use default page size and page index
                paging = new Paging(PagingConstants.DEFAULT_PAGE_INDEX, PagingConstants.DEFAULT_PAGE_SIZE);
            }

            // If no sort column is provided use a property of the type, a sort column is required to use the 'Skip' method together with SQL-Server
            if (string.IsNullOrEmpty(paging.SortColumn))
            {
                paging.SortColumn = typeof(T).GetProperties()
                    .Where(p => p.PropertyType == typeof(string) || !p.PropertyType.GetInterfaces().Any(i => collections.Any(c => i == c)))
                    .First()
                    .Name;
            }

            // Sorting required
            var parameter = Expression.Parameter(typeof(T), "p");

            var command = paging.SortDirection == SortDirection.Descending ? "OrderByDescending" : "OrderBy";

            // If sort column is a nested property like 'CreatedBy.FirstName'
            var parts = paging.SortColumn.Split(new char[] { '.' }, StringSplitOptions.RemoveEmptyEntries);

            PropertyInfo property = typeof(T).GetProperty(parts[0]);
            if (property == null)
            {
                throw new ArgumentException($"Sort column {parts[0]} does not exist.");
            }

            MemberExpression member = Expression.MakeMemberAccess(parameter, property);

            var orderByExpression = Expression.Lambda(member, parameter);
            Expression resultExpression = Expression.Call(
             typeof(Queryable),
             command,
             new Type[] { typeof(T), property.PropertyType },
             query.Expression,
             Expression.Quote(orderByExpression));

            query = query.Provider.CreateQuery<T>(resultExpression);

            if (parts.Length > 1)
            {
                PropertyInfo propertyThen = null;
                MemberExpression memberThen;
                LambdaExpression thenByExpression = null;
                var Thencommand = paging.SortDirection == SortDirection.Descending ? "ThenByDescending" : "ThenBy";
                for (int i = 1; i < parts.Length; i++)
                {
                    propertyThen = typeof(T).GetProperty(parts[i]);
                    memberThen = Expression.MakeMemberAccess(parameter, propertyThen);
                    thenByExpression = Expression.Lambda(memberThen, parameter);
                }

                resultExpression = Expression.Call(
                typeof(Queryable),
                Thencommand,
                new Type[] { typeof(T), propertyThen.PropertyType },
                query.Expression,
                 Expression.Quote(thenByExpression)
                );
                query = query.Provider.CreateQuery<T>(resultExpression);
            }




            return query.Skip(paging.PageIndex * paging.PageSize).Take(paging.PageSize);
        }
        private static Paging ResetPagingObjectIfInvalid(Paging paging, int recordCount)
        {
            if (paging == null)
            {
                // If paging object is not provided then use default page size and page index
                paging = new Paging(PagingConstants.DEFAULT_PAGE_INDEX, PagingConstants.DEFAULT_PAGE_SIZE);
            }

            if (paging.PageSize == 0)
            {
                //If page size is not provided or 0 then use default page size
                paging.PageSize = PagingConstants.DEFAULT_PAGE_SIZE;
            }

            double totalPages = Math.Ceiling((double)recordCount / paging.PageSize);

            if (paging.PageIndex < 0)
                paging.PageIndex = 0;

            if (paging.PageIndex > (totalPages == 0 ? 0 : totalPages - 1))
                paging.PageIndex = Convert.ToInt32(totalPages - 1);
            return paging;
        }
    }

}
