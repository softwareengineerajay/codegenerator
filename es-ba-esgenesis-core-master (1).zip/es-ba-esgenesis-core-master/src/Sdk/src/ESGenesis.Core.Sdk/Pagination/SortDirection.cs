﻿using System.Runtime.Serialization;

namespace ESGenesis.Core.Sdk.Pagination
{
    [DataContract]
    public enum SortDirection
    {
        [EnumMember]
        Ascending,

        [EnumMember]
        Descending
    }
}
