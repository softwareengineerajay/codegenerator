﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ESGenesis.Core.Sdk.Authentication
{
    public interface ILoggedInUser
    {
        string? AccessToken { get; set; }
        string? TokenIssuerKey { get; set; }
        string? EmailId { get; set; }
        string? NtLoginId { get; set; }
        string? Name { get; set; }
        int? CurentErpSystemId { get; set; }
        public string CurentErpSystem { get; set; }
        public bool IsTrainingUser { get; set; }
        public bool IsExternalApp { get; set; }
        public string? DefaultUserEmailId { get; set; }
        public string? ImpersonatedUserId { get; set; }
        public string ClientId { get; set; }
        public int AppId { get; set; }

    }
}
