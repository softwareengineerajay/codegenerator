﻿using MediatR;

namespace ESGenesis.Core.Sdk.CQRS.Events
{
    public class EventBus : IEventBus
    {
        private readonly IMediator mediator;
        public EventBus(IMediator mediator)
        {
            this.mediator = mediator;
        }

        public async Task Publish<TEvent>(TEvent @event) where TEvent : IEvent
        {

            await mediator.Publish(@event);

        }
        public async Task Publish<TEvent>(params TEvent[] events) where TEvent : IEvent
        {
            foreach (var @event in events)
            {
                await mediator.Publish(@event);
            }
        }
    }
}
