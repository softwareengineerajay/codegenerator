﻿namespace ESGenesis.Core.Sdk.CQRS.Events
{
    public interface IEventBus
    {
        Task Publish<TEvent>(TEvent @event) where TEvent : IEvent;
        Task Publish<TEvent>(params TEvent[] events) where TEvent : IEvent;
    }
}
