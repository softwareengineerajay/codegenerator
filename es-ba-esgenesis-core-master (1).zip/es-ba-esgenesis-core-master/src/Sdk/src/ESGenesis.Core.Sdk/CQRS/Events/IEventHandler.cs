﻿using MediatR;

namespace ESGenesis.Core.Sdk.CQRS.Events
{
    public interface IEventHandler<in TEvent> : INotificationHandler<TEvent>
           where TEvent : IEvent
    {
    }
}
