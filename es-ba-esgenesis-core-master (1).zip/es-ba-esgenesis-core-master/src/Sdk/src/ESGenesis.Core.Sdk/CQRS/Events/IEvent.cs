﻿using MediatR;

namespace ESGenesis.Core.Sdk.CQRS.Events
{
    public interface IEvent : INotification
    {
    }
}
