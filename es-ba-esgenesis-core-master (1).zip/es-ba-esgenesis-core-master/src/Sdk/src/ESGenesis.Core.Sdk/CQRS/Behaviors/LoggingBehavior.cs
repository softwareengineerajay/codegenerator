﻿using ESGenesis.Core.Sdk.Extensions;
using MediatR;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;

namespace ESGenesis.Core.Sdk.CQRS.Behaviors;
public class LoggingBehavior<TRequest, TResponse> : IPipelineBehavior<TRequest, TResponse>
    where TRequest : IRequest<TResponse>
{
    private readonly ILogger<LoggingBehavior<TRequest, TResponse>> logger;
    public LoggingBehavior(ILogger<LoggingBehavior<TRequest, TResponse>> logger) => this.logger = logger;

    public async Task<TResponse> Handle(TRequest request, RequestHandlerDelegate<TResponse> next, CancellationToken cancellationToken)
    {
        //logger.LogTrace("----- Handling command {CommandName} ({@Command})", request.GetGenericTypeName(), request);
        //var response = await next();
        //logger.LogTrace("----- Command {CommandName} handled - response: {@Response}", request.GetGenericTypeName(), response);

        try
        {
            var requestLog = JsonConvert.SerializeObject(request, new JsonSerializerSettings() { NullValueHandling = NullValueHandling.Ignore });
            logger.LogInformation($"----- Handling command - {request.GetGenericTypeName()} -request: {requestLog}");
        }
        catch (Exception ex)
        {
            // intentionally kept empty
        }
        var response = await next();
        try
        {
            logger.LogInformation("Command - {CommandName} handled - response: {@Response}", request.GetGenericTypeName(), response);
        }
        catch (Exception ex)
        {
            // intentionally kept empty
        }

        return response;
    }
}

