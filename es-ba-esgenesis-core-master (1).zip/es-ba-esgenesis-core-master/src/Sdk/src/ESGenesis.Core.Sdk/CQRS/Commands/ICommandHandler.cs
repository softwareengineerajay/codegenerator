﻿using MediatR;

namespace ESGenesis.Core.Sdk.CQRS.Commands
{
    public interface ICommandHandler<T> : IRequestHandler<T>
        where T : ICommand
    {
    }

    public interface ICommandHandler<in TCommand, TResponse> : IRequestHandler<TCommand, TResponse>
          where TCommand : ICommand<TResponse>
    {
    }
}
