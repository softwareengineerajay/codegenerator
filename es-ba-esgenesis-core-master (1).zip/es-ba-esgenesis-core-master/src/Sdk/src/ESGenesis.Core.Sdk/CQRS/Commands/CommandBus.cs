﻿using MediatR;

namespace ESGenesis.Core.Sdk.CQRS.Commands
{
    public class CommandBus : ICommandBus
    {
        private readonly IMediator mediator;

        public CommandBus(IMediator mediator)
        {
            this.mediator = mediator;
        }

        public Task Send<TCommand>(TCommand command) where TCommand : ICommand
        {
            return mediator.Send(command);
        }

        public Task<TResponse> Send<TCommand, TResponse>(TCommand command) where TCommand : ICommand<TResponse>
        {
            return mediator.Send(command);
        }
    }
}
