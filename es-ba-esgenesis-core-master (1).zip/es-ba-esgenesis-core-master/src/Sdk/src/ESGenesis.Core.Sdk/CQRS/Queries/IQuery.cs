﻿using MediatR;

namespace ESGenesis.Core.Sdk.CQRS.Queries
{
    public interface IQuery<out TResponse> : IRequest<TResponse>
    {
    }
}
