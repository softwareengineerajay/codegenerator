﻿using Microsoft.EntityFrameworkCore.Storage;

namespace ESGenesis.Core.Sdk.Data.Repositories
{
    public interface IWriteRepository<TEntity>
            where TEntity : class
    {
        void Create(TEntity entity);

        void Update(TEntity entity);

        void Delete(object id);

        void Delete(TEntity entity);

        void RemoveRange(IEnumerable<TEntity> entities);
    }

    public interface IWriteDbRepository<TEntity>
        : IWriteRepository<TEntity>
            where TEntity : class
    {
        Task<IDbContextTransaction> BeginTransactionAsync();
        Task CommitTransactionAsync(IDbContextTransaction transaction);
        IDbContextTransaction BeginTransaction();
        void RollbackTransaction();
        void CommitTransaction();
        int SaveChanges();
        Task<int> SaveChangesAsync();
    }
}
