﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Storage;

namespace ESGenesis.Core.Sdk.Data.Repositories
{
    public class GenericWriteRepository<TEntity>
        : IWriteDbRepository<TEntity> where TEntity : class
    {
        protected readonly BaseContext context;

        public GenericWriteRepository(BaseContext context)
        {
            this.context = context;
        }

        public virtual void Create(TEntity entity)
        {
            context.Set<TEntity>().Add(entity);
        }

        public virtual void Update(TEntity entity)
        {
            context.Set<TEntity>().Attach(entity);
            context.Entry(entity).State = EntityState.Modified;

        }

        public virtual void Delete(object id)
        {
            TEntity entity = context.Set<TEntity>().Find(id);
            Delete(entity);
        }

        public virtual void Delete(TEntity entity)
        {
            var dbSet = context.Set<TEntity>();
            if (context.Entry(entity).State == EntityState.Detached)
            {
                dbSet.Attach(entity);
            }
            dbSet.Remove(entity);

        }

        public virtual void RemoveRange(IEnumerable<TEntity> entities)
        {
            context.RemoveRange(entities);
        }

        public async Task<IDbContextTransaction> BeginTransactionAsync()
        {
            return await this.context.BeginTransactionAsync();
        }
        public async Task CommitTransactionAsync(IDbContextTransaction transaction)
        {
            await this.context.CommitTransactionAsync(transaction);
        }

        public IDbContextTransaction BeginTransaction()
        {
            return this.context.Database.BeginTransaction();
        }
        public void RollbackTransaction()
        {
            this.context.RollbackTransaction();
        }

        public void CommitTransaction()
        {
            this.context.Database.CommitTransaction();
        }
        public int SaveChanges()
        {
            return context.SaveChanges();
        }

        public Task<int> SaveChangesAsync()
        {
            return context.SaveChangesAsync();
        }
    }
}
