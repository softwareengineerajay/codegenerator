﻿using System.Data;
using ESGenesis.Core.Sdk.Authentication;
using ESGenesis.Core.Sdk.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.ChangeTracking;
using Microsoft.EntityFrameworkCore.Storage;

namespace ESGenesis.Core.Sdk.Data
{
    public class BaseContext : DbContext
    {
        protected ILoggedInUser loggedInUser;
        protected IDbContextTransaction currentTransaction;

        public Func<DateTime> TimestampProvider { get; set; } = () => DateTime.UtcNow;


        public BaseContext(DbContextOptions options, ILoggedInUser loggedInUser)
            : base(options)
        {
            this.loggedInUser = loggedInUser;
        }

        public override int SaveChanges()
        {
            TrackChanges();
            return base.SaveChanges();
        }

        public override async Task<int> SaveChangesAsync(CancellationToken cancellationToken = default)
        {
            TrackChanges();
            return await base.SaveChangesAsync(cancellationToken);
        }

        private void TrackChanges()
        {
            foreach (EntityEntry item in from e in ChangeTracker.Entries()
                                         where e.State == EntityState.Added || e.State == EntityState.Modified
                                         select e)
            {
                IAuditEntity auditEntity = item.Entity as IAuditEntity;
                if (auditEntity != null)
                {
                    if (item.State == EntityState.Added)
                    {
                        auditEntity.CreatedBy = !string.IsNullOrEmpty(auditEntity.CreatedBy) ? auditEntity.CreatedBy : loggedInUser.EmailId;//UserProvider;
                        auditEntity.ModifiedBy = !string.IsNullOrEmpty(auditEntity.ModifiedBy) ? auditEntity.ModifiedBy : loggedInUser.EmailId;
                        auditEntity.DateCreated = TimestampProvider();
                        auditEntity.DateModified = TimestampProvider();
                        if (loggedInUser.IsExternalApp)
                        {
                            auditEntity.CreatedSource = loggedInUser.TokenIssuerKey;
                        }
                    }
                    else
                    {

                        auditEntity.ModifiedBy = !string.IsNullOrEmpty(auditEntity.ModifiedBy) ? auditEntity.ModifiedBy : loggedInUser.EmailId;
                        auditEntity.DateModified = TimestampProvider();
                        if (loggedInUser.IsExternalApp)
                        {
                            auditEntity.ModifiedSource = loggedInUser.TokenIssuerKey;
                        }
                    }
                }

                IErpSystem erpSystemEntity = item.Entity as IErpSystem;
                if (erpSystemEntity != null)
                {
                    erpSystemEntity.ErpSystemId = loggedInUser.CurentErpSystemId;
                    erpSystemEntity.ErpSystem = loggedInUser.CurentErpSystem;
                }
            }
        }

        public async Task<IDbContextTransaction> BeginTransactionAsync()
        {
            if (currentTransaction != null) return null;

            // currentTransaction = await Database.BeginTransactionAsync(IsolationLevel.ReadCommitted);
            // Using ReadUncommitted to avoid deadlocks
            currentTransaction = await Database.BeginTransactionAsync(IsolationLevel.ReadUncommitted);

            return currentTransaction;
        }

        public async Task CommitTransactionAsync(IDbContextTransaction transaction)
        {
            if (transaction == null) throw new ArgumentNullException(nameof(transaction));
            if (transaction != currentTransaction) throw new InvalidOperationException($"Transaction {transaction.TransactionId} is not current");

            try
            {
                await SaveChangesAsync();
                transaction.Commit();
            }
            catch
            {
                RollbackTransaction();
                throw;
            }
            finally
            {
                if (currentTransaction != null)
                {
                    currentTransaction.Dispose();
                    currentTransaction = null;
                }
            }
        }

        public void RollbackTransaction()
        {
            try
            {
                currentTransaction?.Rollback();
            }
            finally
            {
                if (currentTransaction != null)
                {
                    currentTransaction.Dispose();
                    currentTransaction = null;
                }
            }
        }
        public IDbContextTransaction BeginTransaction()
        {
            if (currentTransaction != null) return null;

            currentTransaction = Database.BeginTransaction(IsolationLevel.ReadUncommitted);

            return currentTransaction;
        }
        public void CommitTransaction(IDbContextTransaction transaction)
        {
            if (transaction == null) throw new ArgumentNullException(nameof(transaction));
            if (transaction != currentTransaction) throw new InvalidOperationException($"Transaction {transaction.TransactionId} is not current");

            try
            {
                SaveChanges();
                transaction.Commit();
            }
            catch
            {
                RollbackTransactionforSync();
                throw;
            }
            finally
            {
                if (currentTransaction != null)
                {
                    currentTransaction.Dispose();
                    currentTransaction = null;
                }

            }
        }
        public void RollbackTransactionforSync()
        {
            try
            {
                currentTransaction?.Rollback();
            }
            finally
            {
                if (currentTransaction != null)
                {
                    currentTransaction.Dispose();
                    currentTransaction = null;
                }
            }
        }

    }

}
