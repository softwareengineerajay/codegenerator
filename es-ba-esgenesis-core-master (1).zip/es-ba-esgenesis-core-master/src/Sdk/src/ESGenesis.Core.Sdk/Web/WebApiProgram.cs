﻿
namespace ESGenesis.Core.Sdk.Web
{
    public static partial class EsGenesisWebApiProgram
    {
    }
}
