﻿namespace ESGenesis.Core.Sdk.Caching
{
    public interface ICache
    {
        #region Sync Methods

        //IEnumerable<RedisKey> GetAllCacheKeys();

        /// <summary>
        /// Reads the value with specified key from the local cache.</summary>
        /// <typeparam name="TItem">Data type</typeparam>
        /// <param name="key">Key</param>
        TItem Get<TItem>(string key);

        /// <summary>
        /// Adds a value to cache with a given key
        /// </summary>
        /// <param name="key">key</param>
        /// <param name="value">value</param>
        /// <param name="expiration">Expire time (Use TimeSpan.Zero to hold value with no expiration)</param>
        void Add(string key, object value, TimeSpan expiration);

        bool AddWithLock(string key, object value, TimeSpan expiration, TimeSpan lockExpiration);

        /// <summary>
        /// 
        /// </summary>
        /// <param name="key"></param>
        /// <param name="value"></param>
        void Add(string key, object value);

        bool AddWithLock(string key, object value, TimeSpan lockExpiration);



        /// <summary>
        /// Removes the value with specified key from the local cache. If the value doesn't exist, no error is raised.
        /// </summary>
        /// <param name="cacheKey">Key</param>
        bool Remove(string key);

        bool RemoveWithLock(string key, TimeSpan lockExpiration);

        /// <summary>
        /// Removes all items from the cache (avoid expect unit tests).
        /// </summary>
        void RemoveAll();

        /// <summary>
        /// it will remove based on serverType Prefix.
        /// </summary>
        /// <param name="serverTypePrefix"></param>
        void RemoveAll(string serverTypePrefix);
        #endregion

        #region Async Methods
        Task<TItem> GetAsync<TItem>(string key);
        Task<bool> AddAsync(string key, object value, TimeSpan expiration);
        Task<bool> AddAsync(string key, object value);
        Task<bool> AddWithLockAsync(string key, object value, TimeSpan lockExpiration);
        Task<bool> AddWithLockAsync(string key, object value, TimeSpan expiration, TimeSpan lockExpiration);
        Task<bool> RemoveAsync(string key);
        Task<bool> RemoveWithLockAsync(string key, TimeSpan lockExpiration);
        Task<bool> RemoveAllAsync();
        Task<bool> RemoveAllAsync(string serverTypePrefix);
        #endregion

    }
}
