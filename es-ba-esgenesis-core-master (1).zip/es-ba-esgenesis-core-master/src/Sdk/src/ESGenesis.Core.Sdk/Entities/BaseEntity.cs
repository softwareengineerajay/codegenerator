﻿using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using DocumentFormat.OpenXml.Office2013.PowerPoint.Roaming;
using Microsoft.EntityFrameworkCore.Query.Internal;

namespace ESGenesis.Core.Sdk.Entities
{
    public class BaseEntity<T>
        : IEntity<T>, IAuditEntity where T : new()

    {
        [Key]
        public T Id { get; set; }
        [Required]
        [DefaultValue(true)]
        public bool IsActive { get; set; }
        [Required]
        public DateTime DateCreated { get; set; }
        [Required]
        [MaxLength(100)]
        public string? CreatedBy { get; set; }
        [Required]
        public DateTime DateModified { get; set; }
        [Required]
        [MaxLength(100)]
        public string? ModifiedBy { get; set; }
        [MaxLength(15)]
        public string? CreatedSource { get; set; }
        [MaxLength(15)]
        public string? ModifiedSource { get; set; }
        public int? SourceId { get; set; }
        
    }

    public class ErpBaseEntity<T> : BaseEntity<T>, IErpSystem where T : new()
    {
        public int? ErpSystemId { get; set; }
        public string? ErpSystem { get; set; }
    }
}
