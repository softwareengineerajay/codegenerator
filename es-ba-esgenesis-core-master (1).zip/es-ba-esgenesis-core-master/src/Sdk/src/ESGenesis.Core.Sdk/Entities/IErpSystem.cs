﻿namespace ESGenesis.Core.Sdk.Entities
{
    public interface IErpSystem
    {
        int? ErpSystemId { get; set; }
        string ErpSystem { get; set; }
    }
}
