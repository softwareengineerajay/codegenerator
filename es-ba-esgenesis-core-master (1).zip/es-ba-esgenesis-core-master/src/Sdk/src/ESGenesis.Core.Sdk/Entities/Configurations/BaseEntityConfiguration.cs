﻿// Licensed to the .NET Foundation under one or more agreements.
// The .NET Foundation licenses this file to you under the MIT license.

using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore;

namespace ESGenesis.Core.Sdk.Entities.Configurations
{
    public class BaseEntityConfiguration : IEntityTypeConfiguration<BaseEntity<int>>
    {
        public void Configure(EntityTypeBuilder<BaseEntity<int>> builder)
        {            
            builder.HasKey(x => x.Id);
            builder.Property(x => x.Id).ValueGeneratedOnAdd();
            builder.Property(x => x.IsActive).HasDefaultValueSql("1");
            builder.Property(x => x.DateCreated).HasDefaultValueSql("GETUTCDATE()");
            builder.Property(x => x.DateModified).HasDefaultValueSql("GETUTCDATE()");
        }
    }
}
