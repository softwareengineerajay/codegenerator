﻿namespace ESGenesis.Core.Sdk.UtilityClasses
{
    public static class CommonMethods
    {
        public static string GetEnviornment()
        {
            var environment = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT");
            return environment?.ToLower() ?? "unknown";
        }
    }
}
