﻿using System.IO.Compression;
using System.Text;

namespace ESGenesis.Core.Sdk.UtilityClasses
{
    public static class CompressDecompress
    {
        public static string CompressData(string input)
        {
            if (string.IsNullOrWhiteSpace(input))
                return input;

            using (var compressedStream = new MemoryStream())
            {
                using (var uncompressedStream = new MemoryStream(Encoding.UTF8.GetBytes(input)))
                {
                    using (var compressorStream = new DeflateStream(compressedStream, CompressionMode.Compress, true))
                    {
                        uncompressedStream.CopyTo(compressorStream);
                    }
                }

                return Convert.ToBase64String(compressedStream.ToArray());
            }
        }
        public static string DecompressData(string input)
        {
            if (string.IsNullOrWhiteSpace(input))
                return input;

            using (var decompressedStream = new MemoryStream())
            {
                using (var compressedStream = new MemoryStream(Convert.FromBase64String(input)))
                {
                    using (var decompressorStream = new DeflateStream(compressedStream, CompressionMode.Decompress))
                    {
                        decompressorStream.CopyTo(decompressedStream);
                    }
                }
                return Encoding.UTF8.GetString(decompressedStream.ToArray());
            }
        }
    }

}
