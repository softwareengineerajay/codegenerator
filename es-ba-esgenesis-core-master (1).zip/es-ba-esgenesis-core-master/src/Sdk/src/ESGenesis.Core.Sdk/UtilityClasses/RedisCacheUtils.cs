﻿//using ESGenesis.Core.Sdk.Caching;
//using NOV.ES.TAT.Common.UserPermissions.Models;
//using System.Text.RegularExpressions;
//using System.Text;
//using NOV.ES.TAT.Common.FeatureToggle.Models;

//namespace NOV.ES.TAT.Common.UtilityClasses
//{
//    public static class RedisCacheUtils
//    {

//        private static string GetUserToggleFeaturesRedisKey(string currentUserEmailId)
//        {
//            var enviornmentCode = CommonMethods.GetEnviornment();
//            var email = $"{currentUserEmailId.Trim()}-ft-{enviornmentCode}";
//            return ConvertEmailToRedisKey(email);
//        }

//        private static string GetUserRedisKey(string currentUserEmailId)
//        {
//            var enviornmentCode = CommonMethods.GetEnviornment();
//            var email = $"{currentUserEmailId.Trim()}-{enviornmentCode}";
//            return ConvertEmailToRedisKey(email);
//        }

//        private static string ConvertEmailToRedisKey(string emailAddress)
//        {
//            if(string.IsNullOrEmpty(emailAddress))
//            {
//                throw new System.ArgumentException("RedisCacheUtils.ConvertEmailToRedisKey: Email address cannot be null or empty", nameof(emailAddress));
//            }

//            // Remove special characters and replace them with underscores
//            string sanitizedEmail = Regex.Replace(emailAddress.Trim().ToLower(), @"[^0-9a-zA-Z]+", "_");

//            // Encode the string to ensure it's safe for use as a Redis key
//            byte[] encodedBytes = Encoding.UTF8.GetBytes(sanitizedEmail);
//            string redisKey = Convert.ToBase64String(encodedBytes);

//            return redisKey;
//        }

//        #region User Profile Cache Methods
//        // write a method to get UserProfile from ICache using GetUserRedisKey
//        public static async Task<UserProfile> GetUserProfileFromCacheAsync(string currentUserEmailId, ICache cache)
//        {
//            UserProfile userProfile = null;
//            try
//            {
//                var userRedisKey = GetUserRedisKey(currentUserEmailId);
//                userProfile = await cache.GetAsync<UserProfile>(userRedisKey);
//            }
//            catch (System.Exception ex)
//            {
//                //logger.LogError("Exception thrown while getting user profile from ICache: " + ex.ToString());
//            }
//            return userProfile;
//        }

//        // write a method to set UserProfile to ICache using GetUserRedisKey
//        public static async Task SetUserProfileToCacheAsync(string currentUserEmailId, ICache cache, UserProfile userProfile)
//        {
//            try
//            {
//                var userRedisKey = GetUserRedisKey(currentUserEmailId);
//                await cache.AddWithLockAsync(userRedisKey, userProfile, new TimeSpan(24,0,0), new TimeSpan(0,0,1));
//            }
//            catch (System.Exception ex)
//            {
//                //logger.LogError("Exception thrown while setting user profile to ICache: " + ex.ToString());
//            }
//        }

//        public static async Task<bool> RemoveUserProfileFromCacheAsync(string currentUserEmailId, ICache cache)
//        {
//            bool isDeleted = false;
//            try
//            {
//                var userRedisKey = GetUserRedisKey(currentUserEmailId);
//                isDeleted = await cache.RemoveWithLockAsync(userRedisKey, new TimeSpan(0,0,1));
//            }
//            catch (System.Exception ex)
//            {
//                //logger.LogError("Exception thrown while setting user profile to ICache: " + ex.ToString());
//            }
//            return isDeleted;
//        }
//        #endregion

//        #region User Feature Toggle Cache Methods
//        // write a method to get UserProfile from ICache using GetUserRedisKey
//        public static async Task<ToggleFeatures> GetUserToggleFeaturesFromCacheAsync(string currentUserEmailId, ICache cache)
//        {
//            ToggleFeatures userToggleFeatures = null;
//            try
//            {
//                var userToggleFeaturesRedisKey = GetUserToggleFeaturesRedisKey(currentUserEmailId);
//                userToggleFeatures = await cache.GetAsync<ToggleFeatures>(userToggleFeaturesRedisKey);
//            }
//            catch (System.Exception ex)
//            {
//                //logger.LogError("Exception thrown while getting user profile from ICache: " + ex.ToString());
//            }
//            return userToggleFeatures;
//        }

//        // write a method to set UserProfile to ICache using GetUserRedisKey
//        public static async Task SetUserToggleFeaturesToCacheAsync(string currentUserEmailId, ICache cache, ToggleFeatures toggleFeatures)
//        {
//            try
//            {
//                var userToggleFeaturesRedisKey = GetUserToggleFeaturesRedisKey(currentUserEmailId);
//                await cache.AddWithLockAsync(userToggleFeaturesRedisKey, toggleFeatures, new TimeSpan(24, 0, 0), new TimeSpan(0, 0, 1));
//            }
//            catch (System.Exception ex)
//            {
//                //logger.LogError("Exception thrown while setting user profile to ICache: " + ex.ToString());
//            }
//        }

//        public static async Task<bool> RemoveUserToggleFeaturesFromCacheAsync(string currentUserEmailId, ICache cache)
//        {
//            bool isDeleted = false;
//            try
//            {
//                var userToggleFeaturesRedisKey = GetUserToggleFeaturesRedisKey(currentUserEmailId);
//                isDeleted = await cache.RemoveWithLockAsync(userToggleFeaturesRedisKey, new TimeSpan(0, 0, 1));
//            }
//            catch (System.Exception ex)
//            {
//                //logger.LogError("Exception thrown while setting user profile to ICache: " + ex.ToString());
//            }
//            return isDeleted;
//        }
//        #endregion

//    }
//}
