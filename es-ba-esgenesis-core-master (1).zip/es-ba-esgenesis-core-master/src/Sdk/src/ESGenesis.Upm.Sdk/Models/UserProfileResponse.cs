﻿namespace ESGenesis.Upm.Sdk.Models
{
    public enum UserResponseResult
    {
        None,
        Success,
        Error,
        NotFound,
    }

    public class UserProfileResponse
    {
        public int Id { get; set; }
        public int AppId { get; set; }
        public required string ClientId { get; set; }
        public required string Email { get; set; }
        public string? GenercEmail { get; set; }
        public string? FirstName { get; set; }
        public string? LastName { get; set; }
        public string? NtLoginId { get; set; }
        public bool IsSuperAdmin { get; set; }
        public int? Pin { get; set; }
        public string? ModifiedBy { get; set; }
        public DateTime? ModifiedDate { get; set; }                
        public List<UserSystemFeaturePermission>? UserSystemFeaturePermissions { get; set; }
    }

    public class UserSystemFeaturePermission
    {
        public string SystemFeatureCode { get; set; } = string.Empty;
        public string SystemFeatureDescription { get; set; } = string.Empty;
        public int PermissionId { get; set; }
        public string PermissionName { get; set; } = string.Empty;
        //public List<DataAccess> DataAccesses { get; set; }

    }

    public class DataAccess
    {
        public string DataAccessTypeCode { get; set; } = string.Empty;
        public List<string> DataAccessTypeValues { get; set; } = new List<string>();
    }

    
}
