﻿// Licensed to the .NET Foundation under one or more agreements.
// The .NET Foundation licenses this file to you under the MIT license.

namespace ESGenesis.Upm.Sdk.Models
{
    public enum ToggleFeatureResponseResult
    {
        None,
        Success,
        Error,
        NotFound,
    }

    public class ToggleFeatureResponse
    {
        public int AppId { get; set; }
        public string ModuleName​ { get; set; }
        public string FeatureCode​ { get; set; }
    }
}
