﻿// Licensed to the .NET Foundation under one or more agreements.
// The .NET Foundation licenses this file to you under the MIT license.

using System.ComponentModel.DataAnnotations;

namespace ESGenesis.Upm.Sdk.Models
{
    public enum UserPreferenceResponseResult
    {
        None,
        Success,
        Error,
        NotFound,
    }

    public class UserPreferenceResponse
    {
        public int Id { get; set; }
        public int? AppId { get; set; }
        public int? UserId { get; set; }

        [Required, MaxLength(100)]
        public required string ModuleCode { get; set; }

        [Required, MaxLength(100)]
        public required string PreferenceType { get; set; }

        [Required, MaxLength(2000)]
        public required string JsonData { get; set; }

    }
}
